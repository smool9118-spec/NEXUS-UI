<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import ButtonAtom from './showcase/ButtonAtom.vue'
import ButtonGroupAtom from './showcase/ButtonGroupAtom.vue'
import CheckboxAtom from './showcase/CheckboxAtom.vue'
import RadioAtom from './showcase/RadioAtom.vue'
import SwitchAtom from './showcase/SwitchAtom.vue'
import ComingAtom from './showcase/ComingAtom.vue'
import HomeAtom from './showcase/HomeAtom.vue'
import IconButtonAtom from './showcase/IconButtonAtom.vue'
import MaskedFieldAtom from './showcase/MaskedFieldAtom.vue'
import SelectAtom from './showcase/SelectAtom.vue'
import TextFieldAtom from './showcase/TextFieldAtom.vue'
import ToggleAtom from './showcase/ToggleAtom.vue'
import { atoms, type AtomId } from './showcase/atoms'
import './styles/playground.css'
import './styles/showcase.css'

const activeId = ref<AtomId>('home')
const activeSection = ref('')
const active = computed(() => atoms.find((item) => item.id === activeId.value) ?? atoms[0])
const navPages = computed(() => atoms.filter((item) => item.kind === 'page'))
const navAtoms = computed(() => atoms.filter((item) => item.kind !== 'page'))

let sectionObserver: IntersectionObserver | null = null

function isAtomId(value: string): value is AtomId {
  return atoms.some((item) => item.id === value)
}

function atomForSection(sectionId: string) {
  return atoms.find((item) => item.sections.some((section) => section.id === sectionId))
}

function parseHash() {
  const raw = location.hash.replace(/^#/, '')
  if (!raw) return
  if (isAtomId(raw)) {
    activeId.value = raw
    activeSection.value = atoms.find((item) => item.id === raw)?.sections[0]?.id ?? ''
    return
  }
  const owner = atomForSection(raw)
  if (owner) {
    activeId.value = owner.id
    activeSection.value = raw
  }
}

function selectAtom(id: AtomId) {
  activeId.value = id
  activeSection.value = atoms.find((item) => item.id === id)?.sections[0]?.id ?? ''
  history.replaceState(null, '', `#${id}`)
  window.scrollTo({ top: 0 })
}

async function goToSection(event: Event, sectionId: string) {
  event.preventDefault()
  const owner = atomForSection(sectionId)
  if (owner && owner.id !== activeId.value) {
    activeId.value = owner.id
  }
  activeSection.value = sectionId
  history.replaceState(null, '', `#${sectionId}`)
  await nextTick()
  document.getElementById(sectionId)?.scrollIntoView({ block: 'start' })
}

function bindSectionObserver() {
  sectionObserver?.disconnect()
  const nodes = active.value.sections
    .map((section) => document.getElementById(section.id))
    .filter((node): node is HTMLElement => Boolean(node))
  if (!nodes.length) return
  sectionObserver = new IntersectionObserver(
    (entries) => {
      const visible = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)
      const id = visible[0]?.target.id
      if (id) activeSection.value = id
    },
    { rootMargin: '-72px 0px -55% 0px', threshold: [0, 0.25, 1] },
  )
  nodes.forEach((node) => sectionObserver?.observe(node))
}

function onHashChange() {
  parseHash()
}

watch(activeId, async () => {
  await nextTick()
  bindSectionObserver()
})

onMounted(async () => {
  parseHash()
  if (!activeSection.value) {
    activeSection.value = active.value.sections[0]?.id ?? ''
  }
  window.addEventListener('hashchange', onHashChange)
  await nextTick()
  const hash = location.hash.replace(/^#/, '')
  if (hash && !isAtomId(hash)) {
    document.getElementById(hash)?.scrollIntoView({ block: 'start' })
  }
  bindSectionObserver()
})

onUnmounted(() => {
  sectionObserver?.disconnect()
  window.removeEventListener('hashchange', onHashChange)
})
</script>

<template>
  <div class="page docs-page">
    <header class="docs-topbar">
      <a class="brand docs-topbar-brand" href="#home" @click.prevent="selectAtom('home')">
        <b>NEXUS</b> UI
      </a>
      <a class="docs-download" href="/nexus-ui-project.zip" download="nexus-ui-project.zip">
        <svg class="docs-download-icon" viewBox="0 0 16 16" fill="none" aria-hidden="true">
          <path
            d="M8 2.5v7.2M5.2 7.4L8 10.2l2.8-2.8M3 13.5h10"
            stroke="currentColor"
            stroke-width="1.6"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
        Скачать весь проект (.zip)
      </a>
    </header>
    <div class="docs-shell">
      <aside class="docs-aside" aria-label="Каталог атомов">
        <a class="brand docs-logo" href="#home" @click.prevent="selectAtom('home')"><b>NEXUS</b> UI</a>
        <nav class="atom-nav" aria-label="Страницы">
          <button
            v-for="item in navPages"
            :key="item.id"
            type="button"
            class="atom-item"
            :class="{ 'is-active': item.id === activeId }"
            :aria-current="item.id === activeId ? 'page' : undefined"
            @click="selectAtom(item.id)"
          >
            {{ item.name }}
          </button>
        </nav>
        <p class="atom-nav-kicker">Атомы</p>
        <nav class="atom-nav" aria-label="Атомы">
          <button
            v-for="item in navAtoms"
            :key="item.id"
            type="button"
            class="atom-item"
            :class="{
              'is-active': item.id === activeId,
              'is-soon': !item.ready,
            }"
            :aria-current="item.id === activeId ? 'page' : undefined"
            @click="selectAtom(item.id)"
          >
            {{ item.name }}
          </button>
        </nav>
      </aside>

      <div class="docs-body" :class="{ 'has-toc': active.sections.length }">
        <main class="docs-main">
          <HomeAtom v-if="active.id === 'home'" />
          <ButtonAtom v-else-if="active.id === 'button'" />
          <ButtonGroupAtom v-else-if="active.id === 'button-group'" />
          <IconButtonAtom v-else-if="active.id === 'icon-button'" />
          <TextFieldAtom v-else-if="active.id === 'input'" />
          <MaskedFieldAtom v-else-if="active.id === 'masked-field'" />
          <SelectAtom v-else-if="active.id === 'select'" />
          <CheckboxAtom v-else-if="active.id === 'checkbox'" />
          <RadioAtom v-else-if="active.id === 'radio'" />
          <SwitchAtom v-else-if="active.id === 'switch'" />
          <ToggleAtom v-else-if="active.id === 'toggle'" />
          <ComingAtom v-else :atom="active" />
        </main>

        <nav v-if="active.sections.length" class="docs-toc" aria-label="Содержание">
          <p class="toc-kicker">Содержание</p>
          <a
            v-for="section in active.sections"
            :key="section.id"
            class="toc-link"
            :class="{ 'is-active': activeSection === section.id }"
            :href="`#${section.id}`"
            @click="goToSection($event, section.id)"
          >
            {{ section.label }}
          </a>
        </nav>
      </div>
    </div>
  </div>
</template>
