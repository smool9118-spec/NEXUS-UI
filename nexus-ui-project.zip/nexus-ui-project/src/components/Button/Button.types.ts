/** Пропсы и контракт UiButton для фронтендера. Вёрстка — в Button.scss, цвет — в tokens.css. */

export type UiButtonVariant = 'contained' | 'outlined' | 'text' | 'tonal'
export type UiButtonColor = 'primary' | 'secondary' | 'error' | 'warning' | 'info' | 'success'
export type UiButtonSize = 'sm' | 'md' | 'lg'
export type UiButtonType = 'button' | 'submit' | 'reset'

export interface UiButtonProps {
  /** Макет: Default / Outline / Text / Label (подложка). */
  variant?: UiButtonVariant
  color?: UiButtonColor
  size?: UiButtonSize
  type?: UiButtonType
  disabled?: boolean
  loading?: boolean
  /** Квадратная кнопка только с иконкой. */
  icon?: boolean
  block?: boolean
  rounded?: boolean
}

export const UI_BUTTON_VARIANTS: UiButtonVariant[] = ['contained', 'tonal', 'outlined', 'text']
export const UI_BUTTON_COLORS: UiButtonColor[] = [
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
]
export const UI_BUTTON_SIZES: UiButtonSize[] = ['lg', 'md', 'sm']
