<script setup lang="ts">
import { computed, inject } from 'vue'
import { UI_BUTTON_GROUP_KEY } from '../ButtonGroup/ButtonGroup.types'
import type { UiButtonProps } from './Button.types'
import './Button.scss'

defineOptions({ inheritAttrs: false })

const props = withDefaults(defineProps<UiButtonProps>(), {
  type: 'button',
})

const group = inject(UI_BUTTON_GROUP_KEY, null)

const variant = computed(() => props.variant ?? group?.value.variant ?? 'contained')
const color = computed(() => props.color ?? group?.value.color ?? 'primary')
const size = computed(() => props.size ?? group?.value.size ?? 'md')
const disabled = computed(() => Boolean(props.disabled || group?.value.disabled))

const classes = computed(() => [
  'ui-btn',
  `ui-btn--${variant.value}`,
  `ui-btn--${color.value}`,
  `ui-btn--${size.value}`,
  {
    'ui-btn--icon': props.icon,
    'ui-btn--block': props.block,
    'ui-btn--rounded': props.rounded,
    'is-loading': props.loading,
    'is-disabled': disabled.value,
  },
])

function onClick(event: MouseEvent) {
  if (disabled.value || props.loading) {
    event.preventDefault()
    event.stopImmediatePropagation()
    return
  }
  const button = event.currentTarget as HTMLButtonElement
  const rect = button.getBoundingClientRect()
  const ripple = document.createElement('span')
  const dim = Math.max(rect.width, rect.height)
  ripple.className = 'ui-btn__ripple'
  ripple.style.width = `${dim}px`
  ripple.style.height = `${dim}px`
  ripple.style.left = `${event.clientX - rect.left - dim / 2}px`
  ripple.style.top = `${event.clientY - rect.top - dim / 2}px`
  button.append(ripple)
  ripple.addEventListener('animationend', () => ripple.remove())
}
</script>

<template>
  <button
    :class="classes"
    :type="type"
    :disabled="disabled || loading"
    :aria-busy="loading ? 'true' : undefined"
    v-bind="$attrs"
    @click="onClick"
  >
    <span class="ui-btn__body">
      <slot name="icon-left" />
      <slot />
      <slot name="icon-right" />
    </span>
    <span v-if="loading" class="ui-btn__spinner" aria-hidden="true" />
  </button>
</template>
