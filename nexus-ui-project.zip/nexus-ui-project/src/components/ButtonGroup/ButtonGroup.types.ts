import type { ComputedRef, InjectionKey } from 'vue'
import type { UiButtonColor, UiButtonSize, UiButtonVariant } from '../Button/Button.types'

export interface UiButtonGroupProps {
  variant?: UiButtonVariant
  color?: UiButtonColor
  size?: UiButtonSize
  disabled?: boolean
}

export type UiButtonGroupContext = {
  variant: UiButtonVariant
  color: UiButtonColor
  size: UiButtonSize
  disabled: boolean
}

export const UI_BUTTON_GROUP_KEY: InjectionKey<ComputedRef<UiButtonGroupContext>> =
  Symbol('ui-button-group')
