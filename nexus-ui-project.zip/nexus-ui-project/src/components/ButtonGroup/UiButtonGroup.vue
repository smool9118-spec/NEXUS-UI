<script setup lang="ts">
import { computed, provide } from 'vue'
import { UI_BUTTON_GROUP_KEY, type UiButtonGroupProps } from './ButtonGroup.types'
import './ButtonGroup.scss'
import '../Button/Button.scss'

const props = withDefaults(defineProps<UiButtonGroupProps>(), {
  variant: 'contained',
  color: 'primary',
  size: 'md',
})

provide(
  UI_BUTTON_GROUP_KEY,
  computed(() => ({
    variant: props.variant,
    color: props.color,
    size: props.size,
    disabled: Boolean(props.disabled),
  })),
)

const classes = computed(() => [
  'ui-btn-group',
  `ui-btn-group--${props.variant}`,
  `ui-btn-group--${props.color}`,
  `ui-btn-group--${props.size}`,
  { 'is-disabled': props.disabled },
])
</script>

<template>
  <div :class="classes" role="group">
    <slot />
  </div>
</template>
