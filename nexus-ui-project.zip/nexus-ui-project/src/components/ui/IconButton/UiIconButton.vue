<script setup lang="ts">
import { computed } from 'vue'
import type { UiIconButtonProps } from './IconButton.types'
import './IconButton.scss'

defineOptions({ inheritAttrs: false })

const props = withDefaults(defineProps<UiIconButtonProps>(), {
  variant: 'contained',
  color: 'default',
  size: 'md',
  shape: 'rounded',
  type: 'button',
})

const emit = defineEmits<{
  'update:active': [value: boolean]
}>()

const isDisabled = computed(() => Boolean(props.disabled || props.loading))

const classes = computed(() => [
  'ui-icon-btn',
  `ui-icon-btn--${props.variant}`,
  `ui-icon-btn--${props.color}`,
  `ui-icon-btn--${props.size}`,
  `ui-icon-btn--${props.shape}`,
  {
    'is-loading': props.loading,
    'is-disabled': props.disabled,
    'is-active': props.active,
  },
])

function onClick(event: MouseEvent) {
  if (isDisabled.value) {
    event.preventDefault()
    event.stopImmediatePropagation()
    return
  }

  if (props.active !== undefined) {
    emit('update:active', !props.active)
  }

  const button = event.currentTarget as HTMLButtonElement
  const rect = button.getBoundingClientRect()
  const ripple = document.createElement('span')
  const dim = Math.max(rect.width, rect.height)
  ripple.className = 'ui-icon-btn__ripple'
  ripple.style.width = `${dim}px`
  ripple.style.height = `${dim}px`
  ripple.style.left = `${event.clientX - rect.left - dim / 2}px`
  ripple.style.top = `${event.clientY - rect.top - dim / 2}px`
  button.append(ripple)
  ripple.addEventListener('animationend', () => ripple.remove())
}
</script>

<template>
  <button
    :class="classes"
    :type="type"
    :disabled="isDisabled"
    v-bind="$attrs"
    :aria-label="ariaLabel"
    :aria-pressed="active === undefined ? undefined : active ? 'true' : 'false'"
    :aria-busy="loading ? 'true' : undefined"
    @click="onClick"
  >
    <span class="ui-icon-btn__icon">
      <span v-if="loading" class="ui-icon-btn__spinner" aria-hidden="true" />
      <slot v-else />
    </span>
  </button>
</template>
