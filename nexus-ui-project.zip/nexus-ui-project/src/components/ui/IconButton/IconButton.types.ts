/** Пропсы и контракт UiIconButton для фронтендера. Вёрстка — в IconButton.scss, цвет — в tokens.css. */

export type UiIconButtonVariant = 'contained' | 'outlined' | 'standard'
export type UiIconButtonColor =
  | 'default'
  | 'primary'
  | 'secondary'
  | 'error'
  | 'warning'
  | 'info'
  | 'success'
export type UiIconButtonSize = 'sm' | 'md' | 'lg'
export type UiIconButtonShape = 'circle' | 'rounded'
export type UiIconButtonType = 'button' | 'submit' | 'reset'

export interface UiIconButtonProps {
  /** Макет: Обычный / Контур / Текст. */
  variant?: UiIconButtonVariant
  color?: UiIconButtonColor
  size?: UiIconButtonSize
  /** circle — круг, rounded — скругление из токенов размера. */
  shape?: UiIconButtonShape
  type?: UiIconButtonType
  disabled?: boolean
  /** Спиннер вместо иконки, клик заблокирован. */
  loading?: boolean
  /** Состояние переключателя (избранное / лайк). Ставит aria-pressed. */
  active?: boolean
  /** Обязательное описание действия для скринридера. */
  ariaLabel: string
}

export const UI_ICON_BUTTON_VARIANTS: UiIconButtonVariant[] = [
  'contained',
  'outlined',
  'standard',
]
export const UI_ICON_BUTTON_COLORS: UiIconButtonColor[] = [
  'default',
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
]
export const UI_ICON_BUTTON_SIZES: UiIconButtonSize[] = ['lg', 'md', 'sm']
export const UI_ICON_BUTTON_SHAPES: UiIconButtonShape[] = ['rounded', 'circle']
