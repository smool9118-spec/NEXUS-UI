/** Пропсы и контракт UiMaskedField для фронтендера. Вёрстка — в MaskedField.scss, цвет — в tokens.css. */

import type {
  UiTextFieldColor,
  UiTextFieldProps,
  UiTextFieldSize,
  UiTextFieldVariant,
} from '../TextField/TextField.types'

export type { UiTextFieldColor, UiTextFieldSize, UiTextFieldVariant }

/** Готовые пресеты маски. Кастом — любая строка с токенами # / A / *. */
export type UiMaskPreset = 'phone' | 'date' | 'time' | 'card' | 'inn' | 'snils'
export type UiMaskPattern = UiMaskPreset | (string & {})

export const UI_MASK_PRESETS: Record<UiMaskPreset, string> = {
  phone: '+7 (###) ###-##-##',
  date: '##.##.####',
  time: '##:##',
  card: '#### #### #### ####',
  inn: '############',
  snils: '###-###-### ##',
}

export const UI_MASK_PRESET_IDS: UiMaskPreset[] = ['phone', 'date', 'time', 'card', 'inn', 'snils']

/**
 * Наследует визуальные пропсы UiTextField.
 * # — цифра, A — буква, * — любой символ, остальное — литералы маски.
 */
export interface UiMaskedFieldProps extends Pick<
  UiTextFieldProps,
  | 'variant'
  | 'size'
  | 'color'
  | 'label'
  | 'placeholder'
  | 'helperText'
  | 'error'
  | 'errorMessage'
  | 'disabled'
  | 'readonly'
  | 'clearable'
  | 'required'
  | 'id'
  | 'name'
> {
  /** Отформатированная или «чистая» строка — зависит от unmaskedValue. */
  modelValue?: string
  /**
   * Пресет или кастомный паттерн.
   * phone → +7 (###) ###-##-##, date → ##.##.####, time → ##:##, card → #### #### #### ####.
   */
  mask?: UiMaskPattern
  /** Если true, в v-model уходит строка без скобок, пробелов и дефисов. */
  unmaskedValue?: boolean
  /** Показывать шаблон маски при фокусе (и незаполненные слоты полупрозрачно). */
  maskPlaceholder?: boolean
  /** Жёсткий лимит символов (для маски — слотов, иначе длина строки). */
  maxLength?: number
  /** Счётчик current / maxLength в правом нижнем углу. */
  showCounter?: boolean
}

export function resolveMaskPattern(mask: string | undefined): string {
  if (!mask) return ''
  if (Object.prototype.hasOwnProperty.call(UI_MASK_PRESETS, mask)) {
    return UI_MASK_PRESETS[mask as UiMaskPreset]
  }
  return mask
}
