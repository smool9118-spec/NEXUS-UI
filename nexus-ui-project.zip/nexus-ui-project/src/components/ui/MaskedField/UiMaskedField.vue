<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, useSlots, watch } from 'vue'
import UiTextField from '../TextField/UiTextField.vue'
import {
  resolveMaskPattern,
  type UiMaskedFieldProps,
} from './MaskedField.types'
import './MaskedField.scss'

type SlotAccept = '#' | 'A' | '*'
type MaskToken = { type: 'slot'; accept: SlotAccept } | { type: 'literal'; char: string }

defineOptions({ inheritAttrs: false })

const props = withDefaults(defineProps<Omit<UiMaskedFieldProps, 'modelValue'>>(), {
  variant: 'outlined',
  size: 'md',
  color: 'primary',
  mask: '',
  unmaskedValue: false,
  maskPlaceholder: false,
  showCounter: false,
})

const model = defineModel<string>({ default: '' })

const emit = defineEmits<{
  focus: [event: FocusEvent]
  blur: [event: FocusEvent]
  clear: []
  complete: [value: string]
}>()

const slots = useSlots()
const uid = useId()
const helperId = computed(() => `ui-masked-helper-${uid}`)
const root = ref<HTMLElement | null>(null)
const focused = ref(false)
const guideStyle = ref<Record<string, string>>({})
const editing = ref(false)

const tokens = computed(() => parsePattern(resolveMaskPattern(props.mask)))
const hasSlots = computed(() => tokens.value.some((token) => token.type === 'slot'))
const isPhone = computed(() => props.mask === 'phone')
const isError = computed(() => Boolean(props.error || props.errorMessage))
const helper = computed(() => props.errorMessage || props.helperText || '')
const counterVisible = computed(() => Boolean(props.showCounter && props.maxLength != null))
const showFooter = computed(() => Boolean(helper.value || counterVisible.value))
const nativeType = computed(() => (isPhone.value ? 'tel' : 'text'))

const rawValue = computed(() => {
  const source = String(model.value ?? '')
  if (!hasSlots.value) return limitLength(source)
  return coerceRaw(extractRaw(source, tokens.value), tokens.value)
})

const masked = computed(() => {
  if (!hasSlots.value) return { formatted: rawValue.value, complete: false }
  return applyMask(rawValue.value, tokens.value)
})

const displayValue = computed(() => masked.value.formatted)
const isComplete = computed(() => masked.value.complete)

const charCount = computed(() => rawValue.value.length)
const counterLimit = computed(() => props.maxLength ?? 0)
const counterRatio = computed(() => {
  if (!counterLimit.value) return 0
  return charCount.value / counterLimit.value
})
const counterState = computed<'limit' | 'warn' | 'normal'>(() => {
  if (isError.value || (counterLimit.value > 0 && charCount.value >= counterLimit.value)) return 'limit'
  if (counterRatio.value >= 0.9) return 'warn'
  return 'normal'
})

const maskTemplate = computed(() =>
  tokens.value.map((token) => (token.type === 'slot' ? '_' : token.char)).join(''),
)

const showGuide = computed(
  () =>
    Boolean(props.maskPlaceholder && focused.value && hasSlots.value && !props.disabled) &&
    !isComplete.value,
)

const guideRest = computed(() => maskTemplate.value.slice(displayValue.value.length))

const classes = computed(() => [
  'ui-masked',
  {
    'has-footer': showFooter.value,
    'is-guided': showGuide.value,
    'is-error': isError.value,
    'is-disabled': props.disabled,
  },
])

watch(
  () => props.unmaskedValue,
  (unmasked) => {
    const next = unmasked ? rawValue.value : displayValue.value
    if (model.value !== next) model.value = next
  },
)

watch([displayValue, showGuide, () => props.size, () => props.variant], () => {
  syncGuide()
})

onMounted(() => {
  syncGuide()
  window.addEventListener('resize', syncGuide)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', syncGuide)
})

function getInput() {
  return root.value?.querySelector('input.ui-field__input') as HTMLInputElement | null
}

function syncGuide() {
  const input = getInput()
  const wrap = root.value
  if (!input || !wrap) return
  const ir = input.getBoundingClientRect()
  const wr = wrap.getBoundingClientRect()
  const styles = getComputedStyle(input)
  guideStyle.value = {
    top: `${ir.top - wr.top}px`,
    left: `${ir.left - wr.left}px`,
    width: `${ir.width}px`,
    height: `${ir.height}px`,
    fontSize: styles.fontSize,
    fontFamily: styles.fontFamily,
    fontWeight: styles.fontWeight,
    lineHeight: styles.lineHeight,
    letterSpacing: styles.letterSpacing,
  }
}

function commit(raw: string, complete: boolean) {
  const next = props.unmaskedValue || !hasSlots.value ? raw : applyMask(raw, tokens.value).formatted
  if (model.value !== next) model.value = next
  if (complete) emit('complete', raw)
}

function restoreCaret(pos: number) {
  nextTick(() => {
    const input = getInput()
    if (!input) return
    const max = input.value.length
    const next = Math.max(0, Math.min(pos, max))
    input.setSelectionRange(next, next)
    syncGuide()
  })
}

function applyEdit(start: number, end: number, insert: string) {
  if (props.disabled || props.readonly || editing.value) return
  editing.value = true
  const toks = tokens.value
  const formatted = displayValue.value

  if (!hasSlots.value) {
    const next = limitLength(formatted.slice(0, start) + insert + formatted.slice(end))
    const caret = Math.min(start + insert.length, next.length)
    commit(next, false)
    restoreCaret(caret)
    nextTick(() => {
      editing.value = false
    })
    return
  }

  const raw = rawValue.value
  const rawStart = slotCountBefore(formatted, toks, start)
  const rawEnd = slotCountBefore(formatted, toks, end)
  const insertRaw = isPhone.value ? insert.replace(/\D/g, '') : takeMatching(insert, toks, rawStart)
  const head = raw.slice(0, rawStart) + insertRaw
  const nextRaw = coerceRaw(head + raw.slice(rawEnd), toks)
  const caretSlots = Math.min(coerceRaw(head, toks).length, nextRaw.length)
  const { formatted: nextFormatted, complete } = applyMask(nextRaw, toks)
  commit(nextRaw, complete)
  restoreCaret(caretAfterSlots(nextFormatted, toks, caretSlots))
  nextTick(() => {
    editing.value = false
  })
}

function onBeforeInput(event: Event) {
  const e = event as InputEvent
  if (props.disabled || props.readonly) return
  if (e.isComposing) return

  const inputType = e.inputType || ''
  if (inputType === 'insertFromPaste' || inputType === 'insertFromDrop') {
    e.preventDefault()
    return
  }
  if (inputType.startsWith('history')) return

  const input = e.target as HTMLInputElement
  const start = input.selectionStart ?? 0
  const end = input.selectionEnd ?? 0

  if (inputType === 'insertText' || inputType === 'insertReplacementText' || inputType === 'insertCompositionText') {
    e.preventDefault()
    applyEdit(start, end, e.data ?? '')
    return
  }

  if (inputType === 'deleteContentBackward' || inputType === 'deleteByCut' || inputType === 'deleteSoftLineBackward') {
    e.preventDefault()
    if (start !== end) {
      applyEdit(start, end, '')
      return
    }
    const [from, to] = rangeForBackspace(displayValue.value, tokens.value, start)
    applyEdit(from, to, '')
    return
  }

  if (inputType === 'deleteContentForward' || inputType === 'deleteSoftLineForward') {
    e.preventDefault()
    if (start !== end) {
      applyEdit(start, end, '')
      return
    }
    const [from, to] = rangeForDelete(displayValue.value, tokens.value, start)
    applyEdit(from, to, '')
  }
}

function onKeydown(event: KeyboardEvent) {
  if (props.disabled || props.readonly) return
  if (event.isComposing) return
  if (event.ctrlKey || event.metaKey || event.altKey) return
  if (event.defaultPrevented) return
  if (event.key !== 'Backspace' && event.key !== 'Delete') return

  const input = event.target as HTMLInputElement
  const start = input.selectionStart ?? 0
  const end = input.selectionEnd ?? 0
  event.preventDefault()

  if (start !== end) {
    applyEdit(start, end, '')
    return
  }
  if (event.key === 'Backspace') {
    const [from, to] = rangeForBackspace(displayValue.value, tokens.value, start)
    applyEdit(from, to, '')
    return
  }
  const [from, to] = rangeForDelete(displayValue.value, tokens.value, start)
  applyEdit(from, to, '')
}

function onPaste(event: Event) {
  if (props.disabled || props.readonly) return
  const e = event as ClipboardEvent
  e.preventDefault()
  const text = e.clipboardData?.getData('text') ?? ''
  const input = e.target as HTMLInputElement
  const start = input.selectionStart ?? 0
  const end = input.selectionEnd ?? 0
  applyEdit(start, end, text)
}

function onInnerUpdate(value: string | number) {
  if (editing.value) return
  const next = String(value ?? '')
  if (next === displayValue.value) return

  const input = getInput()
  const caret = input?.selectionStart ?? next.length
  const toks = tokens.value

  if (!hasSlots.value) {
    const limited = limitLength(next)
    commit(limited, false)
    restoreCaret(Math.min(caret, limited.length))
    return
  }

  const nextRaw = coerceRaw(extractRaw(next, toks), toks)
  const { formatted, complete } = applyMask(nextRaw, toks)
  const rawBefore = extractRaw(next.slice(0, caret), toks).length
  commit(nextRaw, complete)
  restoreCaret(caretAfterSlots(formatted, toks, Math.min(rawBefore, nextRaw.length)))
}

function onFocus(event: FocusEvent) {
  focused.value = true
  emit('focus', event)
  nextTick(syncGuide)
}

function onBlur(event: FocusEvent) {
  focused.value = false
  emit('blur', event)
}

function onClear() {
  commit('', false)
  emit('clear')
}

function limitLength(value: string) {
  if (props.maxLength == null) return value
  return value.slice(0, props.maxLength)
}

function coerceRaw(raw: string, toks: MaskToken[]) {
  let next = raw
  if (isPhone.value) next = normalizePhoneDigits(next)
  const limit = toks.filter((token) => token.type === 'slot').length
  if (limit) next = next.slice(0, limit)
  return limitLength(next)
}

function parsePattern(pattern: string): MaskToken[] {
  if (!pattern) return []
  return Array.from(pattern).map((char) => {
    if (char === '#' || char === 'A' || char === '*') return { type: 'slot', accept: char }
    return { type: 'literal', char }
  })
}

function isSlotChar(char: string, accept: SlotAccept) {
  if (accept === '#') return /^\d$/.test(char)
  if (accept === 'A') return /^\p{L}$/u.test(char)
  return char.length === 1 && char !== '\n' && char !== '\r'
}

function extractRaw(value: string, toks: MaskToken[]) {
  const slots = toks.filter((token): token is { type: 'slot'; accept: SlotAccept } => token.type === 'slot')
  if (!slots.length) return value

  let valueIndex = 0
  let out = ''
  for (const token of toks) {
    if (valueIndex >= value.length) break
    if (token.type === 'literal') {
      if (value[valueIndex] === token.char) valueIndex += 1
      continue
    }
    while (valueIndex < value.length && !isSlotChar(value[valueIndex], token.accept)) valueIndex += 1
    if (valueIndex < value.length) {
      out += value[valueIndex]
      valueIndex += 1
    }
  }
  return out
}

function takeMatching(insert: string, toks: MaskToken[], rawOffset: number) {
  const slots = toks.filter((token): token is { type: 'slot'; accept: SlotAccept } => token.type === 'slot')
  let index = rawOffset
  let out = ''
  for (const char of insert) {
    if (index >= slots.length) break
    if (isSlotChar(char, slots[index].accept)) {
      out += char
      index += 1
    }
  }
  return out
}

function applyMask(raw: string, toks: MaskToken[]) {
  const total = toks.filter((token) => token.type === 'slot').length
  if (!total) return { formatted: raw, complete: false }

  let rawIndex = 0
  let formatted = ''
  let filled = 0

  for (const token of toks) {
    if (token.type === 'literal') {
      const isPrefix = filled === 0 && raw.length > 0
      const willFillMore = rawIndex < raw.length
      if (isPrefix || willFillMore) formatted += token.char
      else if (filled > 0) break
    } else if (rawIndex < raw.length) {
      formatted += raw[rawIndex]
      rawIndex += 1
      filled += 1
    } else {
      break
    }
  }

  return { formatted, complete: filled === total }
}

function slotCountBefore(formatted: string, toks: MaskToken[], caret: number) {
  let pos = 0
  let count = 0
  for (const token of toks) {
    if (pos >= caret || pos >= formatted.length) break
    if (token.type === 'slot') count += 1
    pos += 1
  }
  return count
}

function caretAfterSlots(formatted: string, toks: MaskToken[], count: number) {
  if (count <= 0) return formatted ? prefixLength(formatted, toks) : 0
  let pos = 0
  let seen = 0
  for (const token of toks) {
    if (pos >= formatted.length) return formatted.length
    if (token.type === 'slot') {
      seen += 1
      pos += 1
      if (seen >= count) return pos
    } else {
      pos += 1
    }
  }
  return formatted.length
}

function prefixLength(formatted: string, toks: MaskToken[]) {
  let pos = 0
  for (const token of toks) {
    if (pos >= formatted.length) break
    if (token.type === 'slot') return pos
    pos += 1
  }
  return 0
}

function rangeForBackspace(formatted: string, toks: MaskToken[], caret: number): [number, number] {
  if (caret <= 0) return [0, 0]
  if (!hasSlots.value) return [Math.max(0, caret - 1), caret]
  let pos = 0
  let lastSlot = -1
  for (const token of toks) {
    if (pos >= formatted.length || pos >= caret) break
    if (token.type === 'slot') lastSlot = pos
    pos += 1
  }
  if (lastSlot < 0) return [0, caret]
  return [lastSlot, caret]
}

function rangeForDelete(formatted: string, toks: MaskToken[], caret: number): [number, number] {
  if (!hasSlots.value) return [caret, Math.min(formatted.length, caret + 1)]
  let pos = 0
  for (const token of toks) {
    if (pos >= formatted.length) break
    if (pos >= caret && token.type === 'slot') return [caret, pos + 1]
    pos += 1
  }
  return [caret, caret]
}

function normalizePhoneDigits(digits: string) {
  let next = digits.replace(/\D/g, '')
  if (next.startsWith('7') || next.startsWith('8')) next = next.slice(1)
  return next.slice(0, 10)
}
</script>

<template>
  <div ref="root" :class="classes">
    <UiTextField
      :model-value="displayValue"
      :variant="variant"
      :size="size"
      :color="color"
      :label="label"
      :placeholder="placeholder"
      :disabled="disabled"
      :readonly="readonly"
      :required="required"
      :clearable="clearable"
      :error="isError"
      :id="id"
      :name="name"
      :type="nativeType"
      :aria-describedby="helper ? helperId : undefined"
      autocomplete="off"
      spellcheck="false"
      @update:model-value="onInnerUpdate"
      @focus="onFocus"
      @blur="onBlur"
      @clear="onClear"
      @beforeinput="onBeforeInput"
      @keydown="onKeydown"
      @paste="onPaste"
    >
      <template v-if="slots.prepend" #prepend>
        <slot name="prepend" />
      </template>
      <template v-if="slots.append" #append>
        <slot name="append" />
      </template>
    </UiTextField>

    <span v-if="showGuide" class="ui-masked__guide" :style="guideStyle" aria-hidden="true">
      <span class="ui-masked__filled">{{ displayValue }}</span><span class="ui-masked__rest">{{ guideRest }}</span>
    </span>

    <div v-if="showFooter" class="ui-masked__footer">
      <p v-if="helper" :id="helperId" class="ui-masked__helper">{{ helper }}</p>
      <span
        v-if="counterVisible"
        class="ui-masked__counter"
        :class="{
          'is-warn': counterState === 'warn',
          'is-limit': counterState === 'limit',
        }"
      >
        {{ charCount }} / {{ counterLimit }}
      </span>
    </div>
  </div>
</template>
