<script setup lang="ts">
import { computed, provide, useId } from 'vue'
import UiRadio from './UiRadio.vue'
import {
  UI_RADIO_GROUP_KEY,
  type UiRadioGroupProps,
  type UiRadioValue,
} from './Radio.types'
import './Radio.scss'

const props = withDefaults(defineProps<Omit<UiRadioGroupProps, 'modelValue'>>(), {
  options: () => [],
  direction: 'column',
  size: 'md',
  color: 'primary',
})

const model = defineModel<UiRadioValue>()

const emit = defineEmits<{
  change: [value: UiRadioValue]
}>()

const uid = useId()
const labelId = computed(() => `ui-radio-group-${uid}-label`)
const helperId = computed(() => `ui-radio-group-${uid}-helper`)
const groupName = computed(() => props.name || `ui-radio-group-${uid}`)
const isError = computed(() => Boolean(props.error || props.errorMessage))
const helper = computed(() => props.errorMessage || props.helperText || '')
const size = computed(() => props.size)
const color = computed(() => props.color)
const disabled = computed(() => Boolean(props.disabled))

function setValue(value: UiRadioValue) {
  if (disabled.value) return
  model.value = value
  emit('change', value)
}

provide(UI_RADIO_GROUP_KEY, {
  model: computed(() => model.value),
  name: groupName,
  disabled,
  error: isError,
  size,
  color,
  setValue,
})

const classes = computed(() => [
  'ui-radio-group',
  `ui-radio-group--${props.direction}`,
  {
    'is-error': isError.value,
    'is-disabled': disabled.value,
  },
])

function onGroupKeydown(event: KeyboardEvent) {
  const keys = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Home', 'End']
  if (!keys.includes(event.key)) return
  const target = event.target
  if (!(target instanceof HTMLInputElement) || target.type !== 'radio') return
  const root = event.currentTarget as HTMLElement
  const radios = Array.from(
    root.querySelectorAll<HTMLInputElement>('input[type="radio"]:not(:disabled)'),
  )
  if (radios.length < 1) return
  const index = radios.indexOf(target)
  if (index < 0) return

  event.preventDefault()
  let next = index
  if (event.key === 'ArrowDown' || event.key === 'ArrowRight') {
    next = (index + 1) % radios.length
  } else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') {
    next = (index - 1 + radios.length) % radios.length
  } else if (event.key === 'Home') {
    next = 0
  } else if (event.key === 'End') {
    next = radios.length - 1
  }

  const node = radios[next]
  node.focus()
  node.click()
}
</script>

<template>
  <div
    :class="classes"
    role="radiogroup"
    :aria-labelledby="label ? labelId : undefined"
    :aria-describedby="helper ? helperId : undefined"
    :aria-invalid="isError ? 'true' : undefined"
    :aria-disabled="disabled ? 'true' : undefined"
    @keydown="onGroupKeydown"
  >
    <p v-if="label" :id="labelId" class="ui-radio-group__label">{{ label }}</p>
    <div class="ui-radio-group__list">
      <UiRadio
        v-for="option in options"
        :key="String(option.value)"
        :value="option.value"
        :label="option.label"
        :disabled="option.disabled"
      />
      <slot />
    </div>
    <p v-if="helper" :id="helperId" class="ui-radio-group__helper">{{ helper }}</p>
  </div>
</template>
