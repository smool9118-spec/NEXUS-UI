<script setup lang="ts">
import { computed, inject, useId } from 'vue'
import {
  UI_RADIO_GROUP_KEY,
  type UiRadioProps,
  type UiRadioValue,
} from './Radio.types'
import './Radio.scss'

const props = withDefaults(defineProps<Omit<UiRadioProps, 'modelValue'>>(), {
  size: 'md',
  color: 'primary',
  labelPlacement: 'end',
})

const model = defineModel<UiRadioValue>()

const emit = defineEmits<{
  change: [value: UiRadioValue]
}>()

const group = inject(UI_RADIO_GROUP_KEY, null)
const uid = useId()

const fieldId = computed(() => props.id || `ui-radio-${uid}`)
const size = computed(() => group?.size.value ?? props.size)
const color = computed(() => group?.color.value ?? props.color)
const name = computed(() => group?.name.value ?? props.name)
const isDisabled = computed(() => Boolean(props.disabled || group?.disabled.value))
const isError = computed(() => Boolean(group?.error.value))
const current = computed(() => (group ? group.model.value : model.value))
const isChecked = computed(() => {
  if (current.value === undefined || current.value === null) return false
  return current.value === props.value || String(current.value) === String(props.value)
})

const classes = computed(() => [
  'ui-radio',
  `ui-radio--${size.value}`,
  `ui-radio--${color.value}`,
  `ui-radio--${props.labelPlacement}`,
  {
    'is-checked': isChecked.value,
    'is-error': isError.value,
    'is-disabled': isDisabled.value,
  },
])

function select() {
  if (isDisabled.value) return
  if (group) group.setValue(props.value)
  else model.value = props.value
  emit('change', props.value)
}

function onChange(event: Event) {
  const input = event.target as HTMLInputElement
  if (!input.checked) return
  select()
}
</script>

<template>
  <div :class="classes">
    <span class="ui-radio__control">
      <input
        :id="fieldId"
        class="ui-radio__input"
        type="radio"
        :name="name"
        :value="value"
        :checked="isChecked"
        :disabled="isDisabled"
        :aria-invalid="isError ? 'true' : undefined"
        @change="onChange"
      />
      <span class="ui-radio__circle" aria-hidden="true">
        <span class="ui-radio__dot" />
      </span>
    </span>

    <span v-if="label" class="ui-radio__copy">
      <label class="ui-radio__label" :for="fieldId">{{ label }}</label>
    </span>
  </div>
</template>
