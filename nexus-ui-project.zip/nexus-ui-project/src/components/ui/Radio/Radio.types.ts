/** Пропсы и контракт UiRadio / UiRadioGroup для фронтендера. Вёрстка — в Radio.scss, цвет — в tokens.css. */

import type { ComputedRef, InjectionKey } from 'vue'

export type UiRadioSize = 'sm' | 'md' | 'lg'
export type UiRadioColor =
  | 'primary'
  | 'secondary'
  | 'error'
  | 'warning'
  | 'info'
  | 'success'
export type UiRadioLabelPlacement = 'end' | 'start' | 'top' | 'bottom'
export type UiRadioGroupDirection = 'row' | 'column'
export type UiRadioValue = string | number

export interface UiRadioOption {
  label: string
  value: UiRadioValue
  disabled?: boolean
}

export interface UiRadioProps {
  /** Текущее выбранное значение группы или одиночной кнопки. */
  modelValue?: UiRadioValue
  /** Значение этой кнопки: при выборе попадает в v-model. */
  value: UiRadioValue
  label?: string
  size?: UiRadioSize
  color?: UiRadioColor
  /** Позиция подписи относительно кружка. */
  labelPlacement?: UiRadioLabelPlacement
  disabled?: boolean
  id?: string
  name?: string
}

export interface UiRadioGroupProps {
  modelValue?: UiRadioValue
  name?: string
  options?: UiRadioOption[]
  direction?: UiRadioGroupDirection
  size?: UiRadioSize
  color?: UiRadioColor
  /** Заголовок группы, связан с role="radiogroup". */
  label?: string
  helperText?: string
  error?: boolean
  errorMessage?: string
  disabled?: boolean
}

export type UiRadioGroupContext = {
  model: ComputedRef<UiRadioValue | undefined>
  name: ComputedRef<string>
  disabled: ComputedRef<boolean>
  error: ComputedRef<boolean>
  size: ComputedRef<UiRadioSize>
  color: ComputedRef<UiRadioColor>
  setValue: (value: UiRadioValue) => void
}

export const UI_RADIO_GROUP_KEY: InjectionKey<UiRadioGroupContext> = Symbol('ui-radio-group')

export const UI_RADIO_SIZES: UiRadioSize[] = ['lg', 'md', 'sm']
export const UI_RADIO_COLORS: UiRadioColor[] = [
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
]
export const UI_RADIO_PLACEMENTS: UiRadioLabelPlacement[] = ['end', 'start', 'top', 'bottom']
export const UI_RADIO_DIRECTIONS: UiRadioGroupDirection[] = ['column', 'row']
