/** Пропсы и контракт UiSwitch для фронтендера. Вёрстка — в Switch.scss, цвет — в tokens.css. */

export type UiSwitchSize = 'sm' | 'md' | 'lg'
export type UiSwitchColor =
  | 'primary'
  | 'secondary'
  | 'error'
  | 'warning'
  | 'info'
  | 'success'
export type UiSwitchLabelPlacement = 'end' | 'start' | 'top' | 'bottom'

export interface UiSwitchProps {
  /** Вкл / выкл. */
  modelValue?: boolean
  size?: UiSwitchSize
  color?: UiSwitchColor
  /** Мини-спиннер в ползунке, переключение заблокировано. */
  loading?: boolean
  disabled?: boolean
  label?: string
  helperText?: string
  error?: boolean
  errorMessage?: string
  /** Позиция подписи относительно тумблера. */
  labelPlacement?: UiSwitchLabelPlacement
  id?: string
}

export const UI_SWITCH_SIZES: UiSwitchSize[] = ['lg', 'md', 'sm']
export const UI_SWITCH_COLORS: UiSwitchColor[] = [
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
]
export const UI_SWITCH_PLACEMENTS: UiSwitchLabelPlacement[] = ['end', 'start', 'top', 'bottom']
