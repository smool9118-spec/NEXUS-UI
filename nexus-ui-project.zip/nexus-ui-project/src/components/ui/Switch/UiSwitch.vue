<script setup lang="ts">
import { computed, useId } from 'vue'
import type { UiSwitchProps } from './Switch.types'
import './Switch.scss'

const props = withDefaults(defineProps<Omit<UiSwitchProps, 'modelValue'>>(), {
  size: 'md',
  color: 'primary',
  labelPlacement: 'end',
  loading: false,
})

const model = defineModel<boolean>({ default: false })

const emit = defineEmits<{
  change: [value: boolean]
}>()

const uid = useId()
const fieldId = computed(() => props.id || `ui-switch-${uid}`)
const helperId = computed(() => `${fieldId.value}-helper`)
const isOn = computed(() => Boolean(model.value))
const isError = computed(() => Boolean(props.error || props.errorMessage))
const helper = computed(() => props.errorMessage || props.helperText || '')
const isLocked = computed(() => Boolean(props.disabled || props.loading))

const classes = computed(() => [
  'ui-switch',
  `ui-switch--${props.size}`,
  `ui-switch--${props.color}`,
  `ui-switch--${props.labelPlacement}`,
  {
    'is-on': isOn.value,
    'is-error': isError.value,
    'is-disabled': props.disabled,
    'is-loading': props.loading,
  },
])

function toggle() {
  if (isLocked.value) return
  const next = !model.value
  model.value = next
  emit('change', next)
}
</script>

<template>
  <div :class="classes">
    <span class="ui-switch__control">
      <button
        :id="fieldId"
        class="ui-switch__hit"
        type="button"
        role="switch"
        :aria-checked="isOn ? 'true' : 'false'"
        :aria-busy="loading ? 'true' : undefined"
        :aria-disabled="isLocked ? 'true' : undefined"
        :aria-invalid="isError ? 'true' : undefined"
        :aria-describedby="helper ? helperId : undefined"
        :disabled="disabled"
        @click="toggle"
      >
        <span class="ui-switch__track" aria-hidden="true">
          <span v-if="$slots['track-on']" class="ui-switch__track-on">
            <slot name="track-on" />
          </span>
          <span v-if="$slots['track-off']" class="ui-switch__track-off">
            <slot name="track-off" />
          </span>
        </span>
        <span class="ui-switch__thumb" aria-hidden="true">
          <span class="ui-switch__knob">
            <span v-if="loading" class="ui-switch__spinner" />
            <slot v-else name="thumb-icon" />
          </span>
        </span>
      </button>
    </span>

    <span v-if="label || helper" class="ui-switch__copy">
      <label v-if="label" class="ui-switch__label" :for="fieldId">{{ label }}</label>
      <p v-if="helper" :id="helperId" class="ui-switch__helper">{{ helper }}</p>
    </span>
  </div>
</template>
