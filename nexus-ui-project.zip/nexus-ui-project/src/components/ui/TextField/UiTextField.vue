<script setup lang="ts">
import { computed, ref, useId, useSlots } from 'vue'
import type { UiTextFieldProps } from './TextField.types'
import './TextField.scss'

defineOptions({ inheritAttrs: false })

const props = withDefaults(defineProps<Omit<UiTextFieldProps, 'modelValue'>>(), {
  variant: 'outlined',
  size: 'md',
  color: 'primary',
  type: 'text',
  rows: 3,
})

const model = defineModel<string | number>({ default: '' })

const emit = defineEmits<{
  focus: [event: FocusEvent]
  blur: [event: FocusEvent]
  clear: []
}>()

const slots = useSlots()
const uid = useId()
const showPassword = ref(false)

const fieldId = computed(() => props.id || `ui-field-${uid}`)
const helperId = computed(() => `${fieldId.value}-helper`)
const isError = computed(() => Boolean(props.error || props.errorMessage))
const helper = computed(() => props.errorMessage || props.helperText || '')
const isFilled = computed(
  () => model.value !== '' && model.value !== null && model.value !== undefined,
)
const hasLabel = computed(() => Boolean(props.label))
const hasPrepend = computed(() => Boolean(slots.prepend))
const hasAppend = computed(() => Boolean(slots.append))
const canClear = computed(
  () => props.clearable && isFilled.value && !props.disabled && !props.readonly,
)
const isPassword = computed(() => props.type === 'password' && !props.multiline)
const nativeType = computed(() => {
  if (props.multiline) return undefined
  if (isPassword.value) return showPassword.value ? 'text' : 'password'
  return props.type
})
const displayValue = computed(() => (model.value === null || model.value === undefined ? '' : String(model.value)))

const classes = computed(() => [
  'ui-field',
  `ui-field--${props.variant}`,
  `ui-field--${props.size}`,
  `ui-field--${props.color}`,
  {
    'is-filled': isFilled.value,
    'is-floated': isFilled.value,
    'is-error': isError.value,
    'is-disabled': props.disabled,
    'has-label': hasLabel.value,
    'has-prepend': hasPrepend.value,
    'has-append': hasAppend.value || canClear.value || isPassword.value,
    'is-multiline': props.multiline,
  },
])

function onInput(event: Event) {
  const raw = (event.target as HTMLInputElement | HTMLTextAreaElement).value
  if (props.type === 'number' && !props.multiline) {
    model.value = raw === '' ? '' : Number(raw)
    return
  }
  model.value = raw
}

function onFocus(event: FocusEvent) {
  emit('focus', event)
}

function onBlur(event: FocusEvent) {
  emit('blur', event)
}

function onClear() {
  model.value = ''
  emit('clear')
}

function togglePassword() {
  showPassword.value = !showPassword.value
}
</script>

<template>
  <div :class="classes">
    <div class="ui-field__control">
      <label v-if="label" class="ui-field__label" :for="fieldId">
        {{ label }}<span v-if="required" class="ui-field__req" aria-hidden="true">*</span>
      </label>

      <span v-if="hasPrepend" class="ui-field__adorn">
        <slot name="prepend" />
      </span>

      <div class="ui-field__body">
        <textarea
          v-if="multiline"
          :id="fieldId"
          class="ui-field__input"
          :value="displayValue"
          :name="name"
          :rows="rows"
          :placeholder="placeholder"
          :disabled="disabled"
          :readonly="readonly"
          :required="required"
          :aria-invalid="isError ? 'true' : undefined"
          :aria-describedby="helper ? helperId : undefined"
          v-bind="$attrs"
          @input="onInput"
          @focus="onFocus"
          @blur="onBlur"
        />
        <input
          v-else
          :id="fieldId"
          class="ui-field__input"
          :type="nativeType"
          :value="displayValue"
          :name="name"
          :placeholder="placeholder"
          :disabled="disabled"
          :readonly="readonly"
          :required="required"
          :aria-invalid="isError ? 'true' : undefined"
          :aria-describedby="helper ? helperId : undefined"
          v-bind="$attrs"
          @input="onInput"
          @focus="onFocus"
          @blur="onBlur"
        />
      </div>

      <span v-if="hasAppend" class="ui-field__adorn">
        <slot name="append" />
      </span>

      <button
        v-if="canClear"
        class="ui-field__icon-btn"
        type="button"
        tabindex="-1"
        aria-label="Очистить"
        @click="onClear"
      >
        <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M6 6l12 12M18 6 6 18" stroke-linecap="round" />
        </svg>
      </button>

      <button
        v-if="isPassword"
        class="ui-field__icon-btn"
        type="button"
        tabindex="-1"
        :aria-label="showPassword ? 'Скрыть пароль' : 'Показать пароль'"
        :aria-pressed="showPassword ? 'true' : 'false'"
        @click="togglePassword"
      >
        <svg
          v-if="!showPassword"
          viewBox="0 0 24 24"
          aria-hidden="true"
          fill="none"
          stroke="currentColor"
          stroke-width="1.6"
        >
          <path d="M2.5 12s3.5-7 9.5-7 9.5 7 9.5 7-3.5 7-9.5 7-9.5-7-9.5-7Z" stroke-linejoin="round" />
          <circle cx="12" cy="12" r="3" />
        </svg>
        <svg
          v-else
          viewBox="0 0 24 24"
          aria-hidden="true"
          fill="none"
          stroke="currentColor"
          stroke-width="1.6"
        >
          <path d="M3 3l18 18" stroke-linecap="round" />
          <path
            d="M10.6 6.2A9.5 9.5 0 0 1 12 6c6 0 9.5 7 9.5 7a16 16 0 0 1-3.2 3.8M6.4 6.5A16 16 0 0 0 2.5 12s3.5 7 9.5 7c1.3 0 2.5-.2 3.6-.6"
            stroke-linejoin="round"
          />
        </svg>
      </button>
    </div>

    <p v-if="helper" :id="helperId" class="ui-field__helper">{{ helper }}</p>
  </div>
</template>
