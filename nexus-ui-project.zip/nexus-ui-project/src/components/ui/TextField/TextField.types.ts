/** Пропсы и контракт UiTextField для фронтендера. Вёрстка — в TextField.scss, цвет — в tokens.css. */

export type UiTextFieldVariant = 'outlined' | 'filled' | 'standard'
export type UiTextFieldSize = 'sm' | 'md' | 'lg'
export type UiTextFieldColor =
  | 'primary'
  | 'secondary'
  | 'error'
  | 'warning'
  | 'info'
  | 'success'
export type UiTextFieldType = 'text' | 'password' | 'email' | 'number' | 'tel' | 'search'

export interface UiTextFieldProps {
  modelValue?: string | number
  /** Макет: Контур / Заливка / стандарт с нижней линией. */
  variant?: UiTextFieldVariant
  size?: UiTextFieldSize
  color?: UiTextFieldColor
  label?: string
  placeholder?: string
  helperText?: string
  error?: boolean
  /** Если задан, заменяет helperText и включает состояние ошибки. */
  errorMessage?: string
  disabled?: boolean
  readonly?: boolean
  required?: boolean
  clearable?: boolean
  type?: UiTextFieldType
  multiline?: boolean
  rows?: number
  id?: string
  name?: string
}

export const UI_TEXT_FIELD_VARIANTS: UiTextFieldVariant[] = ['outlined', 'filled', 'standard']
export const UI_TEXT_FIELD_SIZES: UiTextFieldSize[] = ['lg', 'md', 'sm']
export const UI_TEXT_FIELD_COLORS: UiTextFieldColor[] = [
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
]
export const UI_TEXT_FIELD_TYPES: UiTextFieldType[] = [
  'text',
  'password',
  'email',
  'number',
  'tel',
  'search',
]
