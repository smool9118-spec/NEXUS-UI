/** Пропсы и контракт UiSelect для фронтендера. Вёрстка — в Select.scss, цвет — в tokens.css. */

import type {
  UiTextFieldColor,
  UiTextFieldProps,
  UiTextFieldSize,
  UiTextFieldVariant,
} from '../TextField/TextField.types'

export type { UiTextFieldColor, UiTextFieldSize, UiTextFieldVariant }

export interface UiSelectOption {
  label: string
  value: string | number
  disabled?: boolean
  group?: string
  icon?: string
}

export type UiSelectValue = string | number | Array<string | number> | null

export interface UiSelectProps extends Pick<
  UiTextFieldProps,
  | 'variant'
  | 'size'
  | 'color'
  | 'label'
  | 'placeholder'
  | 'helperText'
  | 'error'
  | 'errorMessage'
  | 'disabled'
  | 'required'
  | 'id'
  | 'name'
> {
  /** Одиночный выбор — скаляр или null, multiple — массив. */
  modelValue?: UiSelectValue
  options?: UiSelectOption[]
  multiple?: boolean
  /** Теги выбранных значений внутри поля (только при multiple). */
  chips?: boolean
  /** Поиск по списку внутри поля. */
  searchable?: boolean
  clearable?: boolean
  loading?: boolean
}

export const UI_SELECT_VARIANTS: UiTextFieldVariant[] = ['outlined', 'filled', 'standard']
export const UI_SELECT_SIZES: UiTextFieldSize[] = ['lg', 'md', 'sm']
export const UI_SELECT_COLORS: UiTextFieldColor[] = [
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
]
