<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, ref, useId, useSlots, watch } from 'vue'
import type { UiSelectOption, UiSelectProps, UiSelectValue } from './Select.types'
import '../TextField/TextField.scss'
import './Select.scss'

defineOptions({ inheritAttrs: false })

const props = withDefaults(defineProps<Omit<UiSelectProps, 'modelValue'>>(), {
  variant: 'outlined',
  size: 'md',
  color: 'primary',
  options: () => [],
  multiple: false,
  chips: false,
  searchable: false,
  clearable: false,
  loading: false,
})

const model = defineModel<UiSelectValue>({ default: null })

const emit = defineEmits<{
  focus: [event: FocusEvent]
  blur: [event: FocusEvent]
  clear: []
}>()

const slots = useSlots()
const uid = useId()
const root = ref<HTMLElement | null>(null)
const searchEl = ref<HTMLInputElement | null>(null)
const open = ref(false)
const query = ref('')
const activeValue = ref<string | number | null>(null)

const fieldId = computed(() => props.id || `ui-select-${uid}`)
const listId = computed(() => `${fieldId.value}-list`)
const helperId = computed(() => `${fieldId.value}-helper`)
const isError = computed(() => Boolean(props.error || props.errorMessage))
const helper = computed(() => props.errorMessage || props.helperText || '')
const hasLabel = computed(() => Boolean(props.label))
const hasPrepend = computed(() => Boolean(slots.prepend))
const selectedValues = computed<(string | number)[]>(() => {
  const value = model.value
  if (props.multiple) {
    return Array.isArray(value) ? value : value == null || value === '' ? [] : [value]
  }
  if (value == null || value === '' || Array.isArray(value)) return []
  return [value]
})
const isFilled = computed(() => selectedValues.value.length > 0)
const selectedOptions = computed(() =>
  selectedValues.value
    .map((value) => props.options.find((option) => option.value === value))
    .filter((option): option is UiSelectOption => Boolean(option)),
)
const filteredOptions = computed(() => {
  const q = query.value.trim().toLowerCase()
  if (!props.searchable || !q) return props.options
  return props.options.filter((option) => option.label.toLowerCase().includes(q))
})
const groupedOptions = computed(() => groupOptions(filteredOptions.value))
const enabledOptions = computed(() => filteredOptions.value.filter((option) => !option.disabled))
const showChips = computed(() => props.multiple && props.chips && selectedOptions.value.length > 0)
const canClear = computed(
  () => props.clearable && isFilled.value && !props.disabled,
)
const displayText = computed(() => {
  if (!isFilled.value) return ''
  if (slots.selected) return ''
  if (props.multiple && !props.chips) {
    if (selectedOptions.value.length > 2) return `Выбрано: ${selectedOptions.value.length}`
    return selectedOptions.value.map((option) => option.label).join(', ')
  }
  if (!props.multiple) return selectedOptions.value[0]?.label ?? ''
  return ''
})
const showPlaceholder = computed(() => {
  if (isFilled.value && !props.searchable) return false
  if (showChips.value && !(props.searchable && open.value)) return false
  if (props.searchable && open.value) return true
  return !isFilled.value
})
const placeholderText = computed(() => {
  if (props.searchable && open.value && isFilled.value && !props.multiple) {
    return selectedOptions.value[0]?.label || props.placeholder || ''
  }
  return props.placeholder || ''
})

const fieldClasses = computed(() => [
  'ui-field',
  `ui-field--${props.variant}`,
  `ui-field--${props.size}`,
  `ui-field--${props.color}`,
  {
    'is-filled': isFilled.value,
    'is-floated': isFilled.value || open.value,
    'is-error': isError.value,
    'is-disabled': props.disabled,
    'has-label': hasLabel.value,
    'has-prepend': hasPrepend.value,
    'has-append': true,
  },
])

const rootClasses = computed(() => [
  'ui-select',
  `ui-select--${props.variant}`,
  {
    'is-open': open.value,
    'is-disabled': props.disabled,
    'is-error': isError.value,
    'is-filled': isFilled.value,
    'is-searchable': props.searchable,
    'has-label': hasLabel.value,
  },
])

watch(open, (isOpen) => {
  if (isOpen) {
    query.value = ''
    const current = selectedValues.value[selectedValues.value.length - 1]
    const first = enabledOptions.value[0]?.value ?? null
    activeValue.value = current ?? first
    document.addEventListener('pointerdown', onDocPointer, true)
    document.addEventListener('keydown', onDocKey)
    nextTick(() => {
      if (props.searchable) searchEl.value?.focus()
      else (root.value?.querySelector('.ui-field__control') as HTMLElement | null)?.focus()
      scrollActive()
    })
    return
  }
  query.value = ''
  document.removeEventListener('pointerdown', onDocPointer, true)
  document.removeEventListener('keydown', onDocKey)
})

watch(filteredOptions, () => {
  if (!open.value) return
  if (!enabledOptions.value.some((option) => option.value === activeValue.value)) {
    activeValue.value = enabledOptions.value[0]?.value ?? null
  }
})

onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', onDocPointer, true)
  document.removeEventListener('keydown', onDocKey)
})

function groupOptions(options: UiSelectOption[]) {
  const groups: { name: string; items: UiSelectOption[] }[] = []
  for (const option of options) {
    const name = option.group ?? ''
    const last = groups[groups.length - 1]
    if (last && last.name === name) last.items.push(option)
    else groups.push({ name, items: [option] })
  }
  return groups
}

function isSelected(value: string | number) {
  return selectedValues.value.includes(value)
}

function optionId(value: string | number) {
  return `${listId.value}-${String(value).replace(/\s+/g, '-')}`
}

function setModel(next: (string | number)[]) {
  if (props.multiple) {
    model.value = next
    return
  }
  model.value = next[0] ?? null
}

function toggleOption(option: UiSelectOption) {
  if (option.disabled || props.disabled) return
  if (props.multiple) {
    const next = isSelected(option.value)
      ? selectedValues.value.filter((value) => value !== option.value)
      : [...selectedValues.value, option.value]
    setModel(next)
    activeValue.value = option.value
    return
  }
  setModel([option.value])
  close()
}

function removeValue(value: string | number, event?: Event) {
  event?.preventDefault()
  event?.stopPropagation()
  if (props.disabled) return
  setModel(selectedValues.value.filter((item) => item !== value))
}

function clear(event?: Event) {
  event?.preventDefault()
  event?.stopPropagation()
  if (props.disabled) return
  setModel([])
  query.value = ''
  emit('clear')
}

function openMenu() {
  if (props.disabled) return
  open.value = true
}

function close() {
  if (!open.value) return
  open.value = false
}

function toggle() {
  if (props.disabled) return
  open.value = !open.value
}

function onTriggerClick(event: MouseEvent) {
  const target = event.target as HTMLElement
  if (target.closest('.ui-select__chip-x, .ui-field__icon-btn')) return
  if (props.searchable) {
    openMenu()
    nextTick(() => searchEl.value?.focus())
    return
  }
  toggle()
}

function onDocPointer(event: PointerEvent) {
  if (!root.value?.contains(event.target as Node)) close()
}

function onDocKey(event: KeyboardEvent) {
  if (event.key === 'Escape') {
    event.preventDefault()
    close()
    ;(root.value?.querySelector('.ui-field__control') as HTMLElement | null)?.focus()
  }
}

function onControlKeydown(event: KeyboardEvent) {
  if (props.disabled) return
  const key = event.key

  if (!open.value) {
    if (key === 'ArrowDown' || key === 'ArrowUp' || key === 'Enter' || key === ' ') {
      event.preventDefault()
      openMenu()
    }
    return
  }

  if (key === 'ArrowDown') {
    event.preventDefault()
    moveActive(1)
    return
  }
  if (key === 'ArrowUp') {
    event.preventDefault()
    moveActive(-1)
    return
  }
  if (key === 'Home') {
    event.preventDefault()
    activeValue.value = enabledOptions.value[0]?.value ?? null
    scrollActive()
    return
  }
  if (key === 'End') {
    event.preventDefault()
    activeValue.value = enabledOptions.value[enabledOptions.value.length - 1]?.value ?? null
    scrollActive()
    return
  }
  if (key === 'Enter' || (key === ' ' && !props.searchable)) {
    event.preventDefault()
    const option = enabledOptions.value.find((item) => item.value === activeValue.value)
    if (option) toggleOption(option)
  }
}

function onSearchInput(event: Event) {
  query.value = (event.target as HTMLInputElement).value
  if (!open.value) openMenu()
}

function moveActive(step: number) {
  const items = enabledOptions.value
  if (!items.length) return
  const index = items.findIndex((item) => item.value === activeValue.value)
  const next = index < 0 ? (step > 0 ? 0 : items.length - 1) : (index + step + items.length) % items.length
  activeValue.value = items[next].value
  scrollActive()
}

function scrollActive() {
  nextTick(() => {
    if (activeValue.value == null) return
    const node = document.getElementById(optionId(activeValue.value))
    node?.scrollIntoView({ block: 'nearest' })
  })
}

function onFocus(event: FocusEvent) {
  emit('focus', event)
}

function onBlur(event: FocusEvent) {
  const next = event.relatedTarget as Node | null
  if (next && root.value?.contains(next)) return
  emit('blur', event)
}

function iconIsUrl(icon: string) {
  return /^(https?:|data:|\/|\.)/.test(icon)
}
</script>

<template>
  <div ref="root" :class="rootClasses">
    <div :class="fieldClasses">
      <div class="ui-select__anchor">
        <div
          class="ui-field__control"
          :id="fieldId"
          :role="searchable ? undefined : 'combobox'"
          :tabindex="searchable || disabled ? -1 : 0"
          :aria-expanded="searchable ? undefined : open ? 'true' : 'false'"
          :aria-haspopup="searchable ? undefined : 'listbox'"
          :aria-controls="searchable ? undefined : listId"
          :aria-activedescendant="!searchable && open && activeValue != null ? optionId(activeValue) : undefined"
          :aria-invalid="isError ? 'true' : undefined"
          :aria-describedby="helper ? helperId : undefined"
          :aria-busy="loading ? 'true' : undefined"
          :aria-disabled="disabled ? 'true' : undefined"
          :aria-required="required ? 'true' : undefined"
          :aria-multiselectable="!searchable && multiple ? 'true' : undefined"
          @click="onTriggerClick"
          @keydown="onControlKeydown"
          @focus="onFocus"
          @blur="onBlur"
        >
          <label v-if="label" class="ui-field__label" :for="searchable ? `${fieldId}-search` : fieldId">
            {{ label }}<span v-if="required" class="ui-field__req" aria-hidden="true">*</span>
          </label>

          <span v-if="hasPrepend" class="ui-field__adorn">
            <slot name="prepend" />
          </span>

          <div class="ui-field__body">
            <div class="ui-select__value">
              <template v-if="slots.selected">
                <slot name="selected" :options="selectedOptions" />
              </template>
              <template v-else-if="showChips">
                <span v-for="option in selectedOptions" :key="String(option.value)" class="ui-select__chip">
                  <span class="ui-select__chip-label">{{ option.label }}</span>
                  <button
                    class="ui-select__chip-x"
                    type="button"
                    tabindex="-1"
                    :aria-label="`Убрать ${option.label}`"
                    @click="removeValue(option.value, $event)"
                  >
                    <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M6 6l12 12M18 6 6 18" stroke-linecap="round" />
                    </svg>
                  </button>
                </span>
              </template>
              <span
                v-else-if="displayText && !(searchable && open)"
                class="ui-select__text"
              >
                {{ displayText }}
              </span>
              <input
                v-if="searchable"
                :id="`${fieldId}-search`"
                ref="searchEl"
                class="ui-select__search"
                :value="open ? query : ''"
                :placeholder="open || !hasLabel ? placeholderText : ''"
                :disabled="disabled"
                :name="name"
                autocomplete="off"
                role="combobox"
                :aria-expanded="open ? 'true' : 'false'"
                aria-autocomplete="list"
                aria-haspopup="listbox"
                :aria-controls="listId"
                :aria-activedescendant="open && activeValue != null ? optionId(activeValue) : undefined"
                @input="onSearchInput"
                @keydown="onControlKeydown"
                @focus="onFocus"
                @click.stop="openMenu"
              />
              <span
                v-else-if="showPlaceholder"
                class="ui-select__placeholder"
              >
                {{ placeholderText }}
              </span>
            </div>
          </div>

          <button
            v-if="canClear"
            class="ui-field__icon-btn"
            type="button"
            tabindex="-1"
            aria-label="Очистить"
            @click="clear"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8">
              <path d="M6 6l12 12M18 6 6 18" stroke-linecap="round" />
            </svg>
          </button>

          <span v-if="loading" class="ui-select__spinner" aria-hidden="true" />

          <span class="ui-select__chevron" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <path d="M6 9l6 6 6-6" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </span>
        </div>

        <div
          v-if="open"
          :id="listId"
          class="ui-select__menu"
          role="listbox"
          :aria-multiselectable="multiple ? 'true' : undefined"
          :aria-labelledby="label ? undefined : fieldId"
        >
          <div v-if="loading" class="ui-select__status">
            <span class="ui-select__spinner" aria-hidden="true" />
            Загрузка
          </div>
          <div v-else-if="!filteredOptions.length" class="ui-select__empty">
            <slot name="empty">Ничего не найдено</slot>
          </div>
          <ul v-else class="ui-select__list">
            <template v-for="(group, gIndex) in groupedOptions" :key="`${group.name}-${gIndex}`">
              <li v-if="group.name" class="ui-select__group" role="presentation">{{ group.name }}</li>
              <li
                v-for="option in group.items"
                :id="optionId(option.value)"
                :key="String(option.value)"
                class="ui-select__option"
                :class="{
                  'is-selected': isSelected(option.value),
                  'is-active': activeValue === option.value,
                  'is-disabled': option.disabled,
                }"
                role="option"
                :aria-selected="isSelected(option.value) ? 'true' : 'false'"
                :aria-disabled="option.disabled ? 'true' : undefined"
                @mousedown.prevent
                @click="toggleOption(option)"
              >
                <span v-if="multiple" class="ui-select__box" aria-hidden="true" />
                <img
                  v-if="option.icon && iconIsUrl(option.icon)"
                  class="ui-select__option-icon"
                  :src="option.icon"
                  alt=""
                />
                <span v-else-if="option.icon" class="ui-select__option-icon" aria-hidden="true">{{ option.icon }}</span>
                <slot name="option" :option="option" :selected="isSelected(option.value)">
                  <span class="ui-select__option-label">{{ option.label }}</span>
                </slot>
                <span v-if="!multiple && isSelected(option.value)" class="ui-select__check" aria-hidden="true">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12.5 9.5 17 19 7" stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
                </span>
              </li>
            </template>
          </ul>
        </div>
      </div>

      <p v-if="helper" :id="helperId" class="ui-field__helper">{{ helper }}</p>
    </div>
  </div>
</template>
