/** Пропсы и контракт UiCheckbox для фронтендера. Вёрстка — в Checkbox.scss, цвет — в tokens.css. */

export type UiCheckboxSize = 'sm' | 'md' | 'lg'
export type UiCheckboxColor =
  | 'primary'
  | 'secondary'
  | 'error'
  | 'warning'
  | 'info'
  | 'success'
export type UiCheckboxLabelPlacement = 'end' | 'start' | 'top' | 'bottom'

export type UiCheckboxValue = boolean | Array<string | number>

export interface UiCheckboxProps {
  /** Одиночный флажок — boolean; группа — массив выбранных value. */
  modelValue?: UiCheckboxValue
  /** Значение, которое попадает в массив при групповом v-model. */
  value?: string | number
  /** Частичный выбор: значок «минус», aria-checked="mixed". */
  indeterminate?: boolean
  size?: UiCheckboxSize
  color?: UiCheckboxColor
  label?: string
  /** Позиция подписи относительно бокса. */
  labelPlacement?: UiCheckboxLabelPlacement
  helperText?: string
  error?: boolean
  errorMessage?: string
  disabled?: boolean
  required?: boolean
  id?: string
  name?: string
}

export const UI_CHECKBOX_SIZES: UiCheckboxSize[] = ['lg', 'md', 'sm']
export const UI_CHECKBOX_COLORS: UiCheckboxColor[] = [
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
]
export const UI_CHECKBOX_PLACEMENTS: UiCheckboxLabelPlacement[] = ['end', 'start', 'top', 'bottom']
