<script setup lang="ts">
import { computed, nextTick, onMounted, ref, useId, watch } from 'vue'
import type { UiCheckboxProps, UiCheckboxValue } from './Checkbox.types'
import './Checkbox.scss'

const props = withDefaults(defineProps<Omit<UiCheckboxProps, 'modelValue'>>(), {
  size: 'md',
  color: 'primary',
  labelPlacement: 'end',
  indeterminate: false,
})

const model = defineModel<UiCheckboxValue>({ default: false })

const emit = defineEmits<{
  'update:indeterminate': [value: boolean]
  change: [value: UiCheckboxValue]
}>()

const uid = useId()
const inputEl = ref<HTMLInputElement | null>(null)

const fieldId = computed(() => props.id || `ui-check-${uid}`)
const helperId = computed(() => `${fieldId.value}-helper`)
const isError = computed(() => Boolean(props.error || props.errorMessage))
const helper = computed(() => props.errorMessage || props.helperText || '')
const isArrayModel = computed(() => Array.isArray(model.value))
const isChecked = computed(() => {
  if (isArrayModel.value) {
    if (props.value === undefined) return false
    return (model.value as Array<string | number>).includes(props.value)
  }
  return model.value === true
})
const ariaChecked = computed(() => {
  if (props.indeterminate && !isChecked.value) return 'mixed'
  return isChecked.value ? 'true' : 'false'
})

const classes = computed(() => [
  'ui-check',
  `ui-check--${props.size}`,
  `ui-check--${props.color}`,
  `ui-check--${props.labelPlacement}`,
  {
    'is-checked': isChecked.value,
    'is-indeterminate': props.indeterminate && !isChecked.value,
    'is-error': isError.value,
    'is-disabled': props.disabled,
  },
])

watch(
  () => [props.indeterminate, isChecked.value],
  () => syncIndeterminate(),
)

onMounted(() => syncIndeterminate())

function syncIndeterminate() {
  nextTick(() => {
    if (!inputEl.value) return
    inputEl.value.indeterminate = Boolean(props.indeterminate && !isChecked.value)
  })
}

function onChange(event: Event) {
  const input = event.target as HTMLInputElement
  const next = props.indeterminate ? true : input.checked
  if (props.indeterminate) emit('update:indeterminate', false)

  if (isArrayModel.value) {
    const current = [...(model.value as Array<string | number>)]
    if (props.value === undefined) return
    const index = current.indexOf(props.value)
    if (next && index < 0) current.push(props.value)
    if (!next && index >= 0) current.splice(index, 1)
    model.value = current
    emit('change', current)
    return
  }

  model.value = next
  emit('change', next)
}
</script>

<template>
  <div :class="classes">
    <span class="ui-check__control">
      <input
        :id="fieldId"
        ref="inputEl"
        class="ui-check__input"
        type="checkbox"
        :name="name"
        :checked="isChecked"
        :disabled="disabled"
        :required="required"
        :value="value"
        :aria-checked="ariaChecked"
        :aria-invalid="isError ? 'true' : undefined"
        :aria-describedby="helper ? helperId : undefined"
        @change="onChange"
      />
      <span class="ui-check__box" aria-hidden="true">
        <svg class="ui-check__icon ui-check__check" viewBox="0 0 12 12" fill="none">
          <path
            d="M2.5 6L5 8.5L10 3.5"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
        <svg class="ui-check__icon ui-check__minus" viewBox="0 0 12 12" fill="none">
          <path
            d="M2.5 6H9.5"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </span>
    </span>

    <span v-if="label || helper" class="ui-check__copy">
      <label v-if="label" class="ui-check__label" :for="fieldId">
        {{ label }}<span v-if="required" class="ui-check__req" aria-hidden="true">*</span>
      </label>
      <p v-if="helper" :id="helperId" class="ui-check__helper">{{ helper }}</p>
    </span>
  </div>
</template>
