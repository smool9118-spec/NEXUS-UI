import { attachOpenShadow } from './shadow'
import type { NuiToggleButton } from './toggle-button'

const css = `
:host {
  display: inline-block;
  box-sizing: border-box;
  width: fit-content;
  max-width: 100%;
  vertical-align: middle;
}
.track {
  display: flex;
  align-items: center;
  width: fit-content;
  overflow: hidden;
  padding: var(--nui-toggle-padding, 7px);
  border: 1px solid var(--nui-toggle-border, var(--nui-divider));
  border-radius: var(--nui-toggle-radius, var(--nui-radius-md));
  background: var(--nui-toggle-bg, transparent);
}
::slotted(nui-toggle-button) {
  flex: none;
}
:host([size='lg']) {
  --nui-toggle-radius: var(--nui-radius-lg);
  --nui-toggle-btn-padding: 14px;
  --nui-toggle-btn-radius: var(--nui-radius-lg);
}
:host([size='md']) {
  --nui-toggle-radius: var(--nui-radius-md);
  --nui-toggle-btn-padding: 10px;
  --nui-toggle-btn-radius: var(--nui-radius-md);
}
:host([size='sm']) {
  --nui-toggle-radius: var(--nui-radius-sm);
  --nui-toggle-btn-padding: 6px;
  --nui-toggle-btn-radius: var(--nui-radius-sm);
}
:host([disabled]) {
  opacity: 0.64;
  pointer-events: none;
}
`

export class NuiToggleGroup extends HTMLElement {
  static get observedAttributes() {
    return ['value', 'size', 'disabled']
  }

  #value = ''

  #observer: MutationObserver | null = null

  constructor() {
    super()
    const shadow = attachOpenShadow(this, css)
    if (!shadow.querySelector('.track')) {
      const track = document.createElement('div')
      track.className = 'track'
      const slot = document.createElement('slot')
      slot.addEventListener('slotchange', () => this.#sync())
      track.append(slot)
      shadow.append(track)
    }
  }

  connectedCallback() {
    this.setAttribute('role', 'radiogroup')
    if (!this.getAttribute('size')) this.setAttribute('size', 'md')
    this.#value = this.getAttribute('value') ?? this.#value
    this.addEventListener('nui-select', this.#onSelect)
    this.addEventListener('keydown', this.#onKey)
    this.#observer = new MutationObserver(() => this.#sync())
    this.#observer.observe(this, { childList: true, subtree: true })
    this.#sync()
  }

  disconnectedCallback() {
    this.removeEventListener('nui-select', this.#onSelect)
    this.removeEventListener('keydown', this.#onKey)
    this.#observer?.disconnect()
    this.#observer = null
  }

  attributeChangedCallback(name: string, oldValue: string | null, next: string | null) {
    if (oldValue === next) return
    if (name === 'value') {
      this.#value = next ?? ''
      this.#sync()
    }
    if (name === 'disabled') this.#sync()
  }

  get value() {
    return this.#value
  }

  set value(next: string) {
    const value = next ?? ''
    if (this.#value === value) {
      this.#sync()
      return
    }
    this.#value = value
    this.setAttribute('value', value)
    this.#sync()
  }

  get size() {
    return (this.getAttribute('size') as 'sm' | 'md' | 'lg') || 'md'
  }

  set size(next: 'sm' | 'md' | 'lg') {
    this.setAttribute('size', next)
  }

  get disabled() {
    return this.hasAttribute('disabled')
  }

  set disabled(next: boolean) {
    this.toggleAttribute('disabled', next)
  }

  #buttons() {
    return [...this.querySelectorAll('nui-toggle-button')] as NuiToggleButton[]
  }

  #sync() {
    const buttons = this.#buttons()
    const current = this.#value
    buttons.forEach((button, index) => {
      const selected = button.value === current
      button.selected = selected
      button.tabIndex = selected || (!current && index === 0) ? 0 : -1
    })
  }

  #commit(value: string) {
    if (this.disabled || value === this.#value) return
    this.value = value
    this.dispatchEvent(
      new CustomEvent('change', {
        bubbles: true,
        composed: true,
        detail: { value },
      }),
    )
  }

  #onSelect = (event: Event) => {
    const custom = event as CustomEvent<{ value: string }>
    event.stopPropagation()
    this.#commit(custom.detail.value)
  }

  #onKey = (event: KeyboardEvent) => {
    const keys = ['ArrowLeft', 'ArrowUp', 'ArrowRight', 'ArrowDown', 'Home', 'End']
    if (!keys.includes(event.key)) return
    const buttons = this.#buttons().filter((button) => !button.disabled)
    if (!buttons.length) return
    event.preventDefault()
    const currentIndex = Math.max(
      0,
      buttons.findIndex((button) => button.value === this.#value),
    )
    let nextIndex = currentIndex
    if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
      nextIndex = (currentIndex - 1 + buttons.length) % buttons.length
    }
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
      nextIndex = (currentIndex + 1) % buttons.length
    }
    if (event.key === 'Home') nextIndex = 0
    if (event.key === 'End') nextIndex = buttons.length - 1
    const next = buttons[nextIndex]
    this.#commit(next.value)
    next.focus()
  }
}

declare global {
  interface HTMLElementTagNameMap {
    'nui-toggle-group': NuiToggleGroup
  }
}
