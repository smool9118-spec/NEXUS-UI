import { attachOpenShadow } from './shadow'

const css = `
:host {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  flex: none;
  width: auto;
  padding: var(--nui-toggle-btn-padding, 10px);
  border-radius: var(--nui-toggle-btn-radius, var(--nui-radius-md));
  color: var(--nui-toggle-icon, var(--nui-text-secondary));
  background: transparent;
  cursor: pointer;
  user-select: none;
  outline: none;
  line-height: 0;
}
:host([selected]) {
  background: var(--nui-toggle-selected-bg, var(--nui-action-selected));
  color: var(--nui-toggle-icon-selected, var(--nui-text-primary));
}
:host([disabled]) {
  color: var(--nui-text-disabled);
  cursor: not-allowed;
  pointer-events: none;
}
:host(:focus-visible) {
  box-shadow: inset 0 0 0 2px var(--nui-primary-main);
}
::slotted(svg) {
  width: 24px;
  height: 24px;
  display: block;
}
`

export class NuiToggleButton extends HTMLElement {
  static get observedAttributes() {
    return ['value', 'disabled', 'selected']
  }

  constructor() {
    super()
    const shadow = attachOpenShadow(this, css)
    if (!shadow.querySelector('slot')) {
      shadow.append(document.createElement('slot'))
    }
  }

  connectedCallback() {
    this.setAttribute('role', 'radio')
    if (!this.hasAttribute('tabindex')) this.tabIndex = -1
    this.addEventListener('click', this.#onClick)
    this.addEventListener('keydown', this.#onKey)
    this.#syncAria()
  }

  disconnectedCallback() {
    this.removeEventListener('click', this.#onClick)
    this.removeEventListener('keydown', this.#onKey)
  }

  get value() {
    return this.getAttribute('value') ?? ''
  }

  set value(next: string) {
    this.setAttribute('value', next)
  }

  get disabled() {
    return this.hasAttribute('disabled')
  }

  set disabled(next: boolean) {
    this.toggleAttribute('disabled', next)
  }

  get selected() {
    return this.hasAttribute('selected')
  }

  set selected(next: boolean) {
    this.toggleAttribute('selected', next)
    this.#syncAria()
  }

  attributeChangedCallback() {
    this.#syncAria()
  }

  #syncAria() {
    this.setAttribute('aria-checked', this.selected ? 'true' : 'false')
    this.setAttribute('aria-disabled', this.disabled ? 'true' : 'false')
  }

  #onClick = () => {
    if (this.disabled) return
    this.dispatchEvent(
      new CustomEvent('nui-select', {
        bubbles: true,
        composed: true,
        detail: { value: this.value },
      }),
    )
  }

  #onKey = (event: KeyboardEvent) => {
    if (event.key === ' ' || event.key === 'Enter') {
      event.preventDefault()
      this.#onClick()
    }
  }
}

declare global {
  interface HTMLElementTagNameMap {
    'nui-toggle-button': NuiToggleButton
  }
}
