import '../styles/elements.css'
import { NuiButton } from './button'
import { NuiToggleButton } from './toggle-button'
import { NuiToggleGroup } from './toggle-group'

export function registerNuiElements() {
  if (!customElements.get('nui-button')) {
    customElements.define('nui-button', NuiButton)
  }
  if (!customElements.get('nui-toggle-button')) {
    customElements.define('nui-toggle-button', NuiToggleButton)
  }
  if (!customElements.get('nui-toggle-group')) {
    customElements.define('nui-toggle-group', NuiToggleGroup)
  }
}

export { NuiButton, NuiToggleButton, NuiToggleGroup }
