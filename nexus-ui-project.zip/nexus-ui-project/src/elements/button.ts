import { attachOpenShadow } from './shadow'

const css = `
:host {
  display: inline-flex;
  vertical-align: middle;
  width: fit-content;
  max-width: 100%;
  --nui-btn-color: var(--nui-primary-main);
  --nui-btn-tonal: var(--nui-primary-tonal);
  --nui-btn-height: 38px;
  --nui-btn-pad-x: 20px;
  --nui-btn-font-size: 15px;
  --nui-btn-radius: var(--nui-radius-md);
  --nui-btn-icon: 20px;
  --nui-btn-gap: 8px;
  --nui-btn-bg: var(--nui-btn-color);
  --nui-btn-fg: var(--nui-on-color);
  --nui-btn-border: transparent;
  --nui-btn-shadow: 0 2px 6px color-mix(in srgb, var(--nui-btn-color) 30%, transparent);
}
:host([block]) {
  display: flex;
  width: 100%;
}
:host([color='secondary']) {
  --nui-btn-color: var(--nui-secondary-main);
  --nui-btn-tonal: var(--nui-secondary-tonal);
}
:host([color='success']) {
  --nui-btn-color: var(--nui-success-main);
  --nui-btn-tonal: var(--nui-success-tonal);
}
:host([color='error']) {
  --nui-btn-color: var(--nui-error-main);
  --nui-btn-tonal: var(--nui-error-tonal);
}
:host([color='warning']) {
  --nui-btn-color: var(--nui-warning-main);
  --nui-btn-tonal: var(--nui-warning-tonal);
}
:host([color='info']) {
  --nui-btn-color: var(--nui-info-main);
  --nui-btn-tonal: var(--nui-info-tonal);
}
:host([size='lg']) {
  --nui-btn-height: 48px;
  --nui-btn-pad-x: 22px;
  --nui-btn-font-size: 16px;
  --nui-btn-radius: var(--nui-radius-lg);
  --nui-btn-icon: 22px;
  --nui-btn-gap: 10px;
}
:host([size='md']) {
  --nui-btn-height: 38px;
  --nui-btn-pad-x: 20px;
  --nui-btn-font-size: 15px;
  --nui-btn-radius: var(--nui-radius-md);
  --nui-btn-icon: 20px;
  --nui-btn-gap: 8px;
}
:host([size='sm']) {
  --nui-btn-height: 31px;
  --nui-btn-pad-x: 16px;
  --nui-btn-font-size: 13px;
  --nui-btn-radius: var(--nui-radius-md);
  --nui-btn-icon: 18px;
  --nui-btn-gap: 6px;
}
:host([size='xs']) {
  --nui-btn-height: 24px;
  --nui-btn-pad-x: 12px;
  --nui-btn-font-size: 13px;
  --nui-btn-radius: var(--nui-radius-sm);
  --nui-btn-icon: 16px;
  --nui-btn-gap: 4px;
}
:host([rounded]) {
  --nui-btn-radius: 999px;
}
:host([variant='contained']) {
  --nui-btn-bg: var(--nui-btn-color);
  --nui-btn-fg: var(--nui-on-color);
  --nui-btn-border: transparent;
  --nui-btn-shadow: 0 2px 6px color-mix(in srgb, var(--nui-btn-color) 30%, transparent);
}
:host([variant='tonal']) {
  --nui-btn-bg: var(--nui-btn-tonal);
  --nui-btn-fg: var(--nui-btn-color);
  --nui-btn-border: transparent;
  --nui-btn-shadow: none;
}
:host([variant='outlined']) {
  --nui-btn-bg: transparent;
  --nui-btn-fg: var(--nui-btn-color);
  --nui-btn-border: var(--nui-btn-color);
  --nui-btn-shadow: none;
}
:host([variant='text']) {
  --nui-btn-bg: transparent;
  --nui-btn-fg: var(--nui-btn-color);
  --nui-btn-border: transparent;
  --nui-btn-shadow: none;
}
.btn {
  appearance: none;
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--nui-btn-gap);
  box-sizing: border-box;
  width: 100%;
  min-height: var(--nui-btn-height);
  padding: 0 var(--nui-btn-pad-x);
  border: 1px solid var(--nui-btn-border, transparent);
  border-radius: var(--nui-btn-radius);
  background: var(--nui-btn-bg);
  color: var(--nui-btn-fg);
  box-shadow: var(--nui-btn-shadow);
  font-family: var(--nui-font-body);
  font-size: var(--nui-btn-font-size);
  font-weight: var(--nui-btn-weight, 500);
  letter-spacing: var(--nui-btn-letter-spacing, 0.43px);
  line-height: 1.2;
  white-space: nowrap;
  cursor: pointer;
  user-select: none;
  outline: none;
  transition: background 0.15s ease, box-shadow 0.15s ease, color 0.15s ease, border-color 0.15s ease;
}
:host([icon]) .btn {
  width: var(--nui-btn-height);
  min-width: var(--nui-btn-height);
  padding: 0;
}
.btn:focus-visible {
  box-shadow:
    var(--nui-btn-shadow),
    0 0 0 2px var(--nui-paper),
    0 0 0 4px var(--nui-btn-color);
}
:host([variant='contained']) .btn:hover:not(:disabled) {
  background: color-mix(in srgb, var(--nui-btn-color) 88%, #000);
  box-shadow: 0 4px 10px color-mix(in srgb, var(--nui-btn-color) 36%, transparent);
}
:host([variant='tonal']) .btn:hover:not(:disabled),
:host([variant='outlined']) .btn:hover:not(:disabled),
:host([variant='text']) .btn:hover:not(:disabled) {
  background: color-mix(in srgb, var(--nui-btn-color) 16%, transparent);
}
.btn:disabled {
  opacity: var(--nui-btn-disabled-opacity, 0.45);
  cursor: not-allowed;
  box-shadow: none;
  pointer-events: none;
}
.content {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--nui-btn-gap);
}
slot {
  display: contents;
}
::slotted(svg) {
  width: var(--nui-btn-icon);
  height: var(--nui-btn-icon);
  display: block;
  flex: none;
}
::slotted(.nui-i) {
  display: inline-flex;
  width: var(--nui-btn-icon);
  height: var(--nui-btn-icon);
  flex: none;
  line-height: 0;
}
::slotted(.nui-i svg) {
  width: 100%;
  height: 100%;
  display: block;
}
:host([loading]) .btn {
  color: var(--nui-btn-fg);
  pointer-events: none;
}
:host([loading]) .content {
  visibility: hidden;
}
:host([loading]) .btn::after {
  content: '';
  position: absolute;
  inset: 0;
  margin: auto;
  width: 1em;
  height: 1em;
  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: nui-spin 0.6s linear infinite;
}
@keyframes nui-spin {
  to { transform: rotate(360deg); }
}
`

export class NuiButton extends HTMLElement {
  static get observedAttributes() {
    return ['variant', 'color', 'size', 'disabled', 'loading', 'rounded', 'icon', 'block', 'type']
  }

  #button: HTMLButtonElement | null = null

  constructor() {
    super()
    const shadow = attachOpenShadow(this, css)
    this.#button = shadow.querySelector('button')
    if (!this.#button) {
      const button = document.createElement('button')
      button.className = 'btn'
      button.setAttribute('part', 'button')
      const content = document.createElement('span')
      content.className = 'content'
      content.append(document.createElement('slot'))
      button.append(content)
      shadow.append(button)
      this.#button = button
    }
  }

  connectedCallback() {
    if (!this.getAttribute('variant')) this.setAttribute('variant', 'contained')
    if (!this.getAttribute('color')) this.setAttribute('color', 'primary')
    if (!this.getAttribute('size')) this.setAttribute('size', 'md')
    if (!this.getAttribute('type')) this.setAttribute('type', 'button')
    this.#sync()
  }

  attributeChangedCallback() {
    this.#sync()
  }

  get variant() {
    return (this.getAttribute('variant') as 'contained' | 'tonal' | 'outlined' | 'text') || 'contained'
  }

  set variant(next: 'contained' | 'tonal' | 'outlined' | 'text') {
    this.setAttribute('variant', next)
  }

  get color() {
    return (
      (this.getAttribute('color') as 'primary' | 'secondary' | 'success' | 'error' | 'warning' | 'info') ||
      'primary'
    )
  }

  set color(next: 'primary' | 'secondary' | 'success' | 'error' | 'warning' | 'info') {
    this.setAttribute('color', next)
  }

  get size() {
    return (this.getAttribute('size') as 'xs' | 'sm' | 'md' | 'lg') || 'md'
  }

  set size(next: 'xs' | 'sm' | 'md' | 'lg') {
    this.setAttribute('size', next)
  }

  get type() {
    return (this.getAttribute('type') as 'button' | 'submit' | 'reset') || 'button'
  }

  set type(next: 'button' | 'submit' | 'reset') {
    this.setAttribute('type', next)
  }

  get disabled() {
    return this.hasAttribute('disabled')
  }

  set disabled(next: boolean) {
    this.toggleAttribute('disabled', next)
  }

  get loading() {
    return this.hasAttribute('loading')
  }

  set loading(next: boolean) {
    this.toggleAttribute('loading', next)
  }

  get rounded() {
    return this.hasAttribute('rounded')
  }

  set rounded(next: boolean) {
    this.toggleAttribute('rounded', next)
  }

  get icon() {
    return this.hasAttribute('icon')
  }

  set icon(next: boolean) {
    this.toggleAttribute('icon', next)
  }

  get block() {
    return this.hasAttribute('block')
  }

  set block(next: boolean) {
    this.toggleAttribute('block', next)
  }

  #sync() {
    const button = this.#button
    if (!button) return
    button.disabled = this.disabled || this.loading
    button.type = this.type
    button.setAttribute('aria-busy', this.loading ? 'true' : 'false')
    if (this.loading) button.setAttribute('aria-live', 'polite')
    else button.removeAttribute('aria-live')
  }
}

declare global {
  interface HTMLElementTagNameMap {
    'nui-button': NuiButton
  }
}
