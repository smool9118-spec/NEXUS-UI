export function attachOpenShadow(host: HTMLElement, css: string): ShadowRoot {
  const shadow = host.shadowRoot ?? host.attachShadow({ mode: 'open' })
  if (!shadow.querySelector('style[data-nui]')) {
    const style = document.createElement('style')
    style.dataset.nui = ''
    style.textContent = css
    shadow.prepend(style)
  }
  return shadow
}
