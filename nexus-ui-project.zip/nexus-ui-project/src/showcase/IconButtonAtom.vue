<script setup lang="ts">
import { reactive, ref } from 'vue'
import {
  UI_ICON_BUTTON_COLORS,
  UI_ICON_BUTTON_SHAPES,
  UI_ICON_BUTTON_SIZES,
  UI_ICON_BUTTON_VARIANTS,
  UiIconButton,
} from '../components'
import StarIcon from '../icons/StarIcon.vue'

const variantLabel: Record<(typeof UI_ICON_BUTTON_VARIANTS)[number], string> = {
  contained: 'Обычный · contained',
  outlined: 'Контур · outlined',
  standard: 'Текст · standard',
}

const sizeLabel: Record<(typeof UI_ICON_BUTTON_SIZES)[number], string> = {
  lg: 'Большой · lg · 48px',
  md: 'Средний · md · 38px',
  sm: 'Малый · sm · 30px',
}

const theme = ref<'light' | 'dark'>('light')
const matrixSize = ref<(typeof UI_ICON_BUTTON_SIZES)[number]>('md')
const matrixDisabled = ref(false)
const loading = ref(false)
const favorite = ref(false)
const clicks = ref(0)

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-primary-tonal': `${brand.primary}29`,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
  }
}

const propsDocs = [
  { name: 'variant', values: 'contained | outlined | standard', def: 'contained' },
  {
    name: 'color',
    values: 'default | primary | secondary | error | warning | info | success',
    def: 'default',
  },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'shape', values: 'circle | rounded', def: 'rounded' },
  { name: 'disabled', values: 'boolean', def: 'false' },
  { name: 'loading', values: 'boolean, спиннер вместо иконки', def: 'false' },
  { name: 'active', values: 'boolean, toggle / aria-pressed', def: '—' },
  { name: 'ariaLabel', values: 'string, обязательный', def: '—' },
  { name: 'слот default', values: 'SVG-иконка', def: '—' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { UiIconButton } from '@/components'",
  '</' + 'script>',
  '',
  '<template>',
  '  <UiIconButton variant="contained" color="primary" size="md" ariaLabel="В избранное">',
  '    <StarIcon />',
  '  </UiIconButton>',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<button class="ui-icon-btn ui-icon-btn--contained ui-icon-btn--primary ui-icon-btn--md ui-icon-btn--rounded" type="button" aria-label="В избранное">',
  '  <!-- svg -->',
  '</button>',
  '',
  '<!-- файлы компонента -->',
  'src/styles/tokens.css',
  'src/components/ui/IconButton/IconButton.scss',
  'src/components/ui/IconButton/IconButton.types.ts',
  'src/components/ui/IconButton/UiIconButton.vue',
].join('\n')

function onAction() {
  clicks.value += 1
}

function onLoadDemo() {
  loading.value = true
  window.setTimeout(() => {
    loading.value = false
    clicks.value += 1
  }, 900)
}
</script>

<template>
  <section class="intro">
    <h1>Icon Button</h1>
    <p>
      Кадр Figma «Кнопка с иконкой» · <code>UiIconButton</code>. Четыре файла: токены,
      SCSS, типы, Vue. Квадрат 1:1, иконка через слот, обязательный
      <code>ariaLabel</code>.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>Клик, Space/Enter, disabled, loading со спиннером, focus-visible, ripple, scale(0.98), aria-label / aria-pressed.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Цвет, размер квадрата, скругление, hover / active / dark. Не делать отдельную икон-кнопку под макет.</span>
    </div>
  </section>

  <section id="icon-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — IconButton.scss. Фронт — types + UiIconButton.vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="icon-variants" class="live section-title">
    <h3>Варианты</h3>
    <p class="hint">Обычный (contained), контур (outlined), текст (standard) — как в макете. Подложка в API нет.</p>
    <div class="btn-row">
      <UiIconButton
        v-for="variant in UI_ICON_BUTTON_VARIANTS"
        :key="variant"
        :variant="variant"
        color="primary"
        :ariaLabel="variantLabel[variant]"
      >
        <StarIcon :filled="variant === 'contained'" />
      </UiIconButton>
    </div>
  </section>

  <section id="icon-sizes" class="split section-title" aria-label="Размеры кнопки с иконкой">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg 48 · md 38 · sm 30, квадрат 1:1.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_ICON_BUTTON_SIZES" :key="`light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiIconButton
              v-for="variant in UI_ICON_BUTTON_VARIANTS"
              :key="`light-${size}-${variant}`"
              :variant="variant"
              :size="size"
              color="primary"
              :ariaLabel="`${variant} ${size}`"
            >
              <StarIcon :filled="variant === 'contained'" />
            </UiIconButton>
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же кнопка, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_ICON_BUTTON_SIZES" :key="`dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiIconButton
              v-for="variant in UI_ICON_BUTTON_VARIANTS"
              :key="`dark-${size}-${variant}`"
              :variant="variant"
              :size="size"
              color="primary"
              :ariaLabel="`${variant} ${size} dark`"
            >
              <StarIcon :filled="variant === 'contained'" />
            </UiIconButton>
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="icon-colors" class="live section-title">
    <h3>Цвета</h3>
    <p class="hint">default и палитра макета. Сетка 3 × 7.</p>
    <div class="filters">
      <label>
        size
        <select v-model="matrixSize">
          <option v-for="size in UI_ICON_BUTTON_SIZES" :key="size" :value="size">
            {{ sizeLabel[size] }}
          </option>
        </select>
      </label>
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
      <label>
        <input v-model="matrixDisabled" type="checkbox" />
        disabled
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <table class="matrix-table">
        <thead>
          <tr>
            <th></th>
            <th v-for="color in UI_ICON_BUTTON_COLORS" :key="color">{{ color }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="variant in UI_ICON_BUTTON_VARIANTS" :key="variant">
            <td>{{ variantLabel[variant] }}</td>
            <td v-for="color in UI_ICON_BUTTON_COLORS" :key="`${variant}-${color}`">
              <UiIconButton
                :variant="variant"
                :color="color"
                :size="matrixSize"
                :disabled="matrixDisabled"
                :ariaLabel="`${variant} ${color}`"
              >
                <StarIcon :filled="variant === 'contained'" />
              </UiIconButton>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="icon-shapes" class="live section-title">
    <h3>Форма</h3>
    <p class="hint">rounded — радиус из токенов размера. circle — круг.</p>
    <div class="btn-row">
      <template v-for="shape in UI_ICON_BUTTON_SHAPES" :key="shape">
        <UiIconButton
          v-for="variant in UI_ICON_BUTTON_VARIANTS"
          :key="`${shape}-${variant}`"
          :variant="variant"
          :shape="shape"
          color="primary"
          :ariaLabel="`${shape} ${variant}`"
        >
          <StarIcon :filled="variant === 'contained'" />
        </UiIconButton>
      </template>
    </div>
  </section>

  <section id="icon-states" class="live section-title">
    <h3>Состояния</h3>
    <p class="hint">
      Наведение, нажатие <code>scale(0.98)</code> + ripple, фокус-кольцо, disabled,
      loading (спиннер вместо иконки), toggle <code>active</code>.
    </p>
    <div class="btn-row">
      <UiIconButton color="primary" ariaLabel="Нажать" @click="onAction">
        <StarIcon filled />
      </UiIconButton>
      <UiIconButton variant="outlined" color="primary" ariaLabel="Контур" @click="onAction">
        <StarIcon />
      </UiIconButton>
      <UiIconButton
        variant="standard"
        color="primary"
        :loading="loading"
        ariaLabel="Загрузка"
        @click="onLoadDemo"
      >
        <StarIcon />
      </UiIconButton>
      <UiIconButton variant="contained" color="primary" disabled ariaLabel="Отключено">
        <StarIcon filled />
      </UiIconButton>
      <UiIconButton
        variant="standard"
        color="error"
        :active="favorite"
        ariaLabel="В избранное"
        @update:active="favorite = $event"
      >
        <StarIcon :filled="favorite" />
      </UiIconButton>
      <p class="value-pill">clicks: <b>{{ clicks }}</b> · favorite: <b>{{ favorite }}</b></p>
    </div>
  </section>

  <section id="icon-theme" class="live section-title">
    <h3>Тема Light / Dark</h3>
    <p class="hint">Переключатель меняет <code>data-theme</code> у панели. Цвета только из токенов.</p>
    <div class="filters">
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <div class="btn-row">
        <UiIconButton
          v-for="variant in UI_ICON_BUTTON_VARIANTS"
          :key="`theme-${variant}`"
          :variant="variant"
          color="primary"
          :ariaLabel="`Тема ${variant}`"
        >
          <StarIcon :filled="variant === 'contained'" />
        </UiIconButton>
        <UiIconButton variant="contained" color="error" ariaLabel="Ошибка">
          <StarIcon filled />
        </UiIconButton>
        <UiIconButton variant="outlined" color="success" ariaLabel="Успех">
          <StarIcon />
        </UiIconButton>
        <UiIconButton variant="standard" color="warning" ariaLabel="Внимание">
          <StarIcon />
        </UiIconButton>
        <UiIconButton variant="contained" color="primary" loading ariaLabel="Загрузка">
          <StarIcon filled />
        </UiIconButton>
        <UiIconButton variant="outlined" color="primary" disabled ariaLabel="Отключено">
          <StarIcon />
        </UiIconButton>
      </div>
    </div>
  </section>

  <section id="icon-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Разметка и клик те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="24" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiIconButton size="lg" color="primary" ariaLabel="Обычный">
        <StarIcon filled />
      </UiIconButton>
      <UiIconButton size="lg" variant="outlined" color="primary" ariaLabel="Контур">
        <StarIcon />
      </UiIconButton>
      <UiIconButton size="lg" variant="standard" color="primary" ariaLabel="Текст">
        <StarIcon />
      </UiIconButton>
      <UiIconButton size="lg" color="primary" shape="circle" ariaLabel="Круг">
        <StarIcon filled />
      </UiIconButton>
    </div>
  </section>

  <section id="icon-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">
      Фронт берёт <code>UiIconButton</code> и типы из <code>IconButton.types.ts</code>.
      Иконка — дефолтный слот. <code>ariaLabel</code> обязателен.
    </p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="icon-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">
      Верстальщик подключает <code>tokens.css</code> и <code>IconButton.scss</code>.
      Те же классы, что рисует <code>UiIconButton</code>.
    </p>
    <div class="btn-row" style="margin-bottom: 16px">
      <button
        class="ui-icon-btn ui-icon-btn--contained ui-icon-btn--primary ui-icon-btn--md ui-icon-btn--rounded"
        type="button"
        aria-label="Обычный"
      >
        <span class="ui-icon-btn__icon"><StarIcon filled /></span>
      </button>
      <button
        class="ui-icon-btn ui-icon-btn--outlined ui-icon-btn--primary ui-icon-btn--md ui-icon-btn--rounded"
        type="button"
        aria-label="Контур"
      >
        <span class="ui-icon-btn__icon"><StarIcon /></span>
      </button>
      <button
        class="ui-icon-btn ui-icon-btn--standard ui-icon-btn--primary ui-icon-btn--md ui-icon-btn--rounded"
        type="button"
        aria-label="Текст"
      >
        <span class="ui-icon-btn__icon"><StarIcon /></span>
      </button>
    </div>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
