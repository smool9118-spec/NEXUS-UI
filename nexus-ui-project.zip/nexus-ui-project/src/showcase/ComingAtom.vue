<script setup lang="ts">
import type { AtomItem } from './atoms'

defineProps<{ atom: AtomItem }>()
</script>

<template>
  <section class="intro">
    <h1>{{ atom.name }}</h1>
    <p>
      Кадр Figma «{{ atom.figma }}». Тег <code>{{ atom.tag }}</code> ещё не
      собран. Слот в каталоге уже есть — документация появится в этой статье.
    </p>
  </section>
  <section class="live">
    <h3>В очереди</h3>
    <p class="hint">
      Тот же каркас, что у Button и Toggle: токены, custom element, тонкая Vue-обёртка.
      Сниппет Vue и чистый HTML появятся в этой колонке, когда кирпич будет готов.
    </p>
  </section>
  <section class="usage">
    <h3>Чистый HTML</h3>
    <p class="hint">Тег будет <code>{{ atom.tag }}</code>. Пока страница-заглушка.</p>
  </section>
</template>
