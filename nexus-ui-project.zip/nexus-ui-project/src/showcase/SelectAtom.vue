<script setup lang="ts">
import { reactive, ref } from 'vue'
import { UI_SELECT_SIZES, UiSelect, type UiSelectOption } from '../components'
import SearchIcon from '../icons/SearchIcon.vue'

const cities: UiSelectOption[] = [
  { label: 'Москва', value: 'msk' },
  { label: 'Санкт-Петербург', value: 'spb' },
  { label: 'Казань', value: 'kzn' },
  { label: 'Новосибирск', value: 'nsk' },
  { label: 'Екатеринбург', value: 'ekb' },
]

const grouped: UiSelectOption[] = [
  { label: 'Москва', value: 'msk', group: 'Города' },
  { label: 'Казань', value: 'kzn', group: 'Города' },
  { label: 'Сочи', value: 'sochi', group: 'Города' },
  { label: 'Дизайн', value: 'design', group: 'Отделы' },
  { label: 'Разработка', value: 'dev', group: 'Отделы' },
  { label: 'Поддержка', value: 'support', group: 'Отделы', disabled: true },
]

const fruits: UiSelectOption[] = [
  { label: 'Яблоко', value: 'apple' },
  { label: 'Груша', value: 'pear' },
  { label: 'Вишня', value: 'cherry' },
  { label: 'Персик', value: 'peach' },
  { label: 'Манго', value: 'mango' },
]

const theme = ref<'light' | 'dark'>('light')
const outlined = ref<string | number | null>('msk')
const filled = ref<string | number | null>('msk')
const standard = ref<string | number | null>('msk')
const single = ref<string | number | null>(null)
const chips = ref<(string | number)[]>(['apple', 'pear'])
const search = ref<string | number | null>(null)
const groupedValue = ref<string | number | null>('design')
const errorValue = ref<string | number | null>(null)
const brandValue = ref<string | number | null>('msk')

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
    '--ui-radius-md': radius,
  }
}

const propsDocs = [
  { name: 'modelValue / v-model', values: 'string | number | Array | null', def: 'null' },
  { name: 'options', values: 'SelectOption[] { label, value, disabled?, group?, icon? }', def: '[]' },
  { name: 'multiple', values: 'boolean, мультивыбор', def: 'false' },
  { name: 'chips', values: 'boolean, теги выбранных при multiple', def: 'false' },
  { name: 'searchable', values: 'boolean, фильтр по списку', def: 'false' },
  { name: 'clearable / loading', values: 'boolean', def: 'false' },
  { name: 'variant', values: 'outlined | filled | standard', def: 'outlined' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'color', values: 'primary | secondary | error | warning | info | success', def: 'primary' },
  { name: 'label / placeholder / helperText', values: 'string', def: '—' },
  { name: 'error / errorMessage / disabled / required', values: 'boolean / string', def: 'false' },
  { name: 'слот option / selected / prepend / empty', values: 'кастом строки, значения, иконка, пустой список', def: '—' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { ref } from 'vue'",
  "import { UiSelect } from '@/components'",
  '',
  "const city = ref<string | number | null>(null)",
  "const cities = [",
  "  { label: 'Москва', value: 'msk' },",
  "  { label: 'Казань', value: 'kzn' },",
  ']',
  '</' + 'script>',
  '',
  '<template>',
  '  <UiSelect v-model="city" :options="cities" label="Город" clearable />',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<div class="ui-select ui-select--outlined">',
  '  <div class="ui-field ui-field--outlined ui-field--md has-label is-filled is-floated">',
  '    <div class="ui-select__anchor">',
  '      <div class="ui-field__control" role="combobox" aria-expanded="true" aria-haspopup="listbox">…</div>',
  '      <div class="ui-select__menu" role="listbox">',
  '        <ul class="ui-select__list">',
  '          <li class="ui-select__option is-selected" role="option" aria-selected="true">Москва</li>',
  '        </ul>',
  '      </div>',
  '    </div>',
  '  </div>',
  '</div>',
].join('\n')
</script>

<template>
  <section class="intro">
    <h1>Select</h1>
    <p>
      Кадр Figma «Список выбора» · <code>UiSelect</code>. Триггер визуально совпадает с
      <code>UiTextField</code>, сверху — список, поиск, мультивыбор и чипсы.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>v-model, клик снаружи, Escape, стрелки / Enter / Space, a11y combobox/listbox, multiple не закрывает меню.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Цвета поля, тень меню (--ui-shadow-lg), поверхность (--ui-surface), скругление (--ui-radius-md).</span>
    </div>
  </section>

  <section id="select-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — Select.scss. Фронт — types + UiSelect.vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="select-variants" class="live section-title">
    <h3>Варианты</h3>
    <p class="hint">Контур (outlined), заливка (filled), линия (standard) — как у текстового поля.</p>
    <div class="field-demo">
      <UiSelect v-model="outlined" :options="cities" variant="outlined" label="Подпись" helper-text="Подсказка" />
      <UiSelect v-model="filled" :options="cities" variant="filled" label="Подпись" helper-text="Подсказка" />
      <UiSelect v-model="standard" :options="cities" variant="standard" label="Подпись" helper-text="Подсказка" />
    </div>
  </section>

  <section id="select-sizes" class="split section-title" aria-label="Размеры списка выбора">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg · md · sm, те же высоты, что у Text Field.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame field-sizes">
          <div v-for="size in UI_SELECT_SIZES" :key="`light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiSelect :size="size" :options="cities" model-value="msk" label="Подпись" helper-text="Подсказка" />
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же поле, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame field-sizes">
          <div v-for="size in UI_SELECT_SIZES" :key="`dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiSelect :size="size" :options="cities" model-value="msk" label="Подпись" helper-text="Подсказка" />
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="select-single" class="live section-title">
    <h3>Одиночный выбор</h3>
    <p class="hint">Клик или Enter выбирает значение и закрывает список. Стрелка справа поворачивается.</p>
    <div class="field-demo">
      <UiSelect
        v-model="single"
        :options="cities"
        label="Город"
        placeholder="Выберите город"
        helper-text="Один пункт"
        clearable
      >
        <template #prepend><SearchIcon /></template>
      </UiSelect>
    </div>
    <p class="mask-value">v-model: <b>{{ single ?? '∅' }}</b></p>
  </section>

  <section id="select-chips" class="live section-title">
    <h3>Мультивыбор с чипсами</h3>
    <p class="hint"><code>multiple</code> + <code>chips</code>. Список не закрывается после клика. Крестик на теге снимает значение.</p>
    <div class="field-demo">
      <UiSelect
        v-model="chips"
        :options="fruits"
        multiple
        chips
        clearable
        label="Фрукты"
        helper-text="Несколько значений"
      />
    </div>
    <p class="mask-value">v-model: <b>{{ chips.join(', ') || '∅' }}</b></p>
  </section>

  <section id="select-search" class="live section-title">
    <h3>Поиск</h3>
    <p class="hint"><code>searchable</code> фильтрует список. Пустой результат — «Ничего не найдено».</p>
    <div class="field-demo">
      <UiSelect
        v-model="search"
        :options="cities"
        searchable
        clearable
        label="Город"
        placeholder="Начните вводить"
        helper-text="Фильтр по названию"
      />
    </div>
  </section>

  <section id="select-groups" class="live section-title">
    <h3>Группы</h3>
    <p class="hint">Опция с <code>group</code> попадает под заголовок. Disabled пункт не выбирается.</p>
    <div class="field-demo">
      <UiSelect
        v-model="groupedValue"
        :options="grouped"
        label="Назначение"
        helper-text="optgroup"
      />
    </div>
  </section>

  <section id="select-states" class="live section-title">
    <h3>Состояния</h3>
    <p class="hint">Loading со спиннером, disabled, ошибка. Светлая и тёмная тема.</p>
    <div class="filters">
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <div class="field-demo">
        <UiSelect
          :options="cities"
          label="Загрузка"
          helper-text="Подсказка"
          loading
        />
        <UiSelect
          model-value="msk"
          :options="cities"
          label="Отключено"
          helper-text="Подсказка"
          disabled
        />
        <UiSelect
          v-model="errorValue"
          :options="cities"
          label="Город"
          error-message="Выберите значение"
        />
        <UiSelect
          model-value="msk"
          :options="cities"
          label="Успех"
          helper-text="Подсказка"
          color="success"
        />
      </div>
    </div>
  </section>

  <section id="select-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Список и клавиатура те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="24" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiSelect v-model="brandValue" :options="cities" label="Подпись" helper-text="Подсказка" />
    </div>
  </section>

  <section id="select-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">Фронт берёт <code>UiSelect</code> и типы из <code>Select.types.ts</code>.</p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="select-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">Верстальщик подключает <code>tokens.css</code>, <code>TextField.scss</code> и <code>Select.scss</code>.</p>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
