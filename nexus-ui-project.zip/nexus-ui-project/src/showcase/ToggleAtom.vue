<script setup lang="ts">
import { reactive, ref } from 'vue'
import AlignIcon from '../icons/AlignIcon.vue'
import NuiToggleButton from '../vue/NuiToggleButton.vue'
import NuiToggleGroup from '../vue/NuiToggleGroup.vue'

const align = ref('left')

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
    '--nui-toggle-radius': radius,
    '--nui-toggle-btn-radius': radius,
  }
}

const propsDocs = [
  { name: 'value / v-model', values: 'строка выбранной кнопки', def: '""' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'disabled', values: 'boolean', def: 'false' },
]

const buttonDocs = [
  { name: 'value', values: 'значение, которое попадёт в группу', def: '—' },
  { name: 'disabled', values: 'пункт недоступен', def: 'false' },
  { name: 'слот', values: 'иконка или текст', def: '—' },
]

function onHtmlChange(event: Event) {
  const custom = event as CustomEvent<{ value: string }>
  align.value = custom.detail.value
}

const vueSnippet = `<NuiToggleGroup v-model="align" size="md">
  <NuiToggleButton value="left">…</NuiToggleButton>
  <NuiToggleButton value="center">…</NuiToggleButton>
</NuiToggleGroup>`

const htmlSnippet = `<nui-toggle-group value="left" size="md">
  <nui-toggle-button value="left">…</nui-toggle-button>
  <nui-toggle-button value="center">…</nui-toggle-button>
</nui-toggle-group>`
</script>

<template>
  <section class="intro">
    <h1>Toggle</h1>
    <p>
      Кадр Figma «Кнопка-переключатель». Связанные параметры, одно выбранное
      значение. Теги <code>nui-toggle-group</code> /
      <code>nui-toggle-button</code>.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>Выбор одного значения, стрелки, Space/Enter, radiogroup / ARIA.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами</strong>
      <span>Цвета, радиусы, фон выбранной кнопки. Верстальщик не лезет в JS.</span>
    </div>
  </section>

  <section id="toggle-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Группа</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
    <p class="hint" style="margin-top: 20px">Кнопка в группе</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Назначение</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in buttonDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="toggle-sizes" class="split section-title" aria-label="Размеры переключателя">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">Кнопки-переключатели объединяют связанные параметры.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div class="size-line">
            <span>lg</span>
            <NuiToggleGroup v-model="align" size="lg" aria-label="Выравнивание, большой">
              <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
              <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
              <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
              <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
            </NuiToggleGroup>
          </div>
          <div class="size-line">
            <span>md</span>
            <NuiToggleGroup v-model="align" size="md" aria-label="Выравнивание, средний">
              <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
              <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
              <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
              <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
            </NuiToggleGroup>
          </div>
          <div class="size-line">
            <span>sm</span>
            <NuiToggleGroup v-model="align" size="sm" aria-label="Выравнивание, малый">
              <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
              <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
              <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
              <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
            </NuiToggleGroup>
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же группа, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div class="size-line">
            <span>lg</span>
            <NuiToggleGroup v-model="align" size="lg" aria-label="Тёмная большая">
              <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
              <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
              <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
              <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
            </NuiToggleGroup>
          </div>
          <div class="size-line">
            <span>md</span>
            <NuiToggleGroup v-model="align" size="md" aria-label="Тёмная средняя">
              <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
              <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
              <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
              <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
            </NuiToggleGroup>
          </div>
          <div class="size-line">
            <span>sm</span>
            <NuiToggleGroup v-model="align" size="sm" aria-label="Тёмная малая">
              <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
              <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
              <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
              <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
            </NuiToggleGroup>
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="toggle-live" class="live section-title">
    <h3>Vue 3</h3>
    <p class="hint">v-model общий для всех размеров и тем — логика одна.</p>
    <div class="live-row">
      <NuiToggleGroup v-model="align" size="md" aria-label="Живой пример">
        <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
        <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
        <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
        <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
      </NuiToggleGroup>
      <p class="value-pill">value: <b>{{ align }}</b> · стрелки, когда фокус внутри группы</p>
    </div>
  </section>

  <section id="toggle-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Разметка и клик те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="24" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <NuiToggleGroup v-model="align" size="lg" aria-label="Токены">
        <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
        <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
        <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
        <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
      </NuiToggleGroup>
    </div>
  </section>

  <section id="toggle-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">Обёртки <code>NuiToggleGroup</code> / <code>NuiToggleButton</code> с <code>v-model</code>.</p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="toggle-html" class="usage section-title">
    <h3>Чистый HTML</h3>
    <p class="hint">
      Без Vue. Теги <code>nui-toggle-group</code> / <code>nui-toggle-button</code>, событие
      <code>change</code>.
    </p>
    <div class="live-row" style="margin-bottom: 16px">
      <nui-toggle-group :value="align" size="md" aria-label="HTML-группа" @change="onHtmlChange">
        <nui-toggle-button value="left">L</nui-toggle-button>
        <nui-toggle-button value="center">C</nui-toggle-button>
        <nui-toggle-button value="right">R</nui-toggle-button>
        <nui-toggle-button value="justify">J</nui-toggle-button>
      </nui-toggle-group>
    </div>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
