<script setup lang="ts">
import { reactive, ref } from 'vue'
import {
  UI_SWITCH_COLORS,
  UI_SWITCH_PLACEMENTS,
  UI_SWITCH_SIZES,
  UiSwitch,
} from '../components'

const theme = ref<'light' | 'dark'>('light')
const live = ref(true)
const loadingOn = ref(true)
const errorOn = ref(false)
const iconsOn = ref(true)
const thumbOn = ref(true)

const brand = reactive({
  primary: '#7367f0',
})

function brandStyle() {
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-primary-tonal': `${brand.primary}29`,
  }
}

const propsDocs = [
  { name: 'modelValue / v-model', values: 'boolean', def: 'false' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'color', values: 'primary | secondary | error | warning | info | success', def: 'primary' },
  { name: 'loading', values: 'boolean, спиннер в ползунке, блок переключения', def: 'false' },
  { name: 'disabled', values: 'boolean', def: 'false' },
  { name: 'label', values: 'string', def: '—' },
  { name: 'labelPlacement', values: 'end | start | top | bottom', def: 'end' },
  { name: 'helperText', values: 'string', def: '—' },
  { name: 'error / errorMessage', values: 'boolean / string', def: 'false / —' },
  { name: 'slot thumb-icon', values: 'иконка внутри ползунка', def: '—' },
  { name: 'slot track-on / track-off', values: 'мини-иконки в треке', def: '—' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { ref } from 'vue'",
  "import { UiSwitch } from '@/components'",
  '',
  'const on = ref(true)',
  '</' + 'script>',
  '',
  '<template>',
  '  <UiSwitch v-model="on" label="Уведомления" />',
  '  <UiSwitch v-model="on" loading label="Сохранение" />',
  '  <UiSwitch v-model="on" label="С иконками">',
  '    <template #track-on>✓</template>',
  '    <template #track-off>×</template>',
  '    <template #thumb-icon>★</template>',
  '  </UiSwitch>',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<div class="ui-switch ui-switch--md ui-switch--primary ui-switch--end is-on">',
  '  <span class="ui-switch__control">',
  '    <button class="ui-switch__hit" type="button" role="switch" aria-checked="true">',
  '      <span class="ui-switch__track"></span>',
  '      <span class="ui-switch__thumb"><span class="ui-switch__knob"></span></span>',
  '    </button>',
  '  </span>',
  '  <span class="ui-switch__copy"><label class="ui-switch__label">Метка</label></span>',
  '</div>',
].join('\n')
</script>

<template>
  <section class="intro">
    <h1>Switch</h1>
    <p>
      Кадр Figma «Переключатель» · <code>UiSwitch</code>. Тумблер вкл/выкл, скольжение ползунка,
      <code>role="switch"</code>.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>
        role="switch", aria-checked, Space/Enter, aria-busy при loading, блокировка при disabled и
        loading.
      </span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Длина трека, диаметр ползунка, ореол, цвет заливки. Не копировать кружок под макет.</span>
    </div>
  </section>

  <section id="switch-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — Switch.scss. Фронт — types + UiSwitch.vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="switch-sizes" class="split section-title" aria-label="Размеры тумблера">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg · md · sm. В макете md — трек 30×18, ползунок 14px.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_SWITCH_SIZES" :key="`light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiSwitch :size="size" :model-value="true" label="Метка" />
            <UiSwitch :size="size" :model-value="false" label="Метка" />
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же поле, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_SWITCH_SIZES" :key="`dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiSwitch :size="size" :model-value="true" label="Метка" />
            <UiSwitch :size="size" :model-value="false" label="Метка" />
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="switch-colors" class="live section-title">
    <h3>Цвета</h3>
    <p class="hint">Основной, вторичный, ошибка, внимание, инфо, успех.</p>
    <div class="filters">
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <div class="check-row">
        <UiSwitch
          v-for="color in UI_SWITCH_COLORS"
          :key="color"
          :color="color"
          :model-value="true"
          :label="color"
        />
      </div>
    </div>
  </section>

  <section id="switch-placement" class="live section-title">
    <h3>Позиция подписи</h3>
    <p class="hint"><code>labelPlacement</code>: end, start, top, bottom.</p>
    <div class="check-row">
      <UiSwitch
        v-for="place in UI_SWITCH_PLACEMENTS"
        :key="place"
        :label-placement="place"
        :model-value="true"
        :label="place"
      />
    </div>
  </section>

  <section id="switch-states" class="live section-title">
    <h3>Состояния</h3>
    <p class="hint">Выкл, вкл, disabled, loading, ошибка. Наведение и фокус с клавиатуры — живые.</p>
    <div class="check-row">
      <UiSwitch v-model="live" label="Интерактив" helper-text="Space или Enter" />
      <UiSwitch :model-value="false" label="Выкл." />
      <UiSwitch :model-value="true" label="Вкл." />
      <UiSwitch :model-value="false" disabled label="Выкл. (недост.)" />
      <UiSwitch :model-value="true" disabled label="Вкл. (недост.)" />
      <UiSwitch v-model="loadingOn" loading label="Сохранение" />
      <UiSwitch
        v-model="errorOn"
        label="Согласие"
        error-message="Нужно подтвердить"
      />
    </div>
    <p class="mask-value">v-model: <b>{{ live ? 'true' : 'false' }}</b></p>
  </section>

  <section id="switch-icons" class="live section-title">
    <h3>Иконки внутри тумблера</h3>
    <p class="hint">
      Слоты <code>track-on</code>, <code>track-off</code> и <code>thumb-icon</code>. При
      <code>loading</code> вместо иконки ползунка — спиннер.
    </p>
    <div class="check-row">
      <UiSwitch v-model="iconsOn" label="Трек">
        <template #track-on>
          <svg viewBox="0 0 12 12" fill="none" aria-hidden="true">
            <path
              d="M2.5 6.2L5 8.7L9.5 3.5"
              stroke="currentColor"
              stroke-width="1.6"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </template>
        <template #track-off>
          <svg viewBox="0 0 12 12" fill="none" aria-hidden="true">
            <path
              d="M3.5 3.5L8.5 8.5M8.5 3.5L3.5 8.5"
              stroke="currentColor"
              stroke-width="1.6"
              stroke-linecap="round"
            />
          </svg>
        </template>
      </UiSwitch>
      <UiSwitch v-model="thumbOn" label="Ползунок">
        <template #thumb-icon>
          <svg viewBox="0 0 12 12" fill="none" aria-hidden="true">
            <path
              d="M6 2.2L7.1 4.6L9.8 4.9L7.8 6.7L8.4 9.4L6 8.1L3.6 9.4L4.2 6.7L2.2 4.9L4.9 4.6L6 2.2Z"
              fill="currentColor"
            />
          </svg>
        </template>
      </UiSwitch>
      <UiSwitch :model-value="true" loading label="Loading + слот">
        <template #thumb-icon>
          <svg viewBox="0 0 12 12" fill="none" aria-hidden="true">
            <path
              d="M6 2.2L7.1 4.6L9.8 4.9L7.8 6.7L8.4 9.4L6 8.1L3.6 9.4L4.2 6.7L2.2 4.9L4.9 4.6L6 2.2Z"
              fill="currentColor"
            />
          </svg>
        </template>
      </UiSwitch>
    </div>
  </section>

  <section id="switch-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Клик и клавиатура те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiSwitch :model-value="true" label="Метка" />
      <UiSwitch :model-value="false" label="Метка" />
    </div>
  </section>

  <section id="switch-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">Фронт берёт <code>UiSwitch</code> и типы из <code>Switch.types.ts</code>.</p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="switch-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">Верстальщик подключает <code>tokens.css</code> и <code>Switch.scss</code>.</p>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
