<script setup lang="ts">
const layers = [
  {
    title: 'Слой токенов',
    file: 'tokens.css',
    question: 'В каком бренде или теме мы сейчас находимся?',
    body: 'Переменные цветов, шрифтов, скруглений и отступов. Светлая и тёмная тема, палитра нового проекта.',
  },
  {
    title: 'Слой вёрстки',
    file: '[Component].scss',
    question: 'Как выглядит кнопка размера MD в состоянии hover?',
    body: 'Правила внешнего вида по variant, size, color и state. Без JS и без бизнес-логики.',
  },
  {
    title: 'Слой логики',
    file: 'types.ts + Ui*.vue',
    question: 'Что происходит при взаимодействии с элементом?',
    body: 'Поведение, клики, фокус, disabled / loading и доступность. Типизированный API для фронта.',
  },
]

const contract = [
  { name: 'variant', values: 'contained (залитая), outlined (контурная), text (без рамки и фона)' },
  { name: 'size', values: 'sm, md, lg — высота, горизонтальные паддинги, размер шрифта и иконки' },
  { name: 'color', values: 'primary, secondary, error, warning, info, success' },
  { name: 'icons', values: 'leftIcon, rightIcon, iconOnly (квадратная кнопка только с иконкой)' },
  { name: 'states', values: 'default, hover, active, focus, disabled, loading' },
]
</script>

<template>
  <section class="intro">
    <h1>Регламент работы с дизайн-системой и UI-библиотекой</h1>
    <p>
      Единый подход к созданию, стилизации и использованию компонентов. Дизайнеры быстро
      адаптируют визуал под новый проект, верстальщики изолированно собирают стили и состояния
      без риска сломать JS, фронтенд использует готовые «умные» компоненты как конструктор и не
      тратит время на CSS.
    </p>
  </section>

  <section id="home-layers" class="section-title">
    <h3 class="guide-h">1. Суть подхода: архитектура трёх слоёв</h3>
    <p class="hint">
      Отказываемся от монолитных компонентов, где цвета, вёрстка и бизнес-логика смешаны в одном
      файле. Каждый UI-элемент (кнопка, инпут, селект, модалка) делится на три независимых слоя.
    </p>
    <div class="guide-layers">
      <article v-for="layer in layers" :key="layer.title" class="guide-card">
        <p class="guide-kicker">{{ layer.file }}</p>
        <strong>{{ layer.title }}</strong>
        <span>{{ layer.body }}</span>
        <em>{{ layer.question }}</em>
      </article>
    </div>
    <p class="hint">
      В репозитории это четыре файла атома: общий <code>tokens.css</code>, изолированный
      <code>[Component].scss</code>, контракт <code>[Component].types.ts</code> и логика
      <code>Ui[Component].vue</code>. Правило зафиксировано в <code>.cursorrules</code>.
    </p>
  </section>

  <section id="home-roles" class="live section-title">
    <h3>2. Зоны ответственности и инструкции по ролям</h3>
    <p class="hint">
      Три роли смотрят в разные файлы одного кирпича. Нельзя склеивать вёрстку, типы и логику в
      одном <code>.vue</code>, копировать внутренний DOM или делать «версию кнопки» под макет.
    </p>
  </section>

  <section id="home-designer" class="live section-title">
    <h3>Для дизайнеров (Figma → токены)</h3>
    <p class="hint">
      Задача — проектировать систему, которой можно управлять через переменные, а не перерисовывать
      вручную под каждый проект.
    </p>
    <ul class="guide-list">
      <li>
        <strong>Единый нейминг свойств.</strong> Названия свойств и вариантов в Figma (Variant, Size,
        Color, State) должны на 100% совпадать с названиями параметров (пропсов) в коде.
      </li>
      <li>
        <strong>Токены вместо фиксированных цветов.</strong> В компонентах запрещено использовать
        «сырые» HEX-цвета. Только семантические переменные: primary, secondary, error, warning, info,
        success, фоны и текст для Light / Dark тем.
      </li>
      <li>
        <strong>Матрица состояний.</strong> Для каждого интерактивного элемента обязательно
        отрисовываются Default, Hover, Active/Pressed, Focus, Disabled, Loading.
      </li>
      <li>
        <strong>Новый проект.</strong> Структура компонентов не трогается — меняются только значения
        в таблице переменных: палитра, радиусы скругления, базовый шрифт.
      </li>
    </ul>
  </section>

  <section id="home-layout" class="live section-title">
    <h3>Для верстальщика (слой стилей и вариантов)</h3>
    <p class="hint">
      Задача — перенести визуальную матрицу из Figma в изолированные таблицы стилей, не погружаясь в
      бизнес-логику приложения.
    </p>
    <ul class="guide-list">
      <li>
        <strong>Работа в песочнице стилей.</strong> Только файлы токенов
        (<code>tokens.css</code> / theme) и стилевой файл компонента (<code>*.scss</code>). Без JS.
      </li>
      <li>
        <strong>Никакого хардкода.</strong> Цвета, тени, скругления и отступы — только через
        <code>var(--token-name)</code>. Смена светлой темы на тёмную перекрашивает компонент без правок
        в его коде.
      </li>
      <li>
        <strong>Сборка вариантов.</strong> Классы для всех комбинаций из Figma: визуальный тип
        (variant: заливка / контур / текст), размерная сетка (size: sm, md, lg), цветовая схема
        (color: primary, error, success и т.д.), псевдоклассы
        (<code>:hover</code>, <code>:active</code>, <code>:focus-visible</code>, <code>:disabled</code>).
      </li>
      <li>
        <strong>Защита от переполнения.</strong> Длинный текст, иконки слева/справа и работа внутри
        флекс/грид-контейнеров.
      </li>
    </ul>
  </section>

  <section id="home-frontend" class="live section-title">
    <h3>Для фронтенд-разработчика (слой логики и API)</h3>
    <p class="hint">
      Задача — оживить компонент, обеспечить строгую типизацию и удобный интерфейс подключения в
      проект.
    </p>
    <ul class="guide-list">
      <li>
        <strong>Фокус на поведении.</strong> Работа в логическом файле компонента
        (<code>Ui*.vue</code> и <code>*.types.ts</code>), подключая уже готовые стили от верстальщика.
      </li>
      <li>
        <strong>Чистый API (пропсы).</strong> Типизированный интерфейс повторяет настройки из Figma и
        добавляет технические свойства: onClick, type, disabled, loading, слоты, v-model.
      </li>
      <li>
        <strong>Логика состояний и a11y.</strong>
        Если передан <code>loading</code> — компонент показывает спиннер, блокирует повторный клик и
        выставляет <code>aria-busy="true"</code>. Фокус с клавиатуры: Tab, Enter, Space, Escape для
        закрытия списков и модалок.
      </li>
      <li>
        <strong>Никаких инлайн-стилей на проектах.</strong> Запрещено перебивать стили компонента
        через внешние классы-костыли. Нужен новый вариант отображения — он добавляется в
        дизайн-систему.
      </li>
    </ul>
  </section>

  <section id="home-contract" class="live section-title">
    <h3>3. Контракт компонента (на примере кнопки)</h3>
    <p class="hint">
      Чтобы все три роли понимали друг друга без лишних созвонов, перед вёрсткой каждого элемента
      фиксируется короткий паспорт (контракт).
    </p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Свойство</th>
            <th>Значения</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in contract" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>
