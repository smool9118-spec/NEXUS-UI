<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import {
  UI_CHECKBOX_COLORS,
  UI_CHECKBOX_PLACEMENTS,
  UI_CHECKBOX_SIZES,
  UiCheckbox,
} from '../components'

const theme = ref<'light' | 'dark'>('light')
const live = ref(true)
const errorOn = ref(false)
const fruits = [
  { label: 'Яблоко', value: 'apple' },
  { label: 'Груша', value: 'pear' },
  { label: 'Вишня', value: 'cherry' },
]
const selected = ref<(string | number)[]>(['apple'])
const allValues = fruits.map((item) => item.value)
const allChecked = computed(() => allValues.every((value) => selected.value.includes(value)))
const someChecked = computed(
  () => selected.value.length > 0 && !allChecked.value,
)

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-primary-tonal': `${brand.primary}29`,
    '--nui-radius-sm': radius,
    '--ui-check-radius': radius,
  }
}

function onSelectAll(next: boolean | Array<string | number>) {
  selected.value = next ? [...allValues] : []
}

const propsDocs = [
  { name: 'modelValue / v-model', values: 'boolean | Array<string | number>', def: 'false' },
  { name: 'value', values: 'string | number, для режима массива', def: '—' },
  { name: 'indeterminate', values: 'boolean, частичный выбор (минус)', def: 'false' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'color', values: 'primary | secondary | error | warning | info | success', def: 'primary' },
  { name: 'label', values: 'string', def: '—' },
  { name: 'labelPlacement', values: 'end | start | top | bottom', def: 'end' },
  { name: 'helperText', values: 'string', def: '—' },
  { name: 'error / errorMessage', values: 'boolean / string', def: 'false / —' },
  { name: 'disabled / required', values: 'boolean', def: 'false' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { ref } from 'vue'",
  "import { UiCheckbox } from '@/components'",
  '',
  'const agree = ref(false)',
  "const picked = ref<(string | number)[]>([])",
  '</' + 'script>',
  '',
  '<template>',
  '  <UiCheckbox v-model="agree" label="Согласен" />',
  '  <UiCheckbox v-model="picked" value="mail" label="Почта" />',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<label class="ui-check ui-check--md ui-check--primary ui-check--end is-checked">',
  '  <span class="ui-check__control">',
  '    <input class="ui-check__input" type="checkbox" checked />',
  '    <span class="ui-check__box">…</span>',
  '  </span>',
  '  <span class="ui-check__copy"><span class="ui-check__label">Метка</span></span>',
  '</label>',
].join('\n')
</script>

<template>
  <section class="intro">
    <h1>Checkbox</h1>
    <p>
      Кадр Figma «Флажок» · <code>UiCheckbox</code>. Одиночный boolean или массив значений, частичный
      выбор, halo при наведении и фокусе.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>Нативный checkbox, Space, aria-checked="mixed", v-model boolean и массив, связь label и input.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Размер бокса, ореол, цвет заливки, радиус. Не копировать галочку под макет.</span>
    </div>
  </section>

  <section id="check-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — Checkbox.scss. Фронт — types + UiCheckbox.vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="check-sizes" class="split section-title" aria-label="Размеры флажка">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg · md · sm. В макете md — бокс 18px.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_CHECKBOX_SIZES" :key="`light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiCheckbox :size="size" :model-value="true" label="Метка" />
            <UiCheckbox :size="size" :model-value="false" label="Метка" />
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же поле, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_CHECKBOX_SIZES" :key="`dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiCheckbox :size="size" :model-value="true" label="Метка" />
            <UiCheckbox :size="size" :model-value="false" label="Метка" />
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="check-colors" class="live section-title">
    <h3>Цвета</h3>
    <p class="hint">Основной, вторичный, ошибка, внимание, инфо, успех.</p>
    <div class="filters">
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <div class="check-row">
        <UiCheckbox
          v-for="color in UI_CHECKBOX_COLORS"
          :key="color"
          :color="color"
          :model-value="true"
          :label="color"
        />
      </div>
    </div>
  </section>

  <section id="check-placement" class="live section-title">
    <h3>Позиция подписи</h3>
    <p class="hint"><code>labelPlacement</code>: end, start, top, bottom.</p>
    <div class="check-row">
      <UiCheckbox
        v-for="place in UI_CHECKBOX_PLACEMENTS"
        :key="place"
        :label-placement="place"
        :model-value="true"
        :label="place"
      />
    </div>
  </section>

  <section id="check-states" class="live section-title">
    <h3>Состояния</h3>
    <p class="hint">Не выбран, частично, выбран, disabled, ошибка. Наведение и фокус с клавиатуры — живые.</p>
    <div class="check-row">
      <UiCheckbox v-model="live" label="Интерактив" helper-text="Space переключает" />
      <UiCheckbox :model-value="false" indeterminate label="Частично" />
      <UiCheckbox :model-value="true" label="Выбран" />
      <UiCheckbox :model-value="false" disabled label="Не выбран (недост.)" />
      <UiCheckbox :model-value="true" disabled label="Выбран (недост.)" />
      <UiCheckbox
        v-model="errorOn"
        label="Согласие"
        error-message="Нужно подтвердить"
      />
    </div>
  </section>

  <section id="check-all" class="live section-title">
    <h3>Выбрать все</h3>
    <p class="hint">
      Родительский флажок с <code>indeterminate</code>, дети связаны массивом
      <code>v-model</code>.
    </p>
    <div class="check-stack">
      <UiCheckbox
        :model-value="allChecked"
        :indeterminate="someChecked"
        label="Выбрать все"
        @update:model-value="onSelectAll"
      />
      <UiCheckbox
        v-for="item in fruits"
        :key="item.value"
        v-model="selected"
        :value="item.value"
        :label="item.label"
      />
    </div>
    <p class="mask-value">v-model: <b>{{ selected.join(', ') || '∅' }}</b></p>
  </section>

  <section id="check-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Клик и клавиатура те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус бокса {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="12" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiCheckbox :model-value="true" label="Метка" />
      <UiCheckbox :model-value="false" label="Метка" />
      <UiCheckbox :model-value="false" indeterminate label="Частично" />
    </div>
  </section>

  <section id="check-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">Фронт берёт <code>UiCheckbox</code> и типы из <code>Checkbox.types.ts</code>.</p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="check-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">Верстальщик подключает <code>tokens.css</code> и <code>Checkbox.scss</code>.</p>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
