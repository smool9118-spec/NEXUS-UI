<script setup lang="ts">
import { reactive, ref } from 'vue'
import {
  UI_RADIO_COLORS,
  UI_RADIO_PLACEMENTS,
  UI_RADIO_SIZES,
  UiRadio,
  UiRadioGroup,
  type UiRadioOption,
} from '../components'

const theme = ref<'light' | 'dark'>('light')
const live = ref<string | number>('apple')
const rowValue = ref<string | number>('md')
const slotValue = ref<string | number>('card')
const errorValue = ref<string | number | undefined>(undefined)
const disabledValue = ref<string | number>('mail')

const fruits: UiRadioOption[] = [
  { label: 'Яблоко', value: 'apple' },
  { label: 'Груша', value: 'pear' },
  { label: 'Вишня', value: 'cherry' },
]

const sizes: UiRadioOption[] = [
  { label: 'Малый', value: 'sm' },
  { label: 'Средний', value: 'md' },
  { label: 'Большой', value: 'lg' },
]

const contacts: UiRadioOption[] = [
  { label: 'Почта', value: 'mail' },
  { label: 'Телефон', value: 'phone' },
  { label: 'Чат', value: 'chat', disabled: true },
]

const brand = reactive({
  primary: '#7367f0',
})

function brandStyle() {
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-primary-tonal': `${brand.primary}29`,
  }
}

const radioDocs = [
  { name: 'modelValue / v-model', values: 'string | number', def: '—' },
  { name: 'value', values: 'string | number, значение этой кнопки', def: 'обязательный' },
  { name: 'label', values: 'string', def: '—' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'color', values: 'primary | secondary | error | warning | info | success', def: 'primary' },
  { name: 'labelPlacement', values: 'end | start | top | bottom', def: 'end' },
  { name: 'disabled', values: 'boolean', def: 'false' },
]

const groupDocs = [
  { name: 'modelValue / v-model', values: 'string | number', def: '—' },
  { name: 'name', values: 'string, общее имя native radio', def: 'сгенерированное' },
  { name: 'options', values: '{ label; value; disabled? }[]', def: '[]' },
  { name: 'direction', values: 'row | column', def: 'column' },
  { name: 'size / color', values: 'наследуются вложенными UiRadio', def: 'md / primary' },
  { name: 'label', values: 'string, заголовок группы', def: '—' },
  { name: 'helperText / error / errorMessage', values: 'string / boolean / string', def: '—' },
  { name: 'disabled', values: 'boolean, блокирует всю группу', def: 'false' },
  { name: 'default slot', values: '<UiRadio> вручную рядом с options', def: '—' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { ref } from 'vue'",
  "import { UiRadio, UiRadioGroup } from '@/components'",
  '',
  "const plan = ref('month')",
  "const pay = ref('card')",
  "const options = [",
  "  { label: 'Месяц', value: 'month' },",
  "  { label: 'Год', value: 'year' },",
  ']',
  '</' + 'script>',
  '',
  '<template>',
  '  <UiRadioGroup v-model="plan" label="Тариф" :options="options" direction="row" />',
  '',
  '  <UiRadioGroup v-model="pay" name="pay" label="Оплата">',
  '    <UiRadio value="card" label="Карта" />',
  '    <UiRadio value="cash" label="Наличные" />',
  '  </UiRadioGroup>',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<div class="ui-radio-group ui-radio-group--column" role="radiogroup">',
  '  <p class="ui-radio-group__label">Тариф</p>',
  '  <div class="ui-radio-group__list">',
  '    <label class="ui-radio ui-radio--md ui-radio--primary ui-radio--end is-checked">',
  '      <span class="ui-radio__control">',
  '        <input class="ui-radio__input" type="radio" name="plan" checked />',
  '        <span class="ui-radio__circle"><span class="ui-radio__dot"></span></span>',
  '      </span>',
  '      <span class="ui-radio__copy"><span class="ui-radio__label">Месяц</span></span>',
  '    </label>',
  '  </div>',
  '</div>',
].join('\n')
</script>

<template>
  <section class="intro">
    <h1>Radio</h1>
    <p>
      Кадр Figma «Радиокнопка» · <code>UiRadio</code> и <code>UiRadioGroup</code>. Один вариант из
      списка, стрелки внутри <code>role="radiogroup"</code>, options или слот.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>
        Нативный radio, общее <code>name</code>, стрелки / Home / End, Space, provide/inject между
        группой и кнопкой.
      </span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Диаметр кружка, точка, ореол, цвет кольца. Не копировать кружок под макет.</span>
    </div>
  </section>

  <section id="radio-docs" class="live section-title">
    <h3>Документация UiRadio</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — Radio.scss. Фронт — types + Vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in radioDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="radio-group-docs" class="live section-title">
    <h3>Документация UiRadioGroup</h3>
    <p class="hint">Группа отдаёт v-model, name, size и color вложенным <code>UiRadio</code>.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in groupDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="radio-sizes" class="split section-title" aria-label="Размеры радиокнопки">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg · md · sm. В макете md — кружок 18px, точка 8px.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_RADIO_SIZES" :key="`light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiRadio :size="size" model-value="on" value="on" label="Метка" />
            <UiRadio :size="size" model-value="off" value="on" label="Метка" />
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же поле, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_RADIO_SIZES" :key="`dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiRadio :size="size" model-value="on" value="on" label="Метка" />
            <UiRadio :size="size" model-value="off" value="on" label="Метка" />
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="radio-colors" class="live section-title">
    <h3>Цвета</h3>
    <p class="hint">Основной, вторичный, ошибка, внимание, инфо, успех.</p>
    <div class="filters">
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <div class="check-row">
        <UiRadio
          v-for="color in UI_RADIO_COLORS"
          :key="color"
          :color="color"
          model-value="on"
          value="on"
          :label="color"
        />
      </div>
    </div>
  </section>

  <section id="radio-placement" class="live section-title">
    <h3>Позиция подписи</h3>
    <p class="hint"><code>labelPlacement</code>: end, start, top, bottom.</p>
    <div class="check-row">
      <UiRadio
        v-for="place in UI_RADIO_PLACEMENTS"
        :key="place"
        :label-placement="place"
        model-value="on"
        value="on"
        :label="place"
      />
    </div>
  </section>

  <section id="radio-states" class="live section-title">
    <h3>Состояния</h3>
    <p class="hint">Не выбран, выбран, disabled. Наведение и фокус с клавиатуры — живые.</p>
    <div class="check-row">
      <UiRadio model-value="off" value="on" label="Не выбран" />
      <UiRadio model-value="on" value="on" label="Выбран" />
      <UiRadio model-value="off" value="on" disabled label="Не выбран (недост.)" />
      <UiRadio model-value="on" value="on" disabled label="Выбран (недост.)" />
    </div>
  </section>

  <section id="radio-groups" class="live section-title">
    <h3>UiRadioGroup</h3>
    <p class="hint">
      Вертикаль и горизонталь, массив <code>options</code> или вложенные <code>UiRadio</code> через
      слот. Стрелки ходят по группе.
    </p>
    <div class="radio-groups">
      <UiRadioGroup
        v-model="live"
        name="fruits-col"
        label="Вертикально"
        :options="fruits"
        direction="column"
        helper-text="direction=&quot;column&quot;"
      />
      <UiRadioGroup
        v-model="rowValue"
        name="sizes-row"
        label="Горизонтально"
        :options="sizes"
        direction="row"
        helper-text="direction=&quot;row&quot;"
      />
      <UiRadioGroup v-model="slotValue" name="pay-slot" label="Слот вручную" direction="column">
        <UiRadio value="card" label="Карта" />
        <UiRadio value="cash" label="Наличные" />
        <UiRadio value="invoice" label="Счёт" />
      </UiRadioGroup>
    </div>
    <p class="mask-value">
      column: <b>{{ live }}</b>
      · row: <b>{{ rowValue }}</b>
      · slot: <b>{{ slotValue }}</b>
    </p>
  </section>

  <section id="radio-disabled" class="live section-title">
    <h3>Disabled и ошибка</h3>
    <p class="hint">Группа целиком, отдельный пункт и состояние ошибки.</p>
    <div class="radio-groups">
      <UiRadioGroup
        v-model="disabledValue"
        name="contacts-off"
        label="Группа недоступна"
        :options="contacts"
        disabled
      />
      <UiRadioGroup
        v-model="errorValue"
        name="contacts-err"
        label="Обязательный выбор"
        :options="contacts"
        error
        error-message="Выберите способ связи"
      />
    </div>
  </section>

  <section id="radio-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Выбор и клавиатура те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiRadio model-value="on" value="on" label="Метка" />
      <UiRadio model-value="off" value="on" label="Метка" />
    </div>
  </section>

  <section id="radio-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">Фронт берёт <code>UiRadio</code>, <code>UiRadioGroup</code> и типы из <code>Radio.types.ts</code>.</p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="radio-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">Верстальщик подключает <code>tokens.css</code> и <code>Radio.scss</code>.</p>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
