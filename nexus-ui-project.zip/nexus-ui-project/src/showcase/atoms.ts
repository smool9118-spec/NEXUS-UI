export type AtomId =
  | 'home'
  | 'button'
  | 'button-group'
  | 'icon-button'
  | 'toggle'
  | 'input'
  | 'masked-field'
  | 'select'
  | 'checkbox'
  | 'radio'
  | 'switch'
  | 'dialog'
  | 'dropdown'

export type AtomItem = {
  id: AtomId
  name: string
  figma: string
  tag: string
  ready: boolean
  kind?: 'page' | 'atom'
  sections: { id: string; label: string }[]
}

export const atoms: AtomItem[] = [
  {
    id: 'home',
    name: 'Главная',
    figma: '',
    tag: '',
    ready: true,
    kind: 'page',
    sections: [
      { id: 'home-layers', label: 'Три слоя' },
      { id: 'home-roles', label: 'Роли' },
      { id: 'home-designer', label: 'Дизайнер' },
      { id: 'home-layout', label: 'Верстальщик' },
      { id: 'home-frontend', label: 'Фронтенд' },
      { id: 'home-contract', label: 'Контракт' },
    ],
  },
  {
    id: 'button',
    name: 'Button',
    figma: 'UiButton',
    tag: 'UiButton',
    ready: true,
    sections: [
      { id: 'docs', label: 'Документация' },
      { id: 'variants', label: 'Варианты' },
      { id: 'icons', label: 'Иконки' },
      { id: 'sizes', label: 'Размеры' },
      { id: 'matrix', label: 'Цвета' },
      { id: 'states', label: 'Состояния' },
      { id: 'tokens', label: 'Токены' },
      { id: 'usage', label: 'Vue' },
      { id: 'button-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'button-group',
    name: 'Button Group',
    figma: 'UiButtonGroup',
    tag: 'UiButtonGroup',
    ready: true,
    sections: [
      { id: 'group-docs', label: 'Документация' },
      { id: 'group-variants', label: 'Варианты' },
      { id: 'group-sizes', label: 'Размеры' },
      { id: 'group-tokens', label: 'Токены' },
      { id: 'group-usage', label: 'Vue' },
      { id: 'group-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'icon-button',
    name: 'Icon Button',
    figma: 'UiIconButton',
    tag: 'UiIconButton',
    ready: true,
    sections: [
      { id: 'icon-docs', label: 'Документация' },
      { id: 'icon-variants', label: 'Варианты' },
      { id: 'icon-sizes', label: 'Размеры' },
      { id: 'icon-colors', label: 'Цвета' },
      { id: 'icon-shapes', label: 'Форма' },
      { id: 'icon-states', label: 'Состояния' },
      { id: 'icon-theme', label: 'Тема' },
      { id: 'icon-tokens', label: 'Токены' },
      { id: 'icon-usage', label: 'Vue' },
      { id: 'icon-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'toggle',
    name: 'Toggle',
    figma: 'Кнопка-переключатель',
    tag: 'nui-toggle-group',
    ready: true,
    sections: [
      { id: 'toggle-docs', label: 'Документация' },
      { id: 'toggle-sizes', label: 'Размеры' },
      { id: 'toggle-live', label: 'v-model' },
      { id: 'toggle-tokens', label: 'Токены' },
      { id: 'toggle-usage', label: 'Vue' },
      { id: 'toggle-html', label: 'Чистый HTML' },
    ],
  },
  {
    id: 'input',
    name: 'Text Field',
    figma: 'UiTextField',
    tag: 'UiTextField',
    ready: true,
    sections: [
      { id: 'field-docs', label: 'Документация' },
      { id: 'field-variants', label: 'Варианты' },
      { id: 'field-sizes', label: 'Размеры' },
      { id: 'field-float', label: 'Label' },
      { id: 'field-icons', label: 'Иконки' },
      { id: 'field-extras', label: 'Пароль' },
      { id: 'field-states', label: 'Состояния' },
      { id: 'field-colors', label: 'Цвета' },
      { id: 'field-theme', label: 'Тема' },
      { id: 'field-tokens', label: 'Токены' },
      { id: 'field-usage', label: 'Vue' },
      { id: 'field-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'masked-field',
    name: 'Masked Field',
    figma: 'UiMaskedField',
    tag: 'UiMaskedField',
    ready: true,
    sections: [
      { id: 'mask-docs', label: 'Документация' },
      { id: 'mask-presets', label: 'Пресеты' },
      { id: 'mask-unmasked', label: 'unmaskedValue' },
      { id: 'mask-counter', label: 'Счётчик' },
      { id: 'mask-tokens', label: 'Токены' },
      { id: 'mask-usage', label: 'Vue' },
      { id: 'mask-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'select',
    name: 'Select',
    figma: 'UiSelect',
    tag: 'UiSelect',
    ready: true,
    sections: [
      { id: 'select-docs', label: 'Документация' },
      { id: 'select-variants', label: 'Варианты' },
      { id: 'select-sizes', label: 'Размеры' },
      { id: 'select-single', label: 'Одиночный' },
      { id: 'select-chips', label: 'Чипсы' },
      { id: 'select-search', label: 'Поиск' },
      { id: 'select-groups', label: 'Группы' },
      { id: 'select-states', label: 'Состояния' },
      { id: 'select-tokens', label: 'Токены' },
      { id: 'select-usage', label: 'Vue' },
      { id: 'select-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'checkbox',
    name: 'Checkbox',
    figma: 'UiCheckbox',
    tag: 'UiCheckbox',
    ready: true,
    sections: [
      { id: 'check-docs', label: 'Документация' },
      { id: 'check-sizes', label: 'Размеры' },
      { id: 'check-colors', label: 'Цвета' },
      { id: 'check-placement', label: 'Подпись' },
      { id: 'check-states', label: 'Состояния' },
      { id: 'check-all', label: 'Выбрать все' },
      { id: 'check-tokens', label: 'Токены' },
      { id: 'check-usage', label: 'Vue' },
      { id: 'check-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'radio',
    name: 'Radio',
    figma: 'UiRadio',
    tag: 'UiRadioGroup',
    ready: true,
    sections: [
      { id: 'radio-docs', label: 'UiRadio' },
      { id: 'radio-group-docs', label: 'UiRadioGroup' },
      { id: 'radio-sizes', label: 'Размеры' },
      { id: 'radio-colors', label: 'Цвета' },
      { id: 'radio-placement', label: 'Подпись' },
      { id: 'radio-states', label: 'Состояния' },
      { id: 'radio-groups', label: 'Группы' },
      { id: 'radio-disabled', label: 'Disabled' },
      { id: 'radio-tokens', label: 'Токены' },
      { id: 'radio-usage', label: 'Vue' },
      { id: 'radio-html', label: 'Вёрстка' },
    ],
  },
  {
    id: 'switch',
    name: 'Switch',
    figma: 'UiSwitch',
    tag: 'UiSwitch',
    ready: true,
    sections: [
      { id: 'switch-docs', label: 'Документация' },
      { id: 'switch-sizes', label: 'Размеры' },
      { id: 'switch-colors', label: 'Цвета' },
      { id: 'switch-placement', label: 'Подпись' },
      { id: 'switch-states', label: 'Состояния' },
      { id: 'switch-icons', label: 'Иконки' },
      { id: 'switch-tokens', label: 'Токены' },
      { id: 'switch-usage', label: 'Vue' },
      { id: 'switch-html', label: 'Вёрстка' },
    ],
  },
  { id: 'dialog', name: 'Dialog', figma: 'Dialog', tag: 'nui-dialog', ready: false, sections: [] },
  {
    id: 'dropdown',
    name: 'Dropdown',
    figma: 'Dropdown',
    tag: 'nui-dropdown',
    ready: false,
    sections: [],
  },
]
