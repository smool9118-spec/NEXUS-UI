<script setup lang="ts">
import { reactive, ref } from 'vue'
import { UiMaskedField } from '../components'

const phone = ref('')
const birth = ref('')
const card = ref('')
const unmaskedOn = ref(false)
const livePhone = ref('')
const completeFlag = ref(false)
const note = ref('Короткий текст')
const noteLimit = ref('Заполнено до лимита!')
const brandField = ref('9123456789')

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
  }
}

function onPhoneComplete() {
  completeFlag.value = true
}

const propsDocs = [
  { name: 'наследует TextField', values: 'variant, size, color, label, placeholder, helperText, error, errorMessage, disabled, readonly, clearable', def: 'как у UiTextField' },
  { name: 'modelValue / v-model', values: 'string', def: "''" },
  { name: 'mask', values: "phone | date | time | card | inn | snils | string (# цифра, A буква, * любой)", def: '—' },
  { name: 'unmaskedValue', values: 'boolean, в v-model уходит чистая строка без скобок и дефисов', def: 'false' },
  { name: 'maskPlaceholder', values: 'boolean, шаблон маски при фокусе', def: 'false' },
  { name: 'maxLength', values: 'number, жёсткий лимит символов', def: '—' },
  { name: 'showCounter', values: 'boolean, счётчик current / maxLength справа внизу', def: 'false' },
  { name: 'слот prepend / append', values: 'пробрасываются в UiTextField', def: '—' },
  { name: '@complete', values: 'маска заполнена целиком (например, 10 цифр телефона)', def: '—' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { ref } from 'vue'",
  "import { UiMaskedField } from '@/components'",
  '',
  "const phone = ref('')",
  '</' + 'script>',
  '',
  '<template>',
  '  <UiMaskedField',
  '    v-model="phone"',
  '    mask="phone"',
  '    label="Телефон"',
  '    :unmasked-value="true"',
  '    mask-placeholder',
  '    @complete="onReady"',
  '  />',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<div class="ui-masked has-footer">',
  '  <div class="ui-field ui-field--outlined ui-field--md has-label is-filled is-floated">…</div>',
  '  <div class="ui-masked__footer">',
  '    <p class="ui-masked__helper">Подсказка</p>',
  '    <span class="ui-masked__counter">12 / 20</span>',
  '  </div>',
  '</div>',
].join('\n')
</script>

<template>
  <section class="intro">
    <h1>Masked Field</h1>
    <p>
      <code>UiMaskedField</code> — обёртка над <code>UiTextField</code>: маски, чистая строка в
      v-model, шаблон при фокусе и счётчик символов. Базовое поле остаётся без этой логики.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>Форматирование при вводе, Backspace / Delete, вставке; эмит complete; лимит maxLength.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Цвета футера и счётчика (--ui-warning, --ui-error), полупрозрачный шаблон маски.</span>
    </div>
  </section>

  <section id="mask-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — MaskedField.scss. Фронт — types + UiMaskedField.vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="mask-presets" class="live section-title">
    <h3>Пресеты</h3>
    <p class="hint">
      Телефон <code>+7 (###) ###-##-##</code>, дата рождения <code>##.##.####</code>, карта
      <code>#### #### #### ####</code>. Шаблон маски виден при фокусе.
    </p>
    <div class="field-demo">
      <UiMaskedField
        v-model="phone"
        mask="phone"
        label="Телефон"
        helper-text="Пресет phone"
        mask-placeholder
        clearable
        @complete="onPhoneComplete"
      />
      <UiMaskedField
        v-model="birth"
        mask="date"
        label="Дата рождения"
        helper-text="Пресет date"
        mask-placeholder
      />
      <UiMaskedField
        v-model="card"
        mask="card"
        label="Банковская карта"
        helper-text="Пресет card"
        mask-placeholder
      />
    </div>
    <p v-if="completeFlag" class="hint">Телефон заполнен — сработал <code>complete</code>.</p>
  </section>

  <section id="mask-unmasked" class="live section-title">
    <h3>unmaskedValue</h3>
    <p class="hint">
      Переключатель меняет то, что уходит в v-model: отформатированная строка или только цифры.
    </p>
    <label class="mask-switch">
      <input v-model="unmaskedOn" type="checkbox" />
      <span>unmaskedValue = {{ unmaskedOn }}</span>
    </label>
    <div class="field-demo">
      <UiMaskedField
        v-model="livePhone"
        mask="phone"
        label="Телефон"
        helper-text="Печатайте или вставьте номер"
        mask-placeholder
        :unmasked-value="unmaskedOn"
      />
    </div>
    <p class="mask-value">
      v-model:
      <b>{{ livePhone === '' ? '∅' : livePhone }}</b>
    </p>
  </section>

  <section id="mask-counter" class="live section-title">
    <h3>Счётчик символов</h3>
    <p class="hint">
      <code>showCounter</code> + <code>maxLength</code>. Обычный цвет, предупреждение с 90%
      (<code>--ui-warning</code>), лимит — <code>--ui-error</code>.
    </p>
    <div class="field-demo">
      <UiMaskedField
        v-model="note"
        label="Комментарий"
        helper-text="Обычное состояние"
        :max-length="20"
        show-counter
      />
      <UiMaskedField
        v-model="noteLimit"
        label="Комментарий"
        helper-text="Достигнут лимит"
        :max-length="20"
        show-counter
      />
    </div>
  </section>

  <section id="mask-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Маска и v-model те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="24" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiMaskedField v-model="brandField" mask="phone" label="Телефон" helper-text="Подсказка" mask-placeholder />
    </div>
  </section>

  <section id="mask-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">Фронт берёт <code>UiMaskedField</code> и типы из <code>MaskedField.types.ts</code>.</p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="mask-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">Верстальщик подключает <code>tokens.css</code> и <code>MaskedField.scss</code>.</p>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
