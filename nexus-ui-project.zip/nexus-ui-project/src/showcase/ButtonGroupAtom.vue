<script setup lang="ts">
import { reactive } from 'vue'
import { UiButton, UiButtonGroup, UI_BUTTON_SIZES, UI_BUTTON_VARIANTS } from '../components'

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-primary-tonal': `${brand.primary}29`,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
  }
}

const variantLabel: Record<(typeof UI_BUTTON_VARIANTS)[number], string> = {
  contained: 'Обычный',
  tonal: 'Подложка',
  outlined: 'Контур',
  text: 'Текст',
}

const propsDocs = [
  { name: 'variant', values: 'contained | tonal | outlined | text', def: 'contained' },
  { name: 'color', values: 'primary | secondary | error | warning | info | success', def: 'primary' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'disabled', values: 'boolean', def: 'false' },
  { name: 'слот', values: 'несколько UiButton', def: '—' },
]

const vueSnippet = `<UiButtonGroup variant="contained" color="primary" size="md">
  <UiButton>Один</UiButton>
  <UiButton>Два</UiButton>
  <UiButton>Три</UiButton>
</UiButtonGroup>`

const htmlSnippet = `<div class="ui-btn-group ui-btn-group--contained ui-btn-group--primary ui-btn-group--md">
  <button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">Один</button>
  <button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">Два</button>
  <button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">Три</button>
</div>`
</script>

<template>
  <section class="intro">
    <h1>Button Group</h1>
    <p>
      Кадр Figma «Группа кнопок» · <code>UiButtonGroup</code>. Объединяет связанные
      <code>UiButton</code>: общая скругление, разделители, те же вариант / цвет / размер.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>Это визуальная группа, не выбор одного значения. Каждая кнопка кликается сама.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Цвета и радиус группы. Выбор «один из» — отдельный атом Toggle.</span>
    </div>
  </section>

  <section id="group-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Пропсы группы наследуются детьми, если у кнопки не заданы свои.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="group-variants" class="live section-title">
    <h3>Варианты</h3>
    <p class="hint">Обычный, подложка, контур, текст — light и dark.</p>
    <div class="sizes-frame" data-theme="light" style="margin-bottom: 16px">
      <div v-for="variant in UI_BUTTON_VARIANTS" :key="`light-${variant}`" class="size-line">
        <span>{{ variantLabel[variant] }}</span>
        <UiButtonGroup :variant="variant" color="primary">
          <UiButton>Один</UiButton>
          <UiButton>Два</UiButton>
          <UiButton>Три</UiButton>
        </UiButtonGroup>
      </div>
    </div>
    <div class="sizes-frame" data-theme="dark">
      <div v-for="variant in UI_BUTTON_VARIANTS" :key="`dark-${variant}`" class="size-line">
        <span>{{ variantLabel[variant] }}</span>
        <UiButtonGroup :variant="variant" color="primary">
          <UiButton>Один</UiButton>
          <UiButton>Два</UiButton>
          <UiButton>Три</UiButton>
        </UiButtonGroup>
      </div>
    </div>
  </section>

  <section id="group-sizes" class="split section-title" aria-label="Размеры группы">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg / md / sm наследуются кнопками.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_BUTTON_SIZES" :key="`g-light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiButtonGroup :size="size">
              <UiButton>Один</UiButton>
              <UiButton>Два</UiButton>
              <UiButton>Три</UiButton>
            </UiButtonGroup>
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede"><code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_BUTTON_SIZES" :key="`g-dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiButtonGroup :size="size">
              <UiButton>Один</UiButton>
              <UiButton>Два</UiButton>
              <UiButton>Три</UiButton>
            </UiButtonGroup>
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="group-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Разметка и клик те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="24" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiButtonGroup size="lg">
        <UiButton>Один</UiButton>
        <UiButton>Два</UiButton>
        <UiButton>Три</UiButton>
      </UiButtonGroup>
      <UiButtonGroup size="lg" variant="outlined">
        <UiButton>Один</UiButton>
        <UiButton>Два</UiButton>
      </UiButtonGroup>
    </div>
  </section>

  <section id="group-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">
      <code>UiButtonGroup</code> + слот из <code>UiButton</code>. Выбор одного значения — Toggle.
    </p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="group-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint"><code>tokens.css</code> + <code>Button.scss</code> + <code>ButtonGroup.scss</code>.</p>
    <div class="btn-row" style="margin-bottom: 16px">
      <div class="ui-btn-group ui-btn-group--contained ui-btn-group--primary ui-btn-group--md">
        <button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">Один</button>
        <button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">Два</button>
        <button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">Три</button>
      </div>
    </div>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
