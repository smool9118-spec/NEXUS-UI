<script setup lang="ts">
import { reactive, ref } from 'vue'
import {
  UI_BUTTON_COLORS,
  UI_BUTTON_SIZES,
  UI_BUTTON_VARIANTS,
  UiButton,
} from '../components'
import ArrowIcon from '../icons/ArrowIcon.vue'
import PlusIcon from '../icons/PlusIcon.vue'

const variantLabel: Record<(typeof UI_BUTTON_VARIANTS)[number], string> = {
  contained: 'Обычный · contained',
  tonal: 'Подложка · tonal',
  outlined: 'Контур · outlined',
  text: 'Текст · text',
}

const sizeLabel: Record<(typeof UI_BUTTON_SIZES)[number], string> = {
  lg: 'Большой · lg · 48px',
  md: 'Средний · md · 38px',
  sm: 'Малый · sm · 30px',
}

const theme = ref<'light' | 'dark'>('light')
const matrixSize = ref<(typeof UI_BUTTON_SIZES)[number]>('md')
const matrixDisabled = ref(false)
const clicks = ref(0)
const loading = ref(false)

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

const propsDocs = [
  { name: 'variant', values: 'contained | tonal | outlined | text', def: 'contained' },
  { name: 'color', values: 'primary | secondary | error | warning | info | success', def: 'primary' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'type', values: 'button | submit | reset', def: 'button' },
  { name: 'disabled', values: 'boolean', def: 'false' },
  { name: 'loading', values: 'boolean', def: 'false' },
  { name: 'icon', values: 'boolean, квадратная иконка', def: 'false' },
  { name: 'block', values: 'boolean, ширина 100%', def: 'false' },
  { name: 'слот default', values: 'подпись', def: '—' },
  { name: 'слот icon-left / icon-right', values: 'иконки слева и справа', def: '—' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { UiButton } from '@/components'",
  '</' + 'script>',
  '',
  '<template>',
  '  <UiButton variant="contained" color="primary" size="md">',
  '    <template #icon-left><PlusIcon /></template>',
  '    Кнопка',
  '  </UiButton>',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">',
  '  Кнопка',
  '</button>',
  '',
  '<!-- файлы компонента -->',
  'src/styles/tokens.css',
  'src/components/Button/Button.scss',
  'src/components/Button/Button.types.ts',
  'src/components/Button/UiButton.vue',
].join('\n')

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-primary-tonal': `${brand.primary}29`,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
  }
}

function onAction() {
  clicks.value += 1
}

function onLoadDemo() {
  loading.value = true
  window.setTimeout(() => {
    loading.value = false
    clicks.value += 1
  }, 900)
}
</script>

<template>
  <section class="intro">
    <h1>Button</h1>
    <p>
      Кадр Figma «Кнопки» · <code>UiButton</code>. Четыре файла: токены, SCSS,
      типы, Vue. Варианты contained / outlined / text (+ tonal из макета «Подложка»).
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>Клик, Space/Enter, disabled, loading, фокус, ripple, scale(0.98). Не копировать внутренний DOM.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Цвет, радиус, отступы, состояния. Не делать отдельную кнопку под макет.</span>
    </div>
  </section>

  <section id="docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — Button.scss. Фронт — types + UiButton.vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="variants" class="live section-title">
    <h3>Варианты</h3>
    <p class="hint">Обычный, подложка, контур, текст — как в макете.</p>
    <div class="btn-row">
      <UiButton v-for="variant in UI_BUTTON_VARIANTS" :key="variant" :variant="variant">
        Кнопка
      </UiButton>
    </div>
  </section>

  <section id="icons" class="live section-title">
    <h3>Иконки</h3>
    <p class="hint">Слоты <code>icon-left</code> / <code>icon-right</code>. Квадрат — проп <code>icon</code>.</p>
    <div class="btn-row">
      <UiButton>Кнопка</UiButton>
      <UiButton>
        <template #icon-left><ArrowIcon /></template>
        Кнопка
      </UiButton>
      <UiButton>
        Кнопка
        <template #icon-right><ArrowIcon direction="right" /></template>
      </UiButton>
      <UiButton>
        <template #icon-left><ArrowIcon /></template>
        Кнопка
        <template #icon-right><ArrowIcon direction="right" /></template>
      </UiButton>
      <UiButton icon aria-label="Добавить"><PlusIcon /></UiButton>
    </div>
  </section>

  <section id="sizes" class="split section-title" aria-label="Размеры кнопки">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg 48 · md 38 · sm 30, как в Figma.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_BUTTON_SIZES" :key="`light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiButton :size="size">
              <template #icon-left><PlusIcon /></template>
              Кнопка
            </UiButton>
            <UiButton :size="size" icon aria-label="Добавить"><PlusIcon /></UiButton>
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же кнопка, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame">
          <div v-for="size in UI_BUTTON_SIZES" :key="`dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiButton :size="size">
              <template #icon-left><PlusIcon /></template>
              Кнопка
            </UiButton>
            <UiButton :size="size" icon aria-label="Добавить"><PlusIcon /></UiButton>
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="matrix" class="live section-title">
    <h3>Цвета</h3>
    <p class="hint">primary, secondary, error, warning, info, success. Сетка 4 × 6 из макета.</p>
    <div class="filters">
      <label>
        size
        <select v-model="matrixSize">
          <option v-for="size in UI_BUTTON_SIZES" :key="size" :value="size">{{ sizeLabel[size] }}</option>
        </select>
      </label>
      <label>
        тема
        <select v-model="theme">
          <option value="light">light</option>
          <option value="dark">dark</option>
        </select>
      </label>
      <label>
        <input v-model="matrixDisabled" type="checkbox" />
        disabled
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <table class="matrix-table">
        <thead>
          <tr>
            <th></th>
            <th v-for="color in UI_BUTTON_COLORS" :key="color">{{ color }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="variant in UI_BUTTON_VARIANTS" :key="variant">
            <td>{{ variantLabel[variant] }}</td>
            <td v-for="color in UI_BUTTON_COLORS" :key="`${variant}-${color}`">
              <UiButton
                :variant="variant"
                :color="color"
                :size="matrixSize"
                :disabled="matrixDisabled"
              >
                Кнопка
              </UiButton>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="states" class="live section-title">
    <h3>Состояния</h3>
    <p class="hint">
      Наведение, нажатие <code>scale(0.98)</code> + ripple, фокус-кольцо, disabled, loading.
      Клики считаются только с живых кнопок.
    </p>
    <div class="btn-row">
      <UiButton @click="onAction">Нажать</UiButton>
      <UiButton variant="tonal" @click="onAction">Подложка</UiButton>
      <UiButton variant="outlined" :loading="loading" @click="onLoadDemo">
        {{ loading ? 'Загрузка' : 'Loading' }}
      </UiButton>
      <UiButton variant="text" disabled @click="onAction">Disabled</UiButton>
      <UiButton icon aria-label="Добавить" @click="onAction"><PlusIcon /></UiButton>
      <p class="value-pill">clicks: <b>{{ clicks }}</b></p>
    </div>
    <p class="hint" style="margin-top: 20px">block — ширина 100%</p>
    <div class="block-demo">
      <UiButton block @click="onAction">Block button</UiButton>
    </div>
  </section>

  <section id="tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Разметка и клик те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="24" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiButton size="lg">
        <template #icon-left><PlusIcon /></template>
        Кнопка
      </UiButton>
      <UiButton size="lg" variant="tonal">Tonal</UiButton>
      <UiButton size="lg" variant="outlined">Outlined</UiButton>
      <UiButton size="lg" variant="text">Text</UiButton>
    </div>
  </section>

  <section id="usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">
      Фронт берёт <code>UiButton</code> и типы из <code>Button.types.ts</code>.
    </p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="button-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">
      Верстальщик подключает <code>tokens.css</code> и <code>Button.scss</code>.
      Те же классы, что рисует <code>UiButton</code>.
    </p>
    <div class="btn-row" style="margin-bottom: 16px">
      <button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">Кнопка</button>
      <button class="ui-btn ui-btn--tonal ui-btn--primary ui-btn--md" type="button">Подложка</button>
      <button class="ui-btn ui-btn--outlined ui-btn--primary ui-btn--md" type="button">Контур</button>
      <button class="ui-btn ui-btn--text ui-btn--primary ui-btn--md" type="button">Текст</button>
    </div>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
