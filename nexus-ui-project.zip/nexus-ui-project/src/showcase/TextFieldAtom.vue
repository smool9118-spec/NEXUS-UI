<script setup lang="ts">
import { reactive, ref } from 'vue'
import {
  UI_TEXT_FIELD_COLORS,
  UI_TEXT_FIELD_SIZES,
  UI_TEXT_FIELD_VARIANTS,
  UiTextField,
} from '../components'
import SearchIcon from '../icons/SearchIcon.vue'
import UserIcon from '../icons/UserIcon.vue'

const variantLabel: Record<(typeof UI_TEXT_FIELD_VARIANTS)[number], string> = {
  outlined: 'Контур · outlined',
  filled: 'Заливка · filled',
  standard: 'Линия · standard',
}

const theme = ref<'light' | 'dark'>('light')
const outlined = ref('Ввод')
const filled = ref('Ввод')
const standard = ref('Ввод')
const floatEmpty = ref('')
const floatFilled = ref('Ввод')
const withIcon = ref('Ввод')
const clearable = ref('Ввод')
const password = ref('secret')
const errorValue = ref('Ввод')
const liveValue = ref('')
const area = ref('Несколько строк')
const brandField = ref('Ввод')

const brand = reactive({
  primary: '#7367f0',
  radius: 8,
})

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-dark': brand.primary,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
  }
}

const propsDocs = [
  { name: 'modelValue / v-model', values: 'string | number', def: "''" },
  { name: 'variant', values: 'outlined | filled | standard', def: 'outlined' },
  { name: 'size', values: 'sm | md | lg', def: 'md' },
  { name: 'color', values: 'primary | secondary | error | warning | info | success', def: 'primary' },
  { name: 'label', values: 'string, плавает при фокусе или заполнении', def: '—' },
  { name: 'placeholder', values: 'string', def: '—' },
  { name: 'helperText', values: 'string, подпись под полем', def: '—' },
  { name: 'error', values: 'boolean', def: 'false' },
  { name: 'errorMessage', values: 'string, заменяет helperText', def: '—' },
  { name: 'disabled / readonly / required', values: 'boolean', def: 'false' },
  { name: 'clearable', values: 'boolean, крестик очистки', def: 'false' },
  { name: 'type', values: 'text | password | email | number | tel | search', def: 'text' },
  { name: 'multiline / rows', values: 'textarea и число строк', def: 'false / 3' },
  { name: 'слот prepend / append', values: 'иконка слева / справа', def: '—' },
]

const vueSnippet = [
  '<script setup lang="ts">',
  "import { ref } from 'vue'",
  "import { UiTextField } from '@/components'",
  '',
  "const email = ref('')",
  '</' + 'script>',
  '',
  '<template>',
  '  <UiTextField v-model="email" variant="outlined" label="Почта" helper-text="Подсказка" />',
  '</template>',
].join('\n')

const htmlSnippet = [
  '<div class="ui-field ui-field--outlined ui-field--md ui-field--primary is-filled is-floated has-label">',
  '  <div class="ui-field__control">',
  '    <div class="ui-field__body">',
  '      <label class="ui-field__label" for="email">Почта</label>',
  '      <input id="email" class="ui-field__input" value="Ввод" />',
  '    </div>',
  '  </div>',
  '  <p class="ui-field__helper">Подсказка</p>',
  '</div>',
].join('\n')
</script>

<template>
  <section class="intro">
    <h1>Text Field</h1>
    <p>
      Кадр Figma «Текстовое поле» · <code>UiTextField</code>. Четыре файла: токены, SCSS, типы, Vue.
      Контур, заливка и нижняя линия, плавающий label.
    </p>
  </section>

  <section class="rules">
    <div class="rule">
      <strong>Не меняется</strong>
      <span>v-model, focus/blur/clear, disabled/readonly, aria-invalid / aria-describedby, связь label и input.</span>
    </div>
    <div class="rule">
      <strong>Меняется токенами и SCSS</strong>
      <span>Цвета рамки и фона, размеры, анимация label. Не делать отдельное поле под макет.</span>
    </div>
  </section>

  <section id="field-docs" class="live section-title">
    <h3>Документация</h3>
    <p class="hint">Дизайнер — tokens.css. Верстальщик — TextField.scss. Фронт — types + UiTextField.vue.</p>
    <div class="docs-table-wrap">
      <table class="docs-table">
        <thead>
          <tr>
            <th>Имя</th>
            <th>Значения</th>
            <th>По умолчанию</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in propsDocs" :key="row.name">
            <td><code>{{ row.name }}</code></td>
            <td>{{ row.values }}</td>
            <td><code>{{ row.def }}</code></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section id="field-variants" class="live section-title">
    <h3>Варианты</h3>
    <p class="hint">Контур (outlined), заливка (filled), линия (standard).</p>
    <div class="field-demo">
      <UiTextField v-model="outlined" variant="outlined" label="Подпись" helper-text="Подсказка" />
      <UiTextField v-model="filled" variant="filled" label="Подпись" helper-text="Подсказка" />
      <UiTextField v-model="standard" variant="standard" label="Подпись" helper-text="Подсказка" />
    </div>
  </section>

  <section id="field-sizes" class="split section-title" aria-label="Размеры текстового поля">
    <article class="panel" data-theme="light">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">светлая</span>
        </div>
        <p class="lede">lg 56 · md 48 · sm 38, как в Figma.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame field-sizes">
          <div v-for="size in UI_TEXT_FIELD_SIZES" :key="`light-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiTextField :size="size" model-value="Ввод" label="Подпись" helper-text="Подсказка" />
          </div>
        </div>
      </div>
    </article>
    <article class="panel" data-theme="dark">
      <div class="panel-head">
        <div class="heading">
          <h2>Размеры</h2>
          <span class="badge">тёмная</span>
        </div>
        <p class="lede">Та же поле, <code>data-theme="dark"</code>.</p>
      </div>
      <div class="panel-body">
        <div class="sizes-frame field-sizes">
          <div v-for="size in UI_TEXT_FIELD_SIZES" :key="`dark-${size}`" class="size-line">
            <span>{{ size }}</span>
            <UiTextField :size="size" model-value="Ввод" label="Подпись" helper-text="Подсказка" />
          </div>
        </div>
      </div>
    </article>
  </section>

  <section id="field-float" class="live section-title">
    <h3>Плавающий label</h3>
    <p class="hint">Пустое поле держит подпись внутри. Фокус или значение поднимают её на рамку.</p>
    <div class="field-demo">
      <UiTextField v-model="floatEmpty" label="Подпись" placeholder="Введите текст" helper-text="Пустое" />
      <UiTextField v-model="floatFilled" label="Подпись" helper-text="Заполненное" />
      <UiTextField v-model="liveValue" label="Живой ввод" placeholder="Начните печатать" helper-text="v-model" />
    </div>
  </section>

  <section id="field-icons" class="live section-title">
    <h3>Иконки</h3>
    <p class="hint">Слоты <code>prepend</code> и <code>append</code> внутри поля.</p>
    <div class="field-demo">
      <UiTextField v-model="withIcon" label="Подпись" helper-text="Слева">
        <template #prepend><SearchIcon /></template>
      </UiTextField>
      <UiTextField v-model="withIcon" label="Подпись" helper-text="Справа">
        <template #append><UserIcon /></template>
      </UiTextField>
      <UiTextField v-model="withIcon" label="Подпись" helper-text="С двух сторон">
        <template #prepend><SearchIcon /></template>
        <template #append><UserIcon /></template>
      </UiTextField>
    </div>
  </section>

  <section id="field-extras" class="live section-title">
    <h3>Очистка и пароль</h3>
    <p class="hint">Крестик <code>clearable</code> и глазик для <code>type="password"</code>.</p>
    <div class="field-demo">
      <UiTextField v-model="clearable" label="Очистка" helper-text="Крестик справа" clearable />
      <UiTextField v-model="password" type="password" label="Пароль" helper-text="Показать / скрыть" />
      <UiTextField v-model="area" multiline :rows="3" label="Комментарий" helper-text="textarea" />
    </div>
  </section>

  <section id="field-states" class="live section-title">
    <h3>Состояния</h3>
    <p class="hint">Ошибка через <code>errorMessage</code>, цвет акцента, disabled. Наведение и фокус — живые.</p>
    <div class="field-demo">
      <UiTextField v-model="errorValue" label="Подпись" error-message="Ошибка" />
      <UiTextField model-value="Ввод" label="Успех" helper-text="Подсказка" color="success" />
      <UiTextField model-value="Ввод" label="Подпись" helper-text="Подсказка" disabled />
      <UiTextField model-value="Ввод" label="Только чтение" helper-text="readonly" readonly />
    </div>
  </section>

  <section id="field-colors" class="live section-title">
    <h3>Цвета</h3>
    <p class="hint">Акцент рамки и label при фокусе. Тема Light / Dark.</p>
    <div class="filters">
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <div class="field-demo">
        <UiTextField
          v-for="color in UI_TEXT_FIELD_COLORS"
          :key="color"
          :color="color"
          model-value="Ввод"
          :label="color"
          helper-text="Подсказка"
        />
      </div>
    </div>
  </section>

  <section id="field-theme" class="live section-title">
    <h3>Тема Light / Dark</h3>
    <p class="hint">Все три варианта на одной панели. Цвета только из токенов.</p>
    <div class="filters">
      <label>
        тема
        <select v-model="theme">
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
    </div>
    <div class="matrix" :data-theme="theme">
      <div class="field-demo">
        <UiTextField
          v-for="variant in UI_TEXT_FIELD_VARIANTS"
          :key="`theme-${variant}`"
          :variant="variant"
          model-value="Ввод"
          :label="variantLabel[variant]"
          helper-text="Подсказка"
        />
        <UiTextField model-value="Ввод" label="Ошибка" error-message="Неверное значение" />
        <UiTextField model-value="Ввод" label="Отключено" helper-text="Подсказка" disabled />
      </div>
    </div>
  </section>

  <section id="field-tokens" class="tokens section-title">
    <h3>Другой бренд — только токены</h3>
    <p class="hint">Меняются CSS-переменные. Разметка и клик те же.</p>
    <div class="token-grid">
      <label>
        --nui-primary-main
        <input v-model="brand.primary" type="color" />
      </label>
      <label>
        радиус {{ brand.radius }}px
        <input v-model.number="brand.radius" type="range" min="0" max="24" />
      </label>
    </div>
    <div class="brand-box" :style="brandStyle()">
      <UiTextField v-model="brandField" variant="outlined" label="Подпись" helper-text="Подсказка" />
      <UiTextField v-model="brandField" variant="filled" label="Подпись" helper-text="Подсказка" />
      <UiTextField v-model="brandField" variant="standard" label="Подпись" helper-text="Подсказка" />
    </div>
  </section>

  <section id="field-usage" class="usage section-title">
    <h3>Vue 3</h3>
    <p class="hint">Фронт берёт <code>UiTextField</code> и типы из <code>TextField.types.ts</code>.</p>
    <pre class="code">{{ vueSnippet }}</pre>
  </section>

  <section id="field-html" class="usage section-title">
    <h3>Вёрстка без JS</h3>
    <p class="hint">Верстальщик подключает <code>tokens.css</code> и <code>TextField.scss</code>.</p>
    <pre class="code">{{ htmlSnippet }}</pre>
  </section>
</template>
