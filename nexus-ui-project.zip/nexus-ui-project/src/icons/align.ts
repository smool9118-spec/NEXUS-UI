const stroke = 'stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"'

export const alignIcons = {
  left: `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" ${stroke}><path d="M4 6H20"/><path d="M4 12H14"/><path d="M4 18H18"/></svg>`,
  center: `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" ${stroke}><path d="M4 6H20"/><path d="M8 12H16"/><path d="M6 18H18"/></svg>`,
  right: `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" ${stroke}><path d="M4 6H20"/><path d="M10 12H20"/><path d="M6 18H20"/></svg>`,
  justify: `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" ${stroke}><path d="M4 6H20"/><path d="M4 12H20"/><path d="M4 18H20"/></svg>`,
} as const

export type AlignName = keyof typeof alignIcons
