<script setup lang="ts">
import { computed } from 'vue'
import { alignIcons, type AlignName } from './align'

const props = defineProps<{ name: AlignName }>()
const markup = computed(() => alignIcons[props.name])
</script>

<template>
  <span class="nui-align-icon" v-html="markup" />
</template>

<style scoped>
.nui-align-icon {
  display: inline-flex;
  line-height: 0;
}
.nui-align-icon :deep(svg) {
  display: block;
}
</style>
