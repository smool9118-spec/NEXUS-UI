<script setup lang="ts">
import { searchIcon } from './search'
</script>

<template>
  <span class="nui-i" v-html="searchIcon" />
</template>

<style scoped>
.nui-i {
  display: inline-flex;
  line-height: 0;
}
.nui-i :deep(svg) {
  width: var(--nui-btn-icon, 16px);
  height: var(--nui-btn-icon, 16px);
  display: block;
}
</style>
