<script setup lang="ts">
import { plusIcon } from './plus'
</script>

<template>
  <span class="nui-i" v-html="plusIcon" />
</template>

<style scoped>
.nui-i {
  display: inline-flex;
  line-height: 0;
}
.nui-i :deep(svg) {
  width: var(--nui-btn-icon, 20px);
  height: var(--nui-btn-icon, 20px);
  display: block;
}
</style>
