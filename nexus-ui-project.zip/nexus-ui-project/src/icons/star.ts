const stroke =
  'stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"'

export const starIcon = `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" ${stroke}><path d="M12 3.5 14.6 9l6 .7-4.5 4.1 1.3 5.9L12 16.8 6.6 19.7l1.3-5.9L3.4 9.7l6-.7L12 3.5Z"/></svg>`

export const starFilledIcon = `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M12 3.5 14.6 9l6 .7-4.5 4.1 1.3 5.9L12 16.8 6.6 19.7l1.3-5.9L3.4 9.7l6-.7L12 3.5Z"/></svg>`
