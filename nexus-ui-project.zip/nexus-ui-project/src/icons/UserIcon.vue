<script setup lang="ts">
const markup = `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.2"/><path d="M5.5 19.2c.8-3 3.3-5 6.5-5s5.7 2 6.5 5"/></svg>`
</script>

<template>
  <span class="nui-i" v-html="markup" />
</template>

<style scoped>
.nui-i {
  display: inline-flex;
  line-height: 0;
}
.nui-i :deep(svg) {
  width: var(--nui-btn-icon, 16px);
  height: var(--nui-btn-icon, 16px);
  display: block;
}
</style>
