<script setup lang="ts">
import { computed } from 'vue'
import { starFilledIcon, starIcon } from './star'

const props = defineProps<{
  filled?: boolean
}>()

const markup = computed(() => (props.filled ? starFilledIcon : starIcon))
</script>

<template>
  <span class="nui-i" v-html="markup" />
</template>

<style scoped>
.nui-i {
  display: inline-flex;
  line-height: 0;
}
.nui-i :deep(svg) {
  width: var(--nui-btn-icon, 22px);
  height: var(--nui-btn-icon, 22px);
  display: block;
}
</style>
