<script setup lang="ts">
withDefaults(
  defineProps<{
    direction?: 'left' | 'right'
  }>(),
  { direction: 'left' },
)
</script>

<template>
  <span class="nui-i" :data-dir="direction" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M15 6 9 12l6 6" />
    </svg>
  </span>
</template>

<style scoped>
.nui-i {
  display: inline-flex;
  line-height: 0;
}
.nui-i[data-dir='right'] {
  transform: rotate(180deg);
}
.nui-i :deep(svg) {
  width: var(--ui-btn-icon, var(--nui-btn-icon, 20px));
  height: var(--ui-btn-icon, var(--nui-btn-icon, 20px));
  display: block;
}
</style>
