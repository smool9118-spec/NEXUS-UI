const stroke =
  'stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"'

export const searchIcon = `<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" ${stroke}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`
