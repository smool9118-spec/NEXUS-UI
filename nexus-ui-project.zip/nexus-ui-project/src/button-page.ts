import { createApp } from 'vue'
import ButtonPage from './ButtonPage.vue'
import { registerNuiElements } from './elements/register'
import './styles/tokens.css'

registerNuiElements()
createApp(ButtonPage).mount('#app')
