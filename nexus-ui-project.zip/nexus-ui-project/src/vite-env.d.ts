/// <reference types="vite/client" />

import 'vue'

declare module 'vue' {
  interface GlobalComponents {
    'nui-button': Record<string, unknown>
    'nui-toggle-group': Record<string, unknown>
    'nui-toggle-button': Record<string, unknown>
  }
}
