import { registerNuiElements } from './elements/register'
import { alignIcons } from './icons/align'
import { plusIcon } from './icons/plus'
import './styles/tokens.css'
import './components/Button/Button.scss'
import './components/ButtonGroup/ButtonGroup.scss'

registerNuiElements()

document.querySelectorAll<HTMLElement>('[data-align]').forEach((node) => {
  const name = node.dataset.align as keyof typeof alignIcons
  node.innerHTML = alignIcons[name] ?? ''
})

document.querySelectorAll<HTMLElement>('[data-plus]').forEach((node) => {
  node.classList.add('nui-i')
  node.innerHTML = plusIcon
})

const clickOutput = document.querySelector('[data-clicks]')
let clicks = 0
document.querySelectorAll('.ui-btn').forEach((button) => {
  button.addEventListener('click', () => {
    clicks += 1
    if (clickOutput) clickOutput.textContent = String(clicks)
  })
})

const groups = document.querySelectorAll('nui-toggle-group')
const output = document.querySelector('[data-value]')

groups.forEach((group) => {
  group.addEventListener('change', (event) => {
    const custom = event as CustomEvent<{ value: string }>
    if (output) output.textContent = custom.detail.value
  })
})

const brand = document.querySelector<HTMLElement>('[data-brand]')
const color = document.querySelector<HTMLInputElement>('[name="primary"]')
const radius = document.querySelector<HTMLInputElement>('[name="radius"]')

function applyBrand() {
  if (!brand) return
  if (color) {
    brand.style.setProperty('--nui-primary-main', color.value)
    brand.style.setProperty('--nui-primary-tonal', `${color.value}29`)
    brand.style.setProperty('--nui-toggle-selected-bg', `${color.value}29`)
    brand.style.setProperty('--nui-toggle-icon-selected', color.value)
  }
  if (radius) {
    const value = `${radius.value}px`
    brand.style.setProperty('--nui-radius-sm', value)
    brand.style.setProperty('--nui-radius-md', value)
    brand.style.setProperty('--nui-radius-lg', value)
  }
}

color?.addEventListener('input', applyBrand)
radius?.addEventListener('input', applyBrand)
applyBrand()
