<script setup lang="ts">
import { reactive, ref } from 'vue'
import AlignIcon from './icons/AlignIcon.vue'
import PlusIcon from './icons/PlusIcon.vue'
import NuiButton from './vue/NuiButton.vue'
import NuiToggleButton from './vue/NuiToggleButton.vue'
import NuiToggleGroup from './vue/NuiToggleGroup.vue'
import './styles/playground.css'
import './styles/showcase.css'

const align = ref('left')
const brandAlign = ref('center')
const clicks = ref(0)
const loading = ref(false)

const brand = reactive({
  primary: '#7367f0',
  radius: 14,
})

const vueSnippet = `<NuiToggleGroup v-model="align" size="md">
  <NuiToggleButton value="left">…</NuiToggleButton>
  <NuiToggleButton value="center">…</NuiToggleButton>
</NuiToggleGroup>`

const htmlSnippet = `<nui-toggle-group value="left" size="md">
  <nui-toggle-button value="left">…</nui-toggle-button>
  <nui-toggle-button value="center">…</nui-toggle-button>
</nui-toggle-group>

<style>
:root { --nui-primary-main: #7367f0; }
</style>`

const vueButtonSnippet = `<NuiButton variant="contained" color="primary" size="md">
  Button
</NuiButton>

<!-- то же имя из макета -->
<UiButton variant="tonal" color="success">Save</UiButton>`

const htmlButtonSnippet = `<nui-button variant="contained" color="primary" size="md">
  Button
</nui-button>`

const colors = ['primary', 'secondary', 'success', 'error', 'warning', 'info'] as const
const variants = ['contained', 'tonal', 'outlined', 'text'] as const

function onAction() {
  clicks.value += 1
}

function onLoadDemo() {
  loading.value = true
  window.setTimeout(() => {
    loading.value = false
    clicks.value += 1
  }, 900)
}

function brandStyle() {
  const radius = `${brand.radius}px`
  return {
    '--nui-primary-main': brand.primary,
    '--nui-primary-tonal': `${brand.primary}29`,
    '--nui-toggle-selected-bg': `${brand.primary}29`,
    '--nui-toggle-icon-selected': brand.primary,
    '--nui-radius-sm': radius,
    '--nui-radius-md': radius,
    '--nui-radius-lg': radius,
  }
}
</script>

<template>
  <div class="page">
    <header class="topbar">
      <div class="brand"><b>NEXUS</b> UI</div>
      <nav class="nav">
        <a class="is-active" href="/">Каталог</a>
        <a href="/button.html">Витрина</a>
        <a href="/html.html">Чистый HTML</a>
      </nav>
    </header>

    <main class="wrap">
      <section class="intro">
        <h1>Кирпичи дизайн-системы</h1>
        <p>
          Компоненты из NEXUS UI: поведение общее и не ломается, внешний вид
          проекта задаётся токенами. Один и тот же custom element работает в Vue 3
          и в вёрстке без фреймворка.
        </p>
      </section>

      <section class="rules">
        <div class="rule">
          <strong>Не меняется</strong>
          <span>Клавиатура, фокус, ARIA, клик, выбор значения. JS кирпича не копируют и не правят.</span>
        </div>
        <div class="rule">
          <strong>Меняется токенами</strong>
          <span>Цвета, радиусы, отступы, тени, фон. Верстальщик не лезет в JS и не дублирует DOM.</span>
        </div>
      </section>

      <nav class="bricks" aria-label="Кирпичи">
        <a href="#toggle">Кнопка-переключатель</a>
        <a href="/button.html">Кнопка · витрина и документация</a>
      </nav>

      <section id="toggle" class="split" aria-label="Справка из макета">
        <article class="panel" data-theme="light">
          <div class="panel-head">
            <div class="heading">
              <h2>Кнопка-переключатель</h2>
              <span class="badge">Автолейаут</span>
            </div>
            <p class="lede">Кнопки-переключатели объединяют связанные параметры.</p>
          </div>
          <div class="panel-body">
            <p class="sizes-label">Размеры</p>
            <div class="sizes-frame">
              <div class="size-line">
                <span>Большой</span>
                <NuiToggleGroup v-model="align" size="lg" aria-label="Выравнивание, большой">
                  <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
                  <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
                  <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
                  <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
                </NuiToggleGroup>
              </div>
              <div class="size-line">
                <span>Средний</span>
                <NuiToggleGroup v-model="align" size="md" aria-label="Выравнивание, средний">
                  <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
                  <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
                  <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
                  <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
                </NuiToggleGroup>
              </div>
              <div class="size-line">
                <span>Малый</span>
                <NuiToggleGroup v-model="align" size="sm" aria-label="Выравнивание, малый">
                  <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
                  <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
                  <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
                  <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
                </NuiToggleGroup>
              </div>
            </div>
          </div>
        </article>

        <article class="panel" data-theme="dark">
          <div class="panel-head">
            <div class="heading">
              <h2>Кнопка-переключатель</h2>
              <span class="badge">Автолейаут</span>
            </div>
            <p class="lede">Кнопки-переключатели объединяют связанные параметры.</p>
          </div>
          <div class="panel-body">
            <p class="sizes-label">Размеры</p>
            <div class="sizes-frame">
              <div class="size-line">
                <span>Большой</span>
                <NuiToggleGroup v-model="align" size="lg" aria-label="Выравнивание, тёмная большая">
                  <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
                  <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
                  <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
                  <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
                </NuiToggleGroup>
              </div>
              <div class="size-line">
                <span>Средний</span>
                <NuiToggleGroup v-model="align" size="md" aria-label="Выравнивание, тёмная средняя">
                  <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
                  <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
                  <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
                  <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
                </NuiToggleGroup>
              </div>
              <div class="size-line">
                <span>Малый</span>
                <NuiToggleGroup v-model="align" size="sm" aria-label="Выравнивание, тёмная малая">
                  <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
                  <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
                  <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
                  <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
                </NuiToggleGroup>
              </div>
            </div>
          </div>
        </article>
      </section>

      <section class="live">
        <h3>Vue 3</h3>
        <p class="hint">v-model общий для всех размеров и тем — логика одна.</p>
        <div class="live-row">
          <NuiToggleGroup v-model="align" size="md" aria-label="Живой пример">
            <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
            <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
            <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
            <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
          </NuiToggleGroup>
          <p class="value-pill">value: <b>{{ align }}</b> · стрелки, когда фокус внутри группы</p>
        </div>
      </section>

      <p class="path-banner">
        <strong>Витрина кнопки:</strong>
        все варианты, состояния и документация —
        <a href="/button.html">/button.html</a>
      </p>

      <section id="button" class="split" aria-label="Кнопка из макета">
        <article class="panel" data-theme="light">
          <div class="panel-head">
            <div class="heading">
              <h2>Кнопка</h2>
              <span class="badge">UiButton</span>
            </div>
            <p class="lede">Одно действие. Вариант и цвет — атрибуты, не отдельные компоненты.</p>
          </div>
          <div class="panel-body">
            <p class="sizes-label">Размеры</p>
            <div class="sizes-frame">
              <div class="size-line">
                <span>Большой</span>
                <NuiButton size="lg" aria-label="Большая кнопка"><PlusIcon /> Button</NuiButton>
              </div>
              <div class="size-line">
                <span>Средний</span>
                <NuiButton size="md"><PlusIcon /> Button</NuiButton>
              </div>
              <div class="size-line">
                <span>Малый</span>
                <NuiButton size="sm"><PlusIcon /> Button</NuiButton>
              </div>
              <div class="size-line">
                <span>XS</span>
                <NuiButton size="sm"><PlusIcon /> Button</NuiButton>
              </div>
            </div>
          </div>
        </article>

        <article class="panel" data-theme="dark">
          <div class="panel-head">
            <div class="heading">
              <h2>Кнопка</h2>
              <span class="badge">UiButton</span>
            </div>
            <p class="lede">Тёмная тема — те же токены на родителе, то же поведение.</p>
          </div>
          <div class="panel-body">
            <p class="sizes-label">Размеры</p>
            <div class="sizes-frame">
              <div class="size-line">
                <span>Большой</span>
                <NuiButton size="lg"><PlusIcon /> Button</NuiButton>
              </div>
              <div class="size-line">
                <span>Средний</span>
                <NuiButton size="md"><PlusIcon /> Button</NuiButton>
              </div>
              <div class="size-line">
                <span>Малый</span>
                <NuiButton size="sm"><PlusIcon /> Button</NuiButton>
              </div>
              <div class="size-line">
                <span>XS</span>
                <NuiButton size="sm"><PlusIcon /> Button</NuiButton>
              </div>
            </div>
          </div>
        </article>
      </section>

      <section class="live">
        <h3>Варианты и цвета</h3>
        <p class="hint">contained / tonal / outlined / text. Цвет задаёт токен, не копия кнопки.</p>
        <div class="variant-table">
          <div v-for="variant in variants" :key="variant" class="variant-row">
            <span class="variant-name">{{ variant }}</span>
            <div class="btn-row">
              <NuiButton
                v-for="color in colors"
                :key="`${variant}-${color}`"
                :variant="variant"
                :color="color"
                size="md"
              >
                {{ color }}
              </NuiButton>
            </div>
          </div>
        </div>
      </section>

      <section class="live">
        <h3>Поведение кнопки</h3>
        <p class="hint">Клик, Space/Enter, disabled и loading заморожены. Скин не трогает логику.</p>
        <div class="btn-row">
          <NuiButton @click="onAction">Нажать</NuiButton>
          <NuiButton variant="tonal" rounded @click="onAction">Rounded</NuiButton>
          <NuiButton variant="outlined" :loading="loading" @click="onLoadDemo">
            {{ loading ? 'Загрузка' : 'Loading' }}
          </NuiButton>
          <NuiButton variant="text" disabled>Disabled</NuiButton>
          <NuiButton icon aria-label="Добавить" @click="onAction"><PlusIcon /></NuiButton>
          <p class="value-pill">clicks: <b>{{ clicks }}</b></p>
        </div>
      </section>

      <section class="tokens">
        <h3>Другой бренд — только токены</h3>
        <p class="hint">Тот же компонент. Меняются CSS-переменные, не разметка и не поведение.</p>
        <div class="token-grid">
          <label>
            --nui-primary-main
            <input v-model="brand.primary" type="color" />
          </label>
          <label>
            радиус {{ brand.radius }}px
            <input v-model.number="brand.radius" type="range" min="0" max="24" />
          </label>
        </div>
        <div class="brand-box" :style="brandStyle()">
          <NuiToggleGroup v-model="brandAlign" size="lg" aria-label="Бренд, токены">
            <NuiToggleButton value="left"><AlignIcon name="left" /></NuiToggleButton>
            <NuiToggleButton value="center"><AlignIcon name="center" /></NuiToggleButton>
            <NuiToggleButton value="right"><AlignIcon name="right" /></NuiToggleButton>
            <NuiToggleButton value="justify"><AlignIcon name="justify" /></NuiToggleButton>
          </NuiToggleGroup>
          <NuiButton size="lg"><PlusIcon /> Button</NuiButton>
          <NuiButton size="lg" variant="tonal">Tonal</NuiButton>
          <span class="value-pill">Проект переопределяет токены на :root или на обёртке</span>
        </div>
      </section>

      <section class="usage">
        <h3>Как брать кирпич</h3>
        <div class="usage-grid">
          <div>
            <p class="hint">Vue 3 · переключатель</p>
            <pre class="code">{{ vueSnippet }}</pre>
          </div>
          <div>
            <p class="hint">HTML · переключатель</p>
            <pre class="code">{{ htmlSnippet }}</pre>
          </div>
          <div>
            <p class="hint">Vue 3 · кнопка (NuiButton / UiButton)</p>
            <pre class="code">{{ vueButtonSnippet }}</pre>
          </div>
          <div>
            <p class="hint">HTML · кнопка</p>
            <pre class="code">{{ htmlButtonSnippet }}</pre>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>
