<script setup lang="ts">
defineProps<{
  value: string
  disabled?: boolean
}>()
</script>

<template>
  <nui-toggle-button :value="value" :disabled="disabled || undefined">
    <slot />
  </nui-toggle-button>
</template>
