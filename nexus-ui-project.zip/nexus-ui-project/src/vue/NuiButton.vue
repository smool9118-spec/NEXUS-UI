<script setup lang="ts">
import UiButton from '../components/Button/UiButton.vue'
import type { UiButtonProps } from '../components/Button/Button.types'

defineOptions({ inheritAttrs: false })
defineProps<UiButtonProps>()
</script>

<template>
  <UiButton v-bind="{ ...$props, ...$attrs }">
    <template v-if="$slots['icon-left']" #icon-left>
      <slot name="icon-left" />
    </template>
    <slot />
    <template v-if="$slots['icon-right']" #icon-right>
      <slot name="icon-right" />
    </template>
  </UiButton>
</template>
