<script setup lang="ts">
defineOptions({ inheritAttrs: false })

withDefaults(
  defineProps<{
    modelValue?: string
    size?: 'sm' | 'md' | 'lg'
    disabled?: boolean
  }>(),
  { size: 'md' },
)

const emit = defineEmits<{
  'update:modelValue': [value: string]
}>()

function onChange(event: Event) {
  const custom = event as CustomEvent<{ value: string }>
  emit('update:modelValue', custom.detail.value)
}
</script>

<template>
  <nui-toggle-group
    :value="modelValue"
    :size="size"
    :disabled="disabled || undefined"
    v-bind="$attrs"
    @change="onChange"
  >
    <slot />
  </nui-toggle-group>
</template>
