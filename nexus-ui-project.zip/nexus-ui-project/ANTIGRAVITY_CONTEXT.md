# NEXUS UI — контекст для агента Antigravity

Дизайн-система на **Vue 3.5 + Vite 8 + TypeScript + Sass**. Внешний вид меняется токенами. Поведение компонентов заморожено: клавиатура, фокус, `v-model`, a11y.

Правила атома продублированы в `.cursorrules` и `AGENTS.md`. Этот файл — карта репозитория: что уже собрано, куда класть следующий кирпич, как устроены витрина и сборка.

Figma: [NEXUS-UI](https://www.figma.com/design/L4Y6dksinsjrCCtPLI47Wd/NEXUS-UI).

---

## 1. Архитектура: три слоя, четыре файла

Каждый UI-атом делится на независимые слои. Нельзя склеивать вёрстку, типы и логику в одном `.vue`.

| Слой | Файл | Кто трогает | Вопрос слоя |
| --- | --- | --- | --- |
| Токены | `src/styles/tokens.css` | дизайнер | В каком бренде / теме мы сейчас? |
| Вёрстка | `[Component].scss` | верстальщик | Как выглядит md + hover? |
| Контракт | `[Component].types.ts` | фронт | Какие пропсы и значения? |
| Логика | `Ui[Component].vue` | фронт | Что происходит по клику, Tab, Space? |

Общий `tokens.css` **не копировать** в папку компонента. Светлая тема — `:root` / `[data-theme='light']`, тёмная — `[data-theme='dark']`. В SCSS и Vue только `var(--token)`, без сырого HEX.

Типовые пути новых атомов (как у последних кирпичей):

```
src/components/ui/[Component]/
  [Component].scss
  [Component].types.ts
  Ui[Component].vue
```

Ранние атомы лежат без `ui/`:

```
src/components/Button/
src/components/ButtonGroup/
```

Группа может жить в той же папке, что и атом (`UiRadio.vue` + `UiRadioGroup.vue` + общие `Radio.scss` / `Radio.types.ts`).

### Роли — жёстко

- **Дизайнер** — только значения в `tokens.css`.
- **Верстальщик** — только `[Component].scss` (variant / size / color / hover / focus-visible / active / disabled). Без JS.
- **Фронтендер** — только types + `Ui*.vue` (пропсы, слоты, loading/disabled, клавиатура). Не хардкодить цвета и отступы.

### Нельзя

- Копировать внутренний DOM из макета и «подкручивать» поведение под кадр Figma.
- Делать отдельную «версию кнопки» вместо variant / color / size через пропсы и токены.
- Писать `:deep()` в standalone `.scss` (молния/lightningcss ругается) — обычные вложенные селекторы.

---

## 2. Стек и точки входа

- Vue 3.5, Vite 8, `sass`, `vue-tsc`.
- Алиас `@` → `src/` (`vite.config.ts`, `tsconfig.app.json`).
- Теги `nui-*` — custom elements (`compilerOptions.isCustomElement`).
- Dev / preview: `127.0.0.1:4827`, `host: true`, `allowedHosts: true`.

| URL | Что это |
| --- | --- |
| `/` (`index.html` → `src/main.ts` → `ButtonPage.vue`) | основная витрина |
| `/button.html` | запасная витрина кнопки |
| `/html.html` | чистый HTML-демо |
| `/nexus-ui-project.zip` | архив исходников из `public/` |

Публичный корень Vite — папка `public/` (фавикон, zip).

---

## 3. Какие компоненты готовы

Готовые атомы из Figma (можно расширять вариантами, нельзя ломать API):

| Компонент | Папка | Vue | Заметки |
| --- | --- | --- | --- |
| Button | `src/components/Button/` | `UiButton` | variant: contained / tonal / outlined / text; loading, ripple |
| ButtonGroup | `src/components/ButtonGroup/` | `UiButtonGroup` | provide/inject в кнопки |
| IconButton | `src/components/ui/IconButton/` | `UiIconButton` | shape, цвета, loading |
| TextField | `src/components/ui/TextField/` | `UiTextField` | outlined / filled / standard, float label |
| MaskedField | `src/components/ui/MaskedField/` | `UiMaskedField` | пресеты phone/date/time/card/inn/snils, счётчик |
| Select | `src/components/ui/Select/` | `UiSelect` | single / multiple chips, search, groups |
| Checkbox | `src/components/ui/Checkbox/` | `UiCheckbox` | boolean и массив, indeterminate |
| Radio + RadioGroup | `src/components/ui/Radio/` | `UiRadio`, `UiRadioGroup` | options и/или слот, стрелки в radiogroup |
| Switch | `src/components/ui/Switch/` | `UiSwitch` | boolean, loading-спиннер в thumb, слоты иконок |

Дополнительно (не из последнего списка Figma-атомов, но в репо):

- **Toggle** (`nui-toggle-group` / `nui-toggle-button`) — custom elements в `src/elements/`, Vue-обёртки в `src/vue/NuiToggle*.vue`. Витрина: атом `toggle`.

Реэкспорт для фронта:

- `src/components/index.ts` — канонический баррель атомов.
- `src/vue/index.ts` — то же плюс toggle-обёртки.

Импорт в приложении:

```ts
import { UiButton, UiSwitch } from '@/components'
```

---

## 4. Что осталось по макету Figma

В сайдбаре витрины (`src/showcase/atoms.ts`) серым помечены **не готовые** атомы:

| Атом | Figma | Статус |
| --- | --- | --- |
| Dialog | Dialog | не начат (`ready: false`) |
| Dropdown | Dropdown | не начат (`ready: false`) |

Следующий кирпич делать тем же каркасом: токены → scss → types → `Ui*.vue` → атом витрины в `src/showcase/` → запись в `atoms.ts` и `ButtonPage.vue`.

---

## 5. Страница-витрина

`src/ButtonPage.vue` — оболочка:

- слева каталог (`atoms` + `kind: 'page' | atom`);
- по центру статья выбранного атома (`src/showcase/*Atom.vue`);
- справа содержание секций.

Новый готовый атом:

1. Компонент в `src/components/...` (4 файла).
2. Экспорт в `src/components/index.ts` и `src/vue/index.ts`.
3. Статья `src/showcase/[Name]Atom.vue`: документация, размеры light/dark, цвета, состояния, токены, Vue-сниппет, чистый HTML.
4. Запись в `src/showcase/atoms.ts` (`ready: true`, `sections` для TOC).
5. Ветка `v-else-if` в `ButtonPage.vue`.
6. Абзац в `README.md`.

Стили витрины: `src/styles/showcase.css`, `src/styles/playground.css`. Не смешивать их с SCSS атома.

Шапка витрины содержит кнопку скачивания архива: `/nexus-ui-project.zip`.

---

## 6. Сборка библиотеки и запуск

Это **не отдельный npm-publish пакет**, а Vite-приложение, из которого забирают исходники атомов.

```bash
npm install
npm run dev       # витрина, порт 4827
npm run build     # vue-tsc -b && vite build
npm run preview   # тот же порт
```

Сборка проверяет типы (`vue-tsc -b`). Multi-page Rollup input: `index.html`, `html.html`, `button.html`.

Custom elements (пока кнопка и toggle) регистрируются в `src/elements/register.ts` на старте `main.ts`. Новые атомы из Figma-очереди делать **Vue-атомами**, не custom elements, если в задаче не сказано иное.

---

## 7. Как добавлять следующий атом

1. Снять геометрию и цвета с кадра Figma (не копировать внутренний DOM).
2. Добавить только недостающие токены в `src/styles/tokens.css` (light + то, что реально меняется в dark).
3. Нарисовать состояния в `[Component].scss`.
4. Описать пропсы в `[Component].types.ts`.
5. Собрать логику и a11y в `Ui[Component].vue`.
6. Показать атом на витрине: размеры, light/dark, цвета, disabled/loading, живой `v-model`.
7. Прогнать `npm run build`.

Имена variant / size / color в Figma должны совпадать с пропсами.

---

## 8. Карта каталогов

```
.cursorrules / AGENTS.md         правила 4 файлов
ANTIGRAVITY_CONTEXT.md           этот файл
src/styles/tokens.css            дизайнер: темы и размеры
src/components/Button/           UiButton
src/components/ButtonGroup/      UiButtonGroup
src/components/ui/IconButton/
src/components/ui/TextField/
src/components/ui/MaskedField/
src/components/ui/Select/
src/components/ui/Checkbox/
src/components/ui/Radio/         UiRadio + UiRadioGroup
src/components/ui/Switch/
src/elements/                    custom elements (button, toggle)
src/vue/                         реэкспорт + обёртки toggle
src/showcase/                    статьи витрины
public/                          favicon, nexus-ui-project.zip
```
