# NEXUS UI — инструкция

Кирпичи дизайн-системы из Figma. Их переиспользуют верстальщик и фронт при сборке проектов.

**Правило:** внешний вид можно менять. Поведение нельзя.

| Можно | Нельзя |
| --- | --- |
| Цвета, радиусы, отступы, шрифты через CSS-токены | Копировать внутренний DOM и править JS компонента |
| Светлая / тёмная тема (`data-theme`) | Ломать клавиатуру, фокус, выбор значения |
| Свои иконки и контент через слот | Делать отдельную «версию кнопки» под каждый макет |

Каждый атом — 4 файла: `tokens.css`, `[Component].scss`, `[Component].types.ts`, `Ui[Component].vue`. Правило в `.cursorrules`.

- **Дизайнер** — `src/styles/tokens.css` (светлая / тёмная тема)
- **Верстальщик** — `[Component].scss` (классы `ui-btn`, без JS)
- **Фронт** — `UiButton` / `UiButtonGroup` / `UiIconButton` / `UiTextField` / `UiMaskedField` / `UiSelect` / `UiCheckbox` / `UiRadio` / `UiRadioGroup` / `UiSwitch` и `*.types.ts`

---

## 1. Запуск локально

Нужны Node.js 22 и npm.

```bash
npm install
npm run dev
```

- **Витрина** (слева атомы, по центру статья, справа содержание): http://127.0.0.1:4827/
- Чистый HTML выбранного атома — раздел в статье, пункт оглавления справа

Сборка:

```bash
npm run build
npm run preview
```

---

## 2. Верстальщик: чистый HTML

Подключите токены и регистрацию элементов (в этом репозитории это делает `/src/html-demo.ts`).

```html
<link rel="stylesheet" href="/src/styles/tokens.css" />
<link rel="stylesheet" href="/src/components/Button/Button.scss" />

<button class="ui-btn ui-btn--contained ui-btn--primary ui-btn--md" type="button">
  Кнопка
</button>

<nui-toggle-group value="left" size="md">
  <nui-toggle-button value="left">…</nui-toggle-button>
  <nui-toggle-button value="center">…</nui-toggle-button>
</nui-toggle-group>
```

Клик кнопки — обычный `click`. Выбор в группе:

```js
document.querySelector('nui-toggle-group')
  .addEventListener('change', (e) => {
    console.log(e.detail.value)
  })
```

Тёмная тема — на родителе:

```html
<section data-theme="dark">
  <nui-toggle-group value="left" size="md">…</nui-toggle-group>
</section>
```

Живой пример без Vue: `html.html`.

---

## 3. Фронт: Vue 3

В `main.ts` один раз зарегистрируйте элементы:

```ts
import { registerNuiElements } from './elements/register'
import './styles/tokens.css'

registerNuiElements()
```

В шаблоне:

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { UiButton, UiButtonGroup, UiIconButton } from '@/components'
import { NuiToggleGroup, NuiToggleButton } from './vue'

const align = ref('left')
</script>

<template>
  <UiButton variant="contained" color="primary" @click="onSave">Save</UiButton>
  <UiButtonGroup variant="outlined" color="primary">
    <UiButton>Один</UiButton>
    <UiButton>Два</UiButton>
  </UiButtonGroup>

  <UiIconButton variant="contained" color="primary" aria-label="В избранное">
    …
  </UiIconButton>

  <NuiToggleGroup v-model="align" size="md">
    <NuiToggleButton value="left">…</NuiToggleButton>
    <NuiToggleButton value="center">…</NuiToggleButton>
  </NuiToggleGroup>
</template>
```

В `vite.config.ts` custom elements с префиксом `nui-` уже помечены как нативные теги.

---

## 4. Как менять стили проекта

Только токенами. Файл-источник: `src/styles/tokens.css`.

На всём сайте:

```css
:root {
  --nui-primary-main: #7367f0;
  --nui-radius-md: 6px;
}
```

На одном блоке (другой бренд / лендинг):

```html
<div style="--nui-primary-main: #e44d62; --nui-radius-lg: 16px">
  <nui-button size="lg">Button</nui-button>
  <nui-toggle-group value="center" size="lg">…</nui-toggle-group>
</div>
```

Нельзя: лезть в shadow DOM, дублировать разметку кнопки, писать «новую логику выбора» рядом с кирпичом.

### Токены из макета

| Токен | Светлая | Тёмная |
| --- | --- | --- |
| `--nui-paper` | `#ffffff` | `#2f3349` |
| `--nui-text-primary` | `#2f2b3de5` | `#e1def5e5` |
| `--nui-text-secondary` | `#2f2b3db2` | `#e1def5b2` |
| `--nui-divider` | `#2f2b3d1f` | `#e1def51f` |
| `--nui-action-selected` | `#2f2b3d14` | `#e1def514` |
| `--nui-primary-main` | `#7367f0` | то же |
| `--nui-success-main` | `#28c76f` | то же |
| `--nui-error-main` | `#ff4c51` | то же |
| `--nui-warning-main` | `#ff9f43` | то же |
| `--nui-info-main` | `#00bad1` | то же |
| `--nui-radius-sm / md / lg` | `4px` / `6px` / `8px` | то же |
| `--nui-on-color` | `#ffffff` | то же |
| `--nui-primary-tonal` | `#7367f029` | то же |

Тема: `data-theme="light"` или `data-theme="dark"` на предке.

---

## 5. Кнопка (Figma: UiButton)

Кадр Figma «Кнопки». Одно действие, не группа выбора. Vue: `UiButton`.

Живая витрина: **http://127.0.0.1:4827/** — слева каталог атомов, по центру эта страница, справа оглавление.

Файлы: `tokens.css` · `Button.scss` · `Button.types.ts` · `UiButton.vue`.

### Пропсы / атрибуты

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `variant` | `contained` \| `tonal` \| `outlined` \| `text` | `contained` |
| `color` | `primary` \| `secondary` \| `error` \| `warning` \| `info` \| `success` | `primary` |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `type` | `button` \| `submit` \| `reset` | `button` |
| `disabled` | boolean | `false` |
| `loading` | boolean | `false` |
| `rounded` | boolean, форма-капсула | `false` |
| `icon` | boolean, квадратная иконка | `false` |
| `block` | boolean, ширина 100% | `false` |
| слот | подпись | |
| `icon-left` / `icon-right` | иконки | |

### Что заморожено

- клик и Space / Enter нажимают кнопку
- `disabled` и `loading` не дают нажать
- фокус кольцом, `aria-busy` при загрузке
- это одна кнопка, а не набор «версий под макет»

### Что меняется токенами

`--nui-primary-main`, `--nui-primary-tonal`, `--nui-on-color`, `--nui-radius-*`, `--nui-btn-weight`.

Нельзя: копировать внутренний `<button>`, писать отдельный «красный contained» рядом с кирпичом.

---

## 6. Кнопка с иконкой (Figma: UiIconButton)

Кадр Figma «Кнопка с иконкой». Квадрат 1:1, внутри только SVG. Vue: `UiIconButton`.

Файлы: `tokens.css` · `src/components/ui/IconButton/IconButton.scss` · `IconButton.types.ts` · `UiIconButton.vue`.

### Пропсы

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `variant` | `contained` \| `outlined` \| `standard` | `contained` |
| `color` | `default` \| `primary` \| `secondary` \| `error` \| `warning` \| `info` \| `success` | `default` |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `shape` | `circle` \| `rounded` | `rounded` |
| `disabled` | boolean | `false` |
| `loading` | boolean, спиннер вместо иконки | `false` |
| `active` | boolean, toggle / `aria-pressed` | — |
| `ariaLabel` | string, обязательный | — |
| слот | SVG-иконка | |

### Что заморожено

- клик и Space / Enter нажимают кнопку
- `disabled` и `loading` не дают нажать, loading меняет слот на спиннер
- `aria-label` всегда, `aria-pressed` при `active`
- фокус кольцом, ripple, `scale(0.98)`

### Что меняется токенами

`--nui-icon-btn-size-*`, `--nui-icon-btn-icon-*`, `--nui-primary-main`, `--nui-default-*`, `--nui-radius-*`.

---

## 7. Текстовое поле (Figma: UiTextField)

Кадр Figma «Текстовое поле». Подпись, ввод, подсказка. Vue: `UiTextField`.

Файлы: `tokens.css` · `src/components/ui/TextField/TextField.scss` · `TextField.types.ts` · `UiTextField.vue`.

### Пропсы

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `modelValue` / `v-model` | `string` \| `number` | `''` |
| `variant` | `outlined` \| `filled` \| `standard` | `outlined` |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `color` | `primary` \| `secondary` \| `error` \| `warning` \| `info` \| `success` | `primary` |
| `label` | string, плавает при фокусе или заполнении | — |
| `placeholder` | string | — |
| `helperText` | string | — |
| `error` / `errorMessage` | boolean / string | — |
| `disabled` / `readonly` / `required` | boolean | `false` |
| `clearable` | boolean | `false` |
| `type` | `text` \| `password` \| `email` \| `number` \| `tel` \| `search` | `text` |
| `multiline` / `rows` | textarea | `false` / `3` |
| слот `prepend` / `append` | иконки внутри поля | |

### Что заморожено

- `v-model`, `focus` / `blur` / `clear`
- `aria-invalid`, `aria-describedby`, связь `label` и `input` через id
- password: глазик показать/скрыть; `clearable`: крестик

### Что меняется токенами

`--ui-input-bg`, `--ui-input-border`, `--ui-placeholder`, `--ui-error`, `--nui-input-height-*`, `--nui-radius-*`.

---

## 8. Поле с маской (UiMaskedField)

Обёртка над `UiTextField`: маски ввода, «чистая» строка в v-model, шаблон маски и счётчик символов. Базовый инпут без этой логики.

Файлы: `tokens.css` · `src/components/ui/MaskedField/MaskedField.scss` · `MaskedField.types.ts` · `UiMaskedField.vue`.

### Пропсы

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| визуальные от TextField | `variant`, `size`, `color`, `label`, `placeholder`, `helperText`, `error`, `errorMessage`, `disabled`, `readonly`, `clearable` | как у `UiTextField` |
| `modelValue` / `v-model` | `string` | `''` |
| `mask` | `phone` \| `date` \| `time` \| `card` \| `inn` \| `snils` \| кастом (`#` цифра, `A` буква, `*` любой) | — |
| `unmaskedValue` | boolean, в v-model без скобок и дефисов | `false` |
| `maskPlaceholder` | boolean, шаблон маски при фокусе | `false` |
| `maxLength` | number | — |
| `showCounter` | boolean, `current / maxLength` справа внизу | `false` |
| `@complete` | маска заполнена целиком | — |
| слот `prepend` / `append` | пробрасываются в `UiTextField` | |

Пресеты: `phone` → `+7 (###) ###-##-##`, `date` → `##.##.####`, `time` → `##:##`, `card` → `#### #### #### ####`.

### Что заморожено

- форматирование при вводе, Backspace / Delete и вставке
- курсор только на валидных слотах маски
- `complete`, когда заполнены все слоты
- лимит `maxLength` не даёт ввести больше символов

### Что меняется токенами

`--ui-warning` (счётчик от 90%), `--ui-error` (лимит или ошибка), `--ui-placeholder` (незаполненные символы маски), `--nui-text-secondary`.

---

## 9. Список выбора (Figma: UiSelect)

Кадр Figma «Список выбора». Триггер как у `UiTextField`, сверху — выпадающий список. Vue: `UiSelect`.

Файлы: `tokens.css` · `src/components/ui/Select/Select.scss` · `Select.types.ts` · `UiSelect.vue`.

### Пропсы

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `modelValue` / `v-model` | `string` \| `number` \| массив \| `null` | `null` |
| `options` | `{ label, value, disabled?, group?, icon? }[]` | `[]` |
| `multiple` | boolean | `false` |
| `chips` | boolean, теги при `multiple` | `false` |
| `searchable` | boolean | `false` |
| `clearable` / `loading` | boolean | `false` |
| `variant` | `outlined` \| `filled` \| `standard` | `outlined` |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `color` | `primary` \| `secondary` \| `error` \| `warning` \| `info` \| `success` | `primary` |
| `label` / `placeholder` / `helperText` | string | — |
| `error` / `errorMessage` / `disabled` / `required` | boolean / string | — |
| слот `option` / `selected` / `prepend` / `empty` | кастом строки, значения, иконка, пустой список | |

### Что заморожено

- открытие по клику, закрытие снаружи и по Escape
- стрелки, Enter / Space, автоскролл к активной опции
- `multiple` не закрывает меню
- `role="combobox"` / `listbox` / `option`, `aria-expanded`, `aria-selected`

### Что меняется токенами

`--ui-surface`, `--ui-shadow-lg`, `--ui-radius-md`, `--ui-input-*`, `--nui-action-hover`, `--nui-action-selected`.

---

## 10. Кнопка-переключатель

Кадр Figma «Кнопка-переключатель». Связанные параметры, одно выбранное значение.

### Пропсы / атрибуты группы

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `value` / `v-model` | строка выбранной кнопки | `""` |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `disabled` | boolean | `false` |

### Кнопка

| Имя | Назначение |
| --- | --- |
| `value` | значение, которое попадёт в группу |
| `disabled` | пункт недоступен |
| слот | иконка или текст |

### Что заморожено

- клик выбирает одну кнопку
- стрелки / Home / End ходят по пунктам
- Space и Enter подтверждают
- `role="radiogroup"` / `role="radio"` и `aria-checked`

### Что меняется токенами

`--nui-toggle-border`, `--nui-toggle-selected-bg`, `--nui-toggle-icon`, `--nui-radius-*`, `--nui-primary-main`.

---

## 11. Флажок (Figma: UiCheckbox)

Кадр Figma «Флажок». Один или несколько пунктов. Vue: `UiCheckbox`.

Файлы: `tokens.css` · `src/components/ui/Checkbox/Checkbox.scss` · `Checkbox.types.ts` · `UiCheckbox.vue`.

### Пропсы

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `modelValue` / `v-model` | `boolean` \| массив | `false` |
| `value` | `string` \| `number`, для режима массива | — |
| `indeterminate` | boolean, минус «выбрать все» | `false` |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `color` | `primary` \| `secondary` \| `error` \| `warning` \| `info` \| `success` | `primary` |
| `label` | string | — |
| `labelPlacement` | `end` \| `start` \| `top` \| `bottom` | `end` |
| `helperText` / `error` / `errorMessage` | string / boolean / string | — |
| `disabled` / `required` | boolean | `false` |

### Что заморожено

- нативный `input type="checkbox"`, Space, связь `label` и `id`
- `aria-checked="mixed"` при `indeterminate`
- `v-model` как boolean и как массив значений

### Что меняется токенами

`--ui-check-box-*`, `--ui-check-halo-*`, `--nui-primary-main` и остальные цвета, `--ui-check-radius`, `--nui-on-color`.

---

## 12. Радиокнопка (Figma: UiRadio)

Кадр Figma «Радиокнопка». Один вариант из списка. Vue: `UiRadio` и `UiRadioGroup`.

Файлы: `tokens.css` · `src/components/ui/Radio/Radio.scss` · `Radio.types.ts` · `UiRadio.vue` · `UiRadioGroup.vue`.

### Пропсы UiRadio

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `modelValue` / `v-model` | `string` \| `number` | — |
| `value` | `string` \| `number` | обязательный |
| `label` | string | — |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `color` | `primary` \| `secondary` \| `error` \| `warning` \| `info` \| `success` | `primary` |
| `labelPlacement` | `end` \| `start` \| `top` \| `bottom` | `end` |
| `disabled` | boolean | `false` |

### Пропсы UiRadioGroup

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `modelValue` / `v-model` | `string` \| `number` | — |
| `name` | string, общее имя native radio | генерируется |
| `options` | `{ label; value; disabled? }[]` | `[]` |
| `direction` | `row` \| `column` | `column` |
| `size` / `color` | наследуются вложенными `UiRadio` | `md` / `primary` |
| `label` | заголовок группы | — |
| `helperText` / `error` / `errorMessage` | string / boolean / string | — |
| `disabled` | boolean | `false` |

### Что заморожено

- нативный `input type="radio"`, общее `name`, Space
- стрелки / Home / End внутри `role="radiogroup"`
- `provide` / `inject`: массив `options` и слот `<UiRadio>`

### Что меняется токенами

`--ui-radio-box-*`, `--ui-radio-dot-*`, `--ui-radio-halo-*`, `--nui-primary-main` и остальные цвета, `--ui-radio-dot-fill`.

---

## 13. Тумблер (Figma: UiSwitch)

Кадр Figma «Переключатель». Вкл / выкл одной настройки. Vue: `UiSwitch`.

Файлы: `tokens.css` · `src/components/ui/Switch/Switch.scss` · `Switch.types.ts` · `UiSwitch.vue`.

### Пропсы

| Имя | Значения | По умолчанию |
| --- | --- | --- |
| `modelValue` / `v-model` | boolean | `false` |
| `size` | `sm` \| `md` \| `lg` | `md` |
| `color` | `primary` \| `secondary` \| `error` \| `warning` \| `info` \| `success` | `primary` |
| `loading` | boolean, спиннер в ползунке | `false` |
| `disabled` | boolean | `false` |
| `label` | string | — |
| `labelPlacement` | `end` \| `start` \| `top` \| `bottom` | `end` |
| `helperText` / `error` / `errorMessage` | string / boolean / string | — |
| слоты | `thumb-icon`, `track-on`, `track-off` | — |

### Что заморожено

- `role="switch"`, `aria-checked`, Space / Enter
- `aria-busy` и блок переключения при `loading`
- скольжение ползунка, не копировать кружок из макета

### Что меняется токенами

`--ui-switch-track-*`, `--ui-switch-thumb-*`, `--ui-switch-halo-*`, `--nui-primary-main` и остальные цвета, `--ui-switch-ease`.

---

## 14. Как добавлять следующий кирпич

Тот же каркас, что у кнопки и toggle:

1. Токены — только в `src/styles/tokens.css`, без хардкода цвета в компоненте.
2. Поведение — class в `src/elements/…`, регистрация в `register.ts`.
3. Vue — тонкая обёртка в `src/vue/` (`v-model`, пропсы).
4. И HTML, и Vue используют один тег `<nui-…>`.
5. В каталоге показать: размеры, light/dark, живой `v-model`, смену токенов без смены логики.

Очередь атомов из макета: Dialog, Dropdown.

---

## 15. Структура

```
.cursorrules                         правило: 4 файла на атом
src/styles/tokens.css                дизайнер: цвета, отступы, темы
src/components/Button/               Button.scss + types + UiButton.vue
src/components/ButtonGroup/          ButtonGroup.scss + types + UiButtonGroup.vue
src/components/ui/IconButton/        IconButton.scss + types + UiIconButton.vue
src/components/ui/TextField/         TextField.scss + types + UiTextField.vue
src/components/ui/MaskedField/       MaskedField.scss + types + UiMaskedField.vue
src/components/ui/Select/            Select.scss + types + UiSelect.vue
src/components/ui/Checkbox/          Checkbox.scss + types + UiCheckbox.vue
src/components/ui/Radio/             Radio.scss + types + UiRadio.vue + UiRadioGroup.vue
src/components/ui/Switch/            Switch.scss + types + UiSwitch.vue
src/elements/                        toggle (custom elements, пока)
src/vue/                             обёртки Toggle + реэкспорт Button
src/showcase/                        статьи витрины
```
